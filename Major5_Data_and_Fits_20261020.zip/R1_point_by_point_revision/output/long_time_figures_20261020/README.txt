MAJOR 5: NUMERICAL DATA, FITS, AND FIGURES
=======================================

This archive contains the data underlying the numerical section of the
Supplementary Material and the response to Major 5, together with runnable
analysis and plotting code. All commands below are run from the extracted
archive directory; they require no connection to the original workspace.

DATA AND CONVENTIONS
--------------------
data/trajectories.tsv contains the trajectories used in the principal fits
and Figs. S1-S2. Columns are d, L, p, tau, index, W, E. W is inclusive total
work and E is the final total energy. One record is one independent trajectory.

The principal data contain 18 durations per protocol (p=1 and p=1.2) and
dimension: 2635 <= tau <= 131072 MCS in 2D (L=512), and
2048 <= tau <= 65536 MCS in 3D (L=128). These are 72 parameter points and
323500 trajectories. sampling_grid.tsv gives the durations and sample counts.

Fig. S3 varies the lower fitting cutoff from 512 to 8192 MCS.
data/window_trajectories.tsv supplies the 40000 additional trajectories at
10 parameter points needed for this comparison; its grid is
data/window_sampling_grid.tsv. Combine this file with data/trajectories.tsv
to reproduce the full cutoff scan.

data/size_trajectories.tsv contains the larger-lattice comparison data.
data/size_sampling_grid.tsv gives their counts. A single trajectory supplies
both cumulants; it must not be counted twice. The component exports within
the preserved analysis directories are inputs to the supplied scripts, not
additional observations to concatenate with data/trajectories.tsv.

c1 = mean(W)/L^d - delta_f; c2 = sample_var(W, ddof=1)/L^d.
The 3D reference is delta_f=-0.29697775299765183 with standard error
1.267188180139219e-6. Its independent replicas and original equilibrium JLD2
files are included. The common reference uncertainty is retained across all
durations and both protocols. The 2D reference and fixed D512 subtraction
are supplied in the reference tables and applied exactly as in the SM.

The fitted forms are A*tau^(-a) and A*tau^(-a)+B/tau, with A>=0 and signed B.
The two-power exponent domain is 0<a<1. The covariance is held fixed at its
sample-moment estimate; it is not rescaled by the fitting residuals. Nominal
95% profile intervals use delta chi-square=3.841458820694124. An interval
reaching a=1 has no resolved upper endpoint within this domain.

GETTING STARTED
---------------
Use Python 3.10 or newer with NumPy, pandas, SciPy, and Matplotlib.
requirements.txt records the versions used for the packaged results.

1. Verify the complete archive and independently refit the principal data:

   python reproduce_checks.py

   This verifies SHA256SUMS.txt before analysis, checks the exported trajectory
   counts and moments, reconstructs the original reference covariance, and
   independently reproduces the principal fitted exponents, profile intervals,
   and chi-square values. It does not modify packaged files.

2. Recalculate the bootstrap statistics and pointwise intervals:

   python R1_point_by_point_revision/numerics/major5_replication_20261014/presentation_20261015/refresh_statistics.py

   The fixed random seeds generate 20000 Gaussian bootstrap samples per fitted
   null model and 2000 whole-trajectory resamples. Each bootstrap fit refits all
   free parameters. The three tables are fit_statistics.tsv,
   model_comparison.tsv, and trajectory_background_2d.tsv in that directory.
   point_intervals.tsv supplies all principal pointwise error bars; the NPZ
   files retain the bootstrap realizations used in the tests and intervals.

3. Recalculate the common-window scan and all three publication figures:

   python R1_point_by_point_revision/numerics/major5_replication_20261014/plot_combined_submission.py

   PDFs and PNGs are written to the presentation_20261015/figures directory.
   Figs. S1-S2 show the eighteen durations used in each principal fit.
   Dashed curves fit a single power with a free exponent; solid curves fit the
   two-term form with the exponent fixed to the theoretical prediction.
   figure_points.tsv and figure_curves.tsv preserve every displayed value.
   window_profiles.tsv contains the lower-cutoff scan in Fig. S3. The size
   comparison uses the supplied matched-duration data at L=1024 in 2D and
   L=192 in 3D.

Commands 2 and 3 overwrite the corresponding derived results in the extracted
copy. Reverify the distributed SHA256SUMS before running them. Small differences
in final floating-point digits can arise across numerical-library versions.

SAMPLING CODE
-------------
The original IsingV2 Julia module, kernels, work estimator, protocols, tests,
and Julia dependency specification are included under:
R1_point_by_point_revision/numerics/major5_replication_20261014/code/

The code uses checkerboard Metropolis sweeps, J_i=0.5, J_f=1, h=0, the listed
critical temperatures, and 500 preparation sweeps. The complete work and
energy exports are sufficient to reproduce every analysis without a GPU.
The Julia sampling module requires a compatible NVIDIA GPU and CUDA.jl.
Batch tables retain sampling seeds and payload hashes where available.
Exact stochastic realizations depend on the Julia/CUDA versions and RNG state;
the supplied trajectory exports determine the reported statistical results.

The numeric directory names are retained so that relative imports and data
paths remain valid. The publication entry points are the three commands above;
other Python modules supply imported numerical helpers.

CONTENTS AND INTEGRITY
----------------------
README.txt                         This guide
requirements.txt                   Python package versions
sampling_grid.tsv                  72-point principal sampling grid
data/trajectories.tsv               323500 principal-fit observations
data/window_sampling_grid.tsv      10 additional points for the cutoff scan
data/window_trajectories.tsv        40000 observations for those points
data/size_trajectories.tsv          Complete larger-size observations
reproduce_checks.py                Independent raw-data and principal-fit check
R1_point_by_point_revision/...      Analysis inputs, modules, results, figures,
                                   reference replicas, and sampling code
SHA256SUMS.txt                      SHA256 for every other archived file

No credentials, remote connection settings, or cloud instance-control programs
are included. The archive SHA256 is provided separately alongside the ZIP.

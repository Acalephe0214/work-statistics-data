"""Package the principal data and the data needed for the window comparison."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import tempfile
import zipfile
import pandas as pd

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
N=ROOT/'numerics/major5_replication_20261014'
F=ROOT/'numerics/major5_followup_20261010'
A=ROOT/'numerics/major5_audit_20261009'
P=N/'presentation_20261015'
DEST=ROOT/'ancillary/Major5_Data_and_Fits_20261020.zip'


def read(path):
    return pd.read_csv(path,sep='\t',float_precision='round_trip')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not DEST.exists(),f'Refusing to overwrite {DEST}'
    stage=Path(tempfile.mkdtemp(prefix='major5_package_stage_',dir=HERE))
    files=[]
    files += [F/name for name in ('audit_signed_background.py','audit_single_power.py',
        'joint_bootstrap_existing.py','bootstrap_model_comparison.py','bootstrap_fixed_theory.py')]
    files += [A/name for name in ('diagnose.py','diagnose_extension.py','audit_common_windows.py',
        'correction_diagnostics.py','extension_analysis/finite_size_reference_2d.tsv')]
    for d in (2,3):
        files += [F/f'analysis_d{d}/{name}' for name in ('points.tsv','samples.tsv','chunks.tsv','point_bootstrap.tsv')]
    files += [F/'analysis_size'/name for name in ('points.tsv','samples.tsv','size_pairs.tsv',
        'joint_size_checks.tsv','work_time_contrasts.tsv','figure_c2_bootstrap.tsv')]
    files += [N/'analysis'/name for name in ('points.tsv','new_samples.tsv','new_chunks.tsv',
        'new_points_julia.tsv','fits_single_power.tsv','fits_two_power.tsv','fit_residuals.tsv',
        'block_consistency.tsv','independent_fit_checks.tsv','summary_checks.tsv')]
    files += [N/'plot_combined_submission.py']
    files += [p for p in P.iterdir() if p.is_file() and p.suffix in ('.py','.tsv','.json','.npz')]
    files += [p for p in (P/'figures').iterdir() if p.suffix in ('.pdf','.png')]
    reference=ROOT/'deliveries/major5_raw_data_original_reference_20261011'
    files += [reference/'reference'/name for name in ('original_reference_replicas.tsv',
        'reference_values.tsv','finite_size_reference_2d.tsv')]
    files += sorted((reference/'raw/original_equilibrium_reference').glob('equilibrium_d3_L128_chunk*.jld2'))
    code_names=('IsingV2.jl','constants.jl','protocols.jl','finite_size_ising.jl',
        'kernels.jl','buffers.jl','sweeps.jl','work.jl','equilibrium.jl','experiments.jl',
        'scaling.jl','exact_markov_reference.jl','test_exact_markov_cpu.jl',
        'test_exact_markov_gpu.jl','test_work_protocol_gpu.jl','test_thermodynamics_cpu.jl',
        'test_finite_size_ising.jl','test_p_schedule.jl','Project.toml','Manifest.toml')
    files += [N/'code'/name for name in code_names]
    # Sampling seeds/configuration are data; no execution or shutdown drivers.
    files += [N/'tasks.tsv']
    files += [HERE/name for name in ('package_analysis.py','README.txt','reproduce_checks.py','requirements.txt')]
    assert len(files)==len(set(files)) and all(p.is_file() for p in files)
    for source in files:
        relative=Path(ROOT.name)/source.relative_to(ROOT)
        target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True)
        if source.suffix=='.tsv':
            table=read(source)
            if 'tau' in table.columns:
                table=table.loc[table.tau>=512]
            table.to_csv(target,sep='\t',index=False,float_format='%.17g')
        elif source.suffix=='.json':
            # Remove workstation-specific prefixes from archival metadata.
            target.write_text(source.read_text().replace(str(ROOT),ROOT.name))
        else:
            shutil.copyfile(source,target)
    for name in ('README.txt','reproduce_checks.py','requirements.txt'):
        shutil.copyfile(HERE/name,stage/name)

    data=stage/'data';data.mkdir()
    raw=[]
    for d,L in ((2,512),(3,128)):
        old=read(F/f'analysis_d{d}/samples.tsv').query('dataset=="pooled" and tau>=512').copy()
        old['d']=d;old['L']=L
        raw.append(old[['d','L','p','tau','index','W','E']])
    added=read(N/'analysis/new_samples.tsv').sort_values(['d','L','p','tau','chunk','index'])
    added['index']=added.groupby(['d','L','p','tau']).cumcount()+1
    raw.append(added[['d','L','p','tau','index','W','E']])
    raw=pd.concat(raw,ignore_index=True).sort_values(['d','L','p','tau','index'])
    assert len(raw)==363500 and not raw.duplicated(['d','L','p','tau','index']).any()
    main_raw=raw.loc[raw.tau>=2048]
    window_raw=raw.loc[raw.tau<2048]
    assert len(main_raw)==323500 and len(window_raw)==40000
    main_raw.to_csv(data/'trajectories.tsv',sep='\t',index=False,float_format='%.17g')
    window_raw.to_csv(data/'window_trajectories.tsv',sep='\t',index=False,float_format='%.17g')
    grid=main_raw.groupby(['d','L','p','tau']).size().rename('N').reset_index()
    window_grid=window_raw.groupby(['d','L','p','tau']).size().rename('N').reset_index()
    assert len(grid)==72 and len(window_grid)==10
    grid.to_csv(stage/'sampling_grid.tsv',sep='\t',index=False)
    window_grid.to_csv(data/'window_sampling_grid.tsv',sep='\t',index=False)
    size=read(F/'analysis_size/samples.tsv').query('dataset=="pooled"').copy()
    size=size.drop(columns='dataset').sort_values(['d','L','p','tau','index'])
    assert not size.duplicated(['d','L','p','tau','index']).any()
    size.to_csv(data/'size_trajectories.tsv',sep='\t',index=False,float_format='%.17g')
    size.groupby(['d','L','p','tau']).size().rename('N').reset_index().to_csv(
        data/'size_sampling_grid.tsv',sep='\t',index=False)
    # Record the hashes of the inputs actually distributed in this archive.
    for target in stage.rglob('*.json'):
        document=json.loads(target.read_text())
        updated=False
        for key in ('source_sha256','inputs','output_hashes'):
            if key in document:
                for name in document[key]:
                    archived=stage/name
                    if archived.is_file():
                        document[key][name]=sha(archived)
                        updated=True
        if updated:
            target.write_text(json.dumps(document,indent=2)+'\n')
    members=sorted(p for p in stage.rglob('*') if p.is_file())
    # The explicit allow-list excludes connection files, cloud scripts and refined references.
    forbidden=('connection.json','ssh_askpass','watchdog','supervise.py','shutdown_',
        'reference_precision','completed_backup.json','.pem','.key')
    for p in members:
        assert not any(s in str(p.relative_to(stage)) for s in forbidden),p
    manifest=''.join(f'{sha(p)}  {p.relative_to(stage)}\n' for p in members)
    (stage/'SHA256SUMS.txt').write_text(manifest)
    DEST.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(DEST,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for p in sorted(stage.rglob('*')):
            if p.is_file():archive.write(p,p.relative_to(stage))
    with zipfile.ZipFile(DEST) as archive:
        assert archive.testzip() is None
        for line in archive.read('SHA256SUMS.txt').decode().splitlines():
            h,name=line.split('  ',1)
            assert hashlib.sha256(archive.read(name)).hexdigest()==h
    archive_hash=sha(DEST)
    checksum=DEST.with_suffix('.zip.sha256')
    checksum.write_text(f'{archive_hash}  {DEST.name}\n')
    receipt=dict(archive=str(DEST),archive_sha256=archive_hash,bytes=DEST.stat().st_size,
        hashed_files=len(members),zip_members=len(members)+1,staging=str(stage),
        main_points=len(grid),main_trajectories=len(main_raw),
        window_additional_points=len(window_grid),
        window_additional_trajectories=len(window_raw),size_trajectories=len(size),
        zip_crc_pass=True,all_file_sha256_pass=True)
    (HERE/'package_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__':main()

"""Independent raw-trajectory and GLS reproduction from the extracted archive."""
from pathlib import Path
import hashlib
import json
import os

for name in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[name] = '1'
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar, brentq

ROOT = Path(__file__).resolve().parent
RUN = ROOT/'R1_point_by_point_revision/numerics/major5_replication_20261014'
P = RUN/'presentation_20261015'
THRESHOLD = 3.841458820694124
OFFSET = 5.5392487898209275e-6


def read(path):
    return pd.read_csv(path, sep='\t', float_precision='round_trip')


def hashfile(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def fit(t, y, C, double):
    """Whitened original power basis, solved by QR independently of helpers."""
    L = np.linalg.cholesky(C); v = np.linalg.solve(L, y)
    def at(a):
        X = t[:,None]**(-a)
        if double:
            X = np.column_stack([X[:,0], 1/t])
        U = np.linalg.solve(L, X)
        U /= np.linalg.norm(U, axis=0)
        Q, R = np.linalg.qr(U)
        b = np.linalg.solve(R, Q.T@v)
        if b[0] < 0:
            b[0] = 0.
            if double:
                b[1] = U[:,1]@v
        return float(np.sum((v-U@b)**2))
    end = 1-1e-6 if double else 2.
    grid = np.linspace(1e-6, end, 1501)
    values = np.array([at(a) for a in grid])
    candidates = [(values[0],grid[0]),(values[-1],grid[-1])]
    for i in range(1,len(grid)-1):
        if values[i] <= values[i-1] and values[i] <= values[i+1]:
            result = minimize_scalar(at,bounds=(grid[i-1],grid[i+1]),
                method='bounded',options={'xatol':1e-13})
            candidates.append((result.fun,result.x))
    bestq,besta = min(candidates)
    f = lambda a: at(a)-bestq-THRESHOLD
    low = 0. if f(grid[0])<=0 else brentq(f,grid[0],besta,xtol=1e-12)
    high = (1. if double else end) if f(end)<=0 else brentq(f,besta,end,xtol=1e-12)
    return dict(a=besta,low95=low,high95=high,chi2=bestq),at


def main():
    lines=(ROOT/'SHA256SUMS.txt').read_text().splitlines()
    for line in lines:
        expected,name=line.split('  ',1)
        path=ROOT/name
        assert path.is_file() and hashfile(path)==expected, name
    main_raw=read(ROOT/'data/trajectories.tsv')
    window_raw=read(ROOT/'data/window_trajectories.tsv')
    raw=pd.concat([main_raw,window_raw],ignore_index=True)
    grid=read(ROOT/'sampling_grid.tsv')
    window_grid=read(ROOT/'data/window_sampling_grid.tsv')
    assert len(main_raw)==323500 and len(grid)==72 and main_raw.tau.min()>=2048
    assert len(window_raw)==40000 and len(window_grid)==10
    assert window_raw.tau.between(512,2047).all()
    assert not raw.duplicated(['d','L','p','tau','index']).any()
    assert np.isfinite(raw[['W','E']]).all().all()
    assert grid.N.sum()==323500 and window_grid.N.sum()==40000
    ref=read(ROOT/'R1_point_by_point_revision/deliveries/major5_raw_data_original_reference_20261011/reference/original_reference_replicas.tsv').delta_f.to_numpy()
    rf=ref.mean(); sf=ref.std(ddof=1)/np.sqrt(len(ref))
    assert abs(rf-(-.29697775299765183))<1e-14
    assert abs(sf-1.267188180139219e-6)<1e-17
    points=read(P/'final_points_all_durations.tsv')
    results=[]; max_moment_error=0.
    for (d,L,p,tau),g in raw.groupby(['d','L','p','tau'],sort=True):
        r=points[(points.d==d)&(points.L==L)&(points.p==p)&(points.tau==tau)].iloc[0]
        x=g.W.to_numpy(); n=len(x); v=x.var(ddof=1); V=L**d
        reconstructed=dict(mean_w=x.mean()/V,se_mean_w=np.sqrt(v/n)/V,c2=v/V,
            se_c2_moment=np.sqrt((np.mean((x-x.mean())**4)-(n-3)/(n-1)*v*v)/n)/V)
        assert n==r.N
        for name,value in reconstructed.items():
            error=abs(value-r[name]); max_moment_error=max(max_moment_error,error)
            assert error < 1e-12+abs(value)*1e-10,(d,p,tau,name,error)
    table=read(P/'fit_statistics.tsv')
    for d in (2,3):
        for p in (1.,1.2):
            rows=points[(points.d==d)&(points.p==p)&(points.tau>=2048)].sort_values('tau')
            t=rows.tau.to_numpy(dtype=float)
            assert len(t)==18
            for obs in ('c1','c2'):
                if obs=='c1':
                    y=rows.mean_w.to_numpy()-rows.delta_f.to_numpy()-(OFFSET if d==2 else 0)
                    C=np.diag(rows.se_mean_w.to_numpy()**2)+(sf**2 if d==3 else 0)
                else:
                    y=rows.c2.to_numpy();C=np.diag(rows.se_c2_moment.to_numpy()**2)
                saved=table[(table.d==d)&(table.p==p)&(table.observable==obs)].iloc[0]
                for double in (False,True):
                    result,fun=fit(t,y,C,double)
                    columns=('a_free','free_low95','free_high95','chi2_free') if double else ('a_single','single_low95','single_high95','chi2_single')
                    errors={key:abs(result[key]-float(saved[col])) for key,col in zip(result,columns)}
                    assert max(errors.values())<2e-5,(d,p,obs,double,errors)
                    if double:
                        error=abs(fun(float(saved.alpha))-float(saved.chi2_fixed))
                        assert error<1e-6
                        errors['chi2_fixed']=error
                    results.append(dict(d=d,p=p,observable=obs,model='two' if double else 'single',
                        a=result['a'],low95=result['low95'],high95=result['high95'],max_error=max(errors.values())))
    print(json.dumps(dict(verified_files=len(lines),principal_points=len(grid),
        principal_trajectories=len(main_raw),window_additional_points=len(window_grid),
        window_additional_trajectories=len(window_raw),max_moment_error=max_moment_error,
        max_fit_error=max(r['max_error'] for r in results),fits=results),indent=2))
    print('PASS: archive integrity, complete raw moments, original reference and all principal fits.')


if __name__=='__main__':
    main()

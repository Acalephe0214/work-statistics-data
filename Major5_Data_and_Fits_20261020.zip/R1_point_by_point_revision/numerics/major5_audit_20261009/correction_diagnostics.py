"""Exploratory, RG-motivated correction tests with new-data prediction.

Models are not replacements for the primary two-term profile analysis.
The leading exponent is fixed to the manuscript prediction. The correction
power is fixed independently: omega*p*nu/(1+p*z*nu), or p/(1+p*z*nu) for
an analytic thermal-scaling-field correction. Fits to archived data predict
independently sampled extension points. Shared Delta F covariance is kept.
No correction exponent is selected by scanning it against the data.
"""
from itertools import combinations
import json
import numpy as np
from diagnose import write_table, chi2_sf
from diagnose_extension import OUT, load_points
from diagnose import read_table


def linear_fit(X, y, C, nonnegative=(0, 1)):
    L = np.linalg.cholesky(C)
    whitening = np.linalg.solve(L, np.eye(len(y)))
    U = whitening @ X
    scale = np.linalg.norm(U, axis=0)
    V = U / scale
    v = whitening @ y
    choices = []
    for nzero in range(len(nonnegative) + 1):
        for zero in combinations(nonnegative, nzero):
            active = [j for j in range(X.shape[1]) if j not in zero]
            beta = np.zeros(X.shape[1])
            beta[active] = np.linalg.lstsq(V[:, active], v, rcond=None)[0]
            if any(beta[j] < -1e-12 for j in nonnegative):
                continue
            coef = beta / scale
            linear_map = np.zeros((len(beta), len(y)))
            linear_map[active, :] = (np.linalg.pinv(V[:, active]) @ whitening) / scale[active, None]
            cov = linear_map @ C @ linear_map.T
            chi = float(np.sum((v - V @ beta)**2))
            choices.append((chi, coef, cov, linear_map, len(active)))
    return min(choices, key=lambda x: x[0])


def model_matrix(t, alpha, delta=None):
    columns = [t**(-alpha), 1/t]
    if delta is not None:
        columns.append(t**(-alpha-delta))
    return np.column_stack(columns)


def get_values(group, obs, finite_offsets):
    y = np.array([r[obs] for r in group])
    if obs == "c1":
        if group[0]["d"] == 2:
            y -= np.array([finite_offsets[r["L"]] for r in group])
        sf = group[0]["se_delta_f"]
        C = np.diag([r["se_mean_w"]**2 for r in group]) + sf**2
    else:
        sf = 0.
        C = np.diag([r["se_c2_moment"]**2 for r in group])
    return y, C, sf


def main():
    points = load_points()
    offsets = {int(r["L"]): float(r["finite_size_offset"])
               for r in read_table(OUT / "finite_size_reference_2d.tsv")}
    rows, predictions, curves = [], [], []
    for d, L in ((2, 512), (3, 128)):
        nu, z = (1., 2.1665) if d == 2 else (.629912, 2.0245)
        omega = 2. if d == 2 else .832
        for p in (1., 1.2):
            alpha = p*d*nu/(1+p*z*nu)
            models = [("fixed_two_positive", None, (0, 1)),
                      ("fixed_two_signedB", None, (0,)),
                      ("fixed_omega_positiveB", omega*p*nu/(1+p*z*nu), (0, 1)),
                      ("fixed_omega_signedB", omega*p*nu/(1+p*z*nu), (0,)),
                      ("fixed_analytic_positiveB", p/(1+p*z*nu), (0, 1))]
            for obs in ("c1", "c2"):
                original = sorted([r for r in points if
                    (r["dataset"],r["d"],r["L"],r["p"]) == ("archived",d,L,p)],key=lambda r:r["tau"])
                allg = sorted([r for r in points if
                    (r["dataset"],r["d"],r["L"],r["p"]) == ("pooled",d,L,p)],key=lambda r:r["tau"])
                hold = sorted([r for r in points if
                    (r["dataset"],r["d"],r["L"],r["p"]) == ("extension",d,L,p)
                    and r["tau"] > max(o["tau"] for o in original)],key=lambda r:r["tau"])
                for dataset, group in (("archived",original),("pooled",allg)):
                    for minimum_time in (128,512,1024,2048):
                        g = [r for r in group if r["tau"] >= minimum_time]
                        if len(g) < 5:
                            continue
                        t = np.array([r["tau"] for r in g],float)
                        y,C,sf = get_values(g,obs,offsets)
                        for name,delta,nonneg in models:
                            X = model_matrix(t,alpha,delta)
                            chi,beta,cov,mapping,nactive = linear_fit(X,y,C,nonneg)
                            coeff = list(beta) + ([0.] if len(beta)==2 else [])
                            errors = list(np.sqrt(np.diag(cov))) + ([0.] if len(beta)==2 else [])
                            first = coeff[0]*t**(-alpha)
                            corr = np.zeros(len(t)) if delta is None else coeff[2]*t**(-alpha-delta)
                            row = dict(dataset=dataset,d=d,L=L,p=p,observable=obs,
                                model=name,tau_min=t[0],tau_max=t[-1],n=len(t),alpha=alpha,
                                delta=delta if delta is not None else 0.,A=coeff[0],B=coeff[1],C=coeff[2],
                                se_A=errors[0],se_B=errors[1],se_C=errors[2],
                                chi2=chi,dof=len(t)-nactive,pvalue=chi2_sf(chi,len(t)-nactive),
                                correction_ratio_first=corr[0]/first[0] if first[0]>0 else np.nan,
                                correction_ratio_last=corr[-1]/first[-1] if first[-1]>0 else np.nan)
                            rows.append(row)
                            if minimum_time == 128:
                                for tt in np.geomspace(128,131072 if d==2 else 65536,180):
                                    xx=model_matrix(np.array([tt]),alpha,delta)[0]
                                    curves.append(dict(dataset=dataset,d=d,L=L,p=p,observable=obs,model=name,
                                        tau=tt,mean=float(xx@beta),se=float(np.sqrt(max(0.,xx@cov@xx)))))
                            if dataset=="archived" and minimum_time==128 and hold:
                                th=np.array([r["tau"] for r in hold],float)
                                yh,Ch,sh=get_values(hold,obs,offsets)
                                Xh=model_matrix(th,alpha,delta)
                                # Only c1 in 3D has a shared uncertain Delta F.
                                cross=np.full((len(hold),len(g)),sf*sh)
                                Cpred=Ch+Xh@cov@Xh.T-cross@mapping.T@Xh.T-Xh@mapping@cross.T
                                residual=yh-Xh@beta
                                predchi=float(residual@np.linalg.solve(Cpred,residual))
                                predictions.append(dict(d=d,L=L,p=p,observable=obs,model=name,
                                    tau_train_max=t[-1],n_test=len(hold),
                                    prediction_chi2=predchi,dof=len(hold),pvalue=chi2_sf(predchi,len(hold)),
                                    max_abs_z=float(np.max(np.abs(residual)/np.sqrt(np.diag(Cpred))))))

    write_table(OUT/"correction_fits.tsv",rows)
    write_table(OUT/"correction_predictions.tsv",predictions)
    write_table(OUT/"correction_curves.tsv",curves)
    for r in rows:
        if r["observable"]=="c1" and r["tau_min"]==128 and r["dataset"]=="pooled":
            print("FIT",json.dumps(r),flush=True)
    for r in predictions:
        if r["observable"]=="c1": print("PREDICTION",json.dumps(r),flush=True)


if __name__ == "__main__":
    main()

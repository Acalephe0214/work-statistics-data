"""Prespecified size, overlap, and fit-window diagnostics for stage 1.

Primary model: A*tau**(-alpha)+B/tau, A,B >= 0. Fits retain the common
free-energy covariance. Reference-free fits use adjacent work differences.
The L=192 scan has only 3 times: it cannot identify a 3-parameter two-term
model after elimination of its unknown constant free-energy reference.
"""
import csv
import json
import math
from pathlib import Path
import numpy as np
from diagnose import read_table, write_table, profile, chi2_sf

HERE = Path(__file__).resolve().parent
OUT = HERE / "extension_analysis"

def load_points():
    result = []
    integer = {"d", "L", "tau", "N", "n_chunks"}
    for row in read_table(OUT / "points.tsv"):
        result.append({k: v if k == "dataset" else int(v) if k in integer else float(v)
                       for k, v in row.items()})
    return result

def covariance(group, observable):
    if observable == "c1":
        sf = group[0]["se_delta_f"]
        return (np.diag([r["se_mean_w"]**2 for r in group])
                + sf**2 * np.ones((len(group),len(group))))
    return np.diag([r["se_c2_moment"]**2 for r in group])

def log_slope(group, observable):
    t=np.array([r["tau"] for r in group],float)
    y=np.array([r[observable] for r in group])
    C=covariance(group,observable)/np.outer(y,y)
    X=np.column_stack([np.ones(len(t)),-np.log(t)])
    precision=np.linalg.inv(C)
    pcov=np.linalg.inv(X.T@precision@X)
    coef=pcov@X.T@precision@np.log(y)
    resid=np.log(y)-X@coef
    return dict(alpha=coef[1],se_alpha=math.sqrt(pcov[1,1]),
                chi2=float(resid@precision@resid),dof=len(t)-2)

def main():
    rows=load_points()
    index={(r["dataset"],r["d"],r["L"],r["p"],r["tau"]):r for r in rows}
    overlaps=[]; sizes=[]; differences=[]; slopes=[]; fits=[]; powerfits=[]
    for r in rows:
        if r["dataset"] != "extension": continue
        key=("archived",r["d"],r["L"],r["p"],r["tau"])
        if key in index:
            old=index[key]
            overlaps.append(dict(d=r["d"],L=r["L"],p=r["p"],tau=r["tau"],
                z_mean_w=(r["mean_w"]-old["mean_w"])/math.hypot(r["se_mean_w"],old["se_mean_w"]),
                z_c2=(r["c2"]-old["c2"])/math.hypot(r["se_c2_moment"],old["se_c2_moment"])))

    for p in (1.0,1.2):
        for tau in (16384,32768,65536,131072):
            small=index[("extension",2,512,p,tau)]
            large=index[("extension",2,1024,p,tau)]
            se=math.hypot(small["se_mean_w"],large["se_mean_w"])
            df=small["delta_f"]-large["delta_f"]
            dw=small["mean_w"]-large["mean_w"]
            sizes.append(dict(d=2,p=p,tau=tau,L_small=512,L_large=1024,
                delta_c1=small["c1"]-large["c1"],se_delta_c1=se,
                z_c1=(small["c1"]-large["c1"])/se,
                delta_mean_w=dw,z_mean_w=dw/se,
                minus_delta_free_energy=-df,
                z_c2=(small["c2"]-large["c2"])/math.hypot(small["se_c2_moment"],large["se_c2_moment"])))

    t=np.array([16384,32768,65536],float)
    D=np.eye(3)[:-1]-np.eye(3)[1:]
    diff_vectors={}; diff_covariances={}
    for L in (128,192):
        group=[index[("extension",3,L,1.0,int(tau))] for tau in t]
        w=np.array([r["mean_w"] for r in group])
        C=np.diag([r["se_mean_w"]**2 for r in group])
        dw=D@w; cov=D@C@D.T
        diff_vectors[L]=dw; diff_covariances[L]=cov
        gradient=np.array([1/dw[0],-1/dw[1]])/math.log(2)
        alpha=math.log(dw[0]/dw[1])/math.log(2)
        se=math.sqrt(gradient@cov@gradient)
        differences.append(dict(kind="three_time_effective_power",L=L,
            delta_w_16k_32k=dw[0],delta_w_32k_65k=dw[1],alpha=alpha,
            se_alpha=se,chi2=math.nan,dof=0,pvalue=math.nan))
    deviation=diff_vectors[128]-diff_vectors[192]
    cov=diff_covariances[128]+diff_covariances[192]
    chi=float(deviation@np.linalg.solve(cov,deviation))
    differences.append(dict(kind="size_difference_of_differences",L=0,
        delta_w_16k_32k=deviation[0],delta_w_32k_65k=deviation[1],
        alpha=math.nan,se_alpha=math.nan,chi2=chi,dof=2,pvalue=chi2_sf(chi,2)))

    selections=[("archived",2,512,1.0),("archived",2,512,1.2),
                ("archived",3,128,1.0),("archived",3,128,1.2),("pooled",2,512,1.0),
                ("pooled",2,512,1.2),("pooled",3,128,1.0),("pooled",3,128,1.2),
                ("extension",2,1024,1.0),("extension",2,1024,1.2)]
    for dataset,d,L,p in selections:
        group=sorted([r for r in rows if (r["dataset"],r["d"],r["L"],r["p"])==
                      (dataset,d,L,p)],key=lambda r:r["tau"])
        nu,z=(1.,2.1665) if d==2 else (.629912,2.0245)
        theory=p*d*nu/(1+p*z*nu)
        for observable in ("c1","c2"):
            all_t=np.array([r["tau"] for r in group],float)
            y=np.array([r[observable] for r in group]); C=covariance(group,observable)
            for i in range(len(group)-1):
                grad=np.zeros(len(group)); grad[i]=1/y[i];grad[i+1]=-1/y[i+1]
                logratio=math.log(all_t[i+1]/all_t[i])
                slopes.append(dict(dataset=dataset,d=d,L=L,p=p,observable=observable,
                    tau_lo=all_t[i],tau_hi=all_t[i+1],
                    alpha=-math.log(y[i+1]/y[i])/logratio,
                    se_alpha=math.sqrt(grad@C@grad)/logratio,theory=theory))
            if dataset=="extension":
                powerfits.append(dict(dataset=dataset,d=d,L=L,p=p,observable=observable,
                    tau_min=all_t[0],tau_max=all_t[-1],theory=theory,**log_slope(group,observable)))
            # All nested late-time windows with at least 4 points, rather
            # than choosing the first window compatible with the prediction.
            for start in range(len(group)-3):
                tt=all_t[start:]; yy=y[start:]; cc=C[start:,start:]
                result=profile(tt,yy,cc,theory)
                fits.append(dict(dataset=dataset,d=d,L=L,p=p,observable=observable,
                    model="positive_two_term",tau_min=tt[0],tau_max=tt[-1],
                    min_L_over_xi=min(r["L_over_xi"] for r in group[start:]),
                    theory=theory,**result))
                if observable=="c1" and len(tt)>=5:
                    fits.append(dict(dataset=dataset,d=d,L=L,p=p,observable=observable,
                        model="reference_free_contrast",tau_min=tt[0],tau_max=tt[-1],
                        min_L_over_xi=min(r["L_over_xi"] for r in group[start:]),
                        theory=theory,**profile(tt,yy,cc,theory,contrast=True)))
            # Explicit guardrail sensitivity on the same pooled 3D grid.
            if dataset=="pooled" and d==3:
                for cutoff in (4.,6.,8.):
                    g=[r for r in group if r["L_over_xi"]>=cutoff]
                    tt=np.array([r["tau"] for r in g],float)
                    yy=np.array([r[observable] for r in g])
                    cc=covariance(g,observable)
                    fits.append(dict(dataset=dataset,d=d,L=L,p=p,observable=observable,
                        model=f"positive_two_term_sizecut_{cutoff:g}",tau_min=tt[0],tau_max=tt[-1],
                        min_L_over_xi=min(r["L_over_xi"] for r in g),theory=theory,
                        **profile(tt,yy,cc,theory)))

    save={"overlap_checks.tsv":overlaps,"size_checks_2d.tsv":sizes,
          "reference_free_3d.tsv":differences,"local_slopes.tsv":slopes,
          "profiles.tsv":fits,"tail_power_fits.tsv":powerfits}
    for name,data in save.items(): write_table(OUT/name,data)
    print("OVERLAP",json.dumps(overlaps),flush=True)
    print("SIZE2D",json.dumps(sizes),flush=True)
    print("CONTRAST3D",json.dumps(differences),flush=True)
    print("TAIL_POWER",json.dumps(powerfits),flush=True)
    for r in fits:
        if r["observable"]=="c1" and (r["tau_min"]==128 or r["dataset"]=="extension"
            or r["d"]==3 and r["tau_min"] in (512,1024,2048,4096)):
            print("FIT",json.dumps(r),flush=True)

if __name__=="__main__": main()

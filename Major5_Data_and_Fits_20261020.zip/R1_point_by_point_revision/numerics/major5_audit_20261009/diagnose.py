"""Independent NumPy analysis of the audited raw-sample summaries.

The primary model remains A*tau**(-a)+B/tau with A,B>=0. Signed B and a
fixed-theory correction term are diagnostic alternatives, never used to
silently replace the primary model or select a passing time window.
"""
import csv
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
OUT = HERE / "results"

def read_table(path):
    with path.open() as stream:
        return list(csv.DictReader(stream, delimiter="\t"))

def write_table(path, rows):
    with path.open("w") as stream:
        w=csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter="\t")
        w.writeheader(); w.writerows(rows)

def golden(f, a, b):
    r=(math.sqrt(5)-1)/2
    x=b-r*(b-a); y=a+r*(b-a); fx=f(x); fy=f(y)
    for _ in range(75):
        if fx<fy:
            b,y,fy=y,x,fx; x=b-r*(b-a); fx=f(x)
        else:
            a,x,fx=x,y,fy; y=a+r*(b-a); fy=f(y)
    return (a+b)/2

def chi2_sf(x, dof):
    """Regularized upper incomplete gamma; independent of SciPy."""
    if x<=0: return 1.0
    a=dof/2; z=x/2; pref=math.exp(-z+a*math.log(z)-math.lgamma(a))
    if z<a+1:
        term=1/a; total=term
        for k in range(1,10000):
            term*=z/(a+k); total+=term
            if abs(term)<abs(total)*1e-14: break
        return max(0.0,1-total*pref)
    b=z+1-a; c=1e300; d=1/b; h=d
    for k in range(1,10000):
        an=-k*(k-a); b+=2; d=an*d+b
        if abs(d)<1e-300: d=1e-300
        c=b+an/c
        if abs(c)<1e-300: c=1e-300
        d=1/d; factor=d*c; h*=factor
        if abs(factor-1)<1e-14: break
    return max(0.0,min(1.0,pref*h))

def make_fit(t, y, covariance, contrast=False, signed_B=False):
    D=np.eye(len(t))
    if contrast: D=D[:-1]-D[1:]
    lower=np.linalg.cholesky(D@covariance@D.T)
    whiten=np.linalg.solve(lower,D)
    yy=whiten@y
    def fit(a):
        X=whiten@np.column_stack([t**(-a),1/t])
        norms=np.linalg.norm(X,axis=0); X=X/norms
        coeff=np.linalg.lstsq(X,yy,rcond=None)[0]
        candidates=[]
        if coeff[0]>=0 and (signed_B or coeff[1]>=0): candidates.append(coeff)
        candidates += [np.array([max(0,X[:,0]@yy),0]),
                       np.array([0,X[:,1]@yy if signed_B else max(0,X[:,1]@yy)])]
        best=min(candidates,key=lambda c:np.sum((yy-X@c)**2))
        return float(np.sum((yy-X@best)**2)),best/norms
    return fit, len(yy)

def profile(t,y,C,theory,contrast=False,signed_B=False):
    fit,n=make_fit(t,y,C,contrast,signed_B)
    grid=np.linspace(.05,.98,1201)
    vals=np.array([fit(a)[0] for a in grid]); j=int(vals.argmin())
    best=grid[j] if j in (0,len(grid)-1) else golden(lambda a:fit(a)[0],grid[j-1],grid[j+1])
    minimum,coeff=fit(best)
    cutoff=3.841458820694124
    accepted=grid[vals-minimum<=cutoff]
    low=float(accepted[0]) if len(accepted) else best
    high=float(accepted[-1]) if len(accepted) else best
    fixed,ab=fit(theory)
    return dict(a=best,low95_grid=low,high95_grid=high,A=float(coeff[0]),B=float(coeff[1]),
                chi2_min=minimum,dof_free=n-3,chi2_theory=fixed,dof_theory=n-2,
                theory_goodness_p=chi2_sf(fixed,n-2),delta_theory=fixed-minimum,
                A_theory=float(ab[0]),B_theory=float(ab[1]),n_constraints=n)

def main():
    rows=read_table(OUT/"points.tsv")
    profiles=[]; slopes=[]; code_quality=[]
    for d in (2,3):
      Lmax=512 if d==2 else 128
      nu,z=(1.,2.1665) if d==2 else (.629912,2.0245)
      for L in sorted({int(r["L"]) for r in rows if int(r["d"])==d}):
       for p in (1.,1.2):
        group=sorted([r for r in rows if int(r["d"])==d and int(r["L"])==L and float(r["p"])==p],key=lambda r:int(r["tau"]))
        t=np.array([float(r["tau"]) for r in group]); theory=p*d*nu/(1+p*z*nu)
        meanvar=np.array([float(r["se_mean_w"])**2 for r in group]); sf=float(group[0]["se_delta_f"])
        for obs in ("c1","c2"):
            y=np.array([float(r[obs]) for r in group])
            C=(np.diag(meanvar)+sf*sf*np.ones((len(t),len(t)))) if obs=="c1" else np.diag([float(r["se_c2_moment"])**2 for r in group])
            for i in range(len(t)-1):
                slope=-np.log(y[i+1]/y[i])/np.log(t[i+1]/t[i])
                e=np.zeros(len(t)); e[i]=1/y[i]; e[i+1]=-1/y[i+1]
                se=np.sqrt(e@C@e)/np.log(t[i+1]/t[i])
                slopes.append(dict(d=d,L=L,p=p,observable=obs,tau_lo=t[i],tau_hi=t[i+1],a_eff=slope,se_a_eff=se,theory=theory))
            starts=range(min(5,len(t)-4))
            for start in starts:
                tt=t[start:]; yy=y[start:]; cc=C[start:,start:]
                result=profile(tt,yy,cc,theory)
                row=dict(d=d,L=L,p=p,observable=obs,model="positive_two_term",tau_min=tt[0],tau_max=tt[-1],theory=theory,**result)
                profiles.append(row)
                if obs=="c1" and len(tt)>=6:
                    profiles.append(dict(d=d,L=L,p=p,observable=obs,model="reference_free_contrast",tau_min=tt[0],tau_max=tt[-1],theory=theory,**profile(tt,yy,cc,theory,contrast=True)))
                if start==0 and L==Lmax:
                    print(json.dumps(row),flush=True)
                    profiles.append(dict(d=d,L=L,p=p,observable=obs,model="signed_B_diagnostic",tau_min=tt[0],tau_max=tt[-1],theory=theory,**profile(tt,yy,cc,theory,signed_B=True)))
        chi=sum(float(r["chunk_chi2"]) for r in group); dof=sum(int(r["chunk_dof"]) for r in group)
        ratios=[float(r["se_mean_w_chunks"])/float(r["se_mean_w"]) for r in group]
        code_quality.append(dict(d=d,L=L,p=p,chunk_chi2=chi,dof=dof,pvalue=chi2_sf(chi,dof),median_chunk_iid_se_ratio=float(np.median(ratios))))
    write_table(OUT/"independent_profiles.tsv",profiles)
    write_table(OUT/"effective_exponents.tsv",slopes)
    write_table(OUT/"chunk_consistency.tsv",code_quality)
    print("Chunk consistency",json.dumps(code_quality),flush=True)

if __name__=="__main__": main()

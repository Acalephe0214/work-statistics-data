"""Post-hoc COMMON lower-time cutoffs for all eight primary exponent fits.

Keep all original data untouched. Primary model and covariance are unchanged:
A*tau**(-a) + B/tau, A,B >= 0, plus the exactly known D_L for 2D c1.
Each cutoff is used for every d,p,c_n, without group-specific selection.
Intervals are nominal profile-likelihood intervals conditional on 0<a<1;
a bound reaching zero is explicitly reported as unidentified, not as 0.05.
"""
import math
import numpy as np
from diagnose import read_table, write_table, make_fit, golden, chi2_sf
from diagnose_extension import OUT, load_points, covariance

THRESHOLD = 3.841458820694124
CUTS = (128, 256, 512, 1024, 2048, 4096, 8192)


def bisect_root(fun, left, right):
    fl = fun(left)
    for _ in range(60):
        mid = (left + right) / 2
        fm = fun(mid)
        if fl * fm <= 0:
            right = mid
        else:
            left, fl = mid, fm
    return (left + right) / 2


def refined_profile(t, y, C, theory, contrast=False):
    fit, n = make_fit(t, y, C, contrast=contrast)
    # Work in the open interval: at a=0 a contrast annihilates the
    # critical column, and at a=1 the two amplitude columns coincide.
    grid = np.linspace(1.e-6, 1.-1.e-6, 2401)
    values = np.array([fit(a)[0] for a in grid])
    j = int(values.argmin())
    best = (grid[j] if j in (0, len(grid)-1) else
            golden(lambda a: fit(a)[0], grid[j-1], grid[j+1]))
    minimum, ab = fit(best)
    # Refine every crossing, preserving possibly disconnected intervals.
    f = lambda a: fit(a)[0] - minimum - THRESHOLD
    accepted = values - minimum <= THRESHOLD
    boundaries = [0.]
    boundaries += [bisect_root(f, grid[i], grid[i+1])
                   for i in range(len(grid)-1) if accepted[i] != accepted[i+1]]
    boundaries += [1.]
    intervals = [(a,b) for a,b in zip(boundaries[:-1],boundaries[1:])
                 if f((a+b)/2) <= 0]
    assert intervals
    fixed, fixed_ab = fit(theory)
    return dict(a=best, low95=intervals[0][0], high95=intervals[-1][1],
        interval_components=len(intervals),
        lower_unidentified=intervals[0][0] == 0.,
        upper_unidentified=intervals[-1][1] == 1.,
        theory_in95=fixed-minimum <= THRESHOLD,
        chi2_min=minimum, dof_free=n-3,
        chi2_theory=fixed, dof_theory=n-2,
        goodness_p=chi2_sf(fixed,n-2), delta_theory=fixed-minimum,
        A=float(ab[0]), B=float(ab[1]),
        A_theory=float(fixed_ab[0]), B_theory=float(fixed_ab[1]))


def main():
    points = load_points()
    references = {int(r['L']): float(r['finite_size_offset'])
                  for r in read_table(OUT/'finite_size_reference_2d.tsv')}
    intervals = {(r['dataset'],int(r['d']),int(r['L']),float(r['p']),
                  int(r['tau']),r['observable']):r
                 for r in read_table(OUT/'bootstrap_intervals.tsv')}
    fits, residuals, summaries, contrasts = [], [], [], []
    # Primary: same LOWER cutoff, all available later times.
    # Sensitivity: same lower AND upper cutoff (old 3D maximum).
    for upper_name, upper in [('all_available',math.inf),('common_16384',16384)]:
        for cut in CUTS:
            here = []
            for d in (2,3):
                L = 512 if d == 2 else 128
                nu,z = (1.,2.1665) if d==2 else (.629912,2.0245)
                for p in (1.,1.2):
                    group=sorted([r for r in points if
                        (r['dataset'],r['d'],r['L'],r['p'])==('pooled',d,L,p)
                        and cut<=r['tau']<=upper],key=lambda r:r['tau'])
                    if len(group)<4:
                        continue
                    t=np.array([r['tau'] for r in group],float)
                    theory=p*d*nu/(1+p*z*nu)
                    for obs in ('c1','c2'):
                        offset=references[L] if d==2 and obs=='c1' else 0.
                        y=np.array([r[obs] for r in group])-offset
                        C=covariance(group,obs)
                        ans=refined_profile(t,y,C,theory)
                        base=dict(window=upper_name,cutoff=cut,d=d,L=L,p=p,
                            observable=obs,n_points=len(t),tau_min=t[0],
                            tau_max=t[-1],theory=theory,fixed_offset=offset)
                        row={**base,**ans}
                        fixed=ans['A_theory']*t**(-theory)+ans['B_theory']/t+offset
                        outside=0
                        for i,r in enumerate(group):
                            band=intervals[('pooled',d,L,p,r['tau'],obs)]
                            lo,hi=float(band['low95']),float(band['high95'])
                            inside=lo<=fixed[i]<=hi
                            outside+=not inside
                            residuals.append(dict(**base,tau=r['tau'],
                                value=r[obs],prediction=fixed[i],low95=lo,high95=hi,
                                prediction_in_point95=inside,
                                marginal_residual_z=(r[obs]-fixed[i])/math.sqrt(C[i,i])))
                        row['outside_pointwise95']=outside
                        fits.append(row); here.append(row)
                        if obs=='c1' and d==3 and len(group)>=5 and cut in (128,1024,2048):
                            contrasts.append({**base,**refined_profile(t,y,C,theory,contrast=True)})
            summaries.append(dict(window=upper_name,cutoff=cut,n_groups=len(here),
                theory_in95=sum(r['theory_in95'] for r in here),
                goodness_ge05=sum(r['goodness_p']>=.05 for r in here),
                all_eight_supported=len(here)==8 and all(r['theory_in95'] and
                    r['goodness_p']>=.05 for r in here),
                min_points=min((r['n_points'] for r in here),default=0),
                max_points=max((r['n_points'] for r in here),default=0),
                outside_pointwise95=sum(r['outside_pointwise95'] for r in here),
                total_points=sum(r['n_points'] for r in here)))
    write_table(OUT/'common_window_fits.tsv',fits)
    write_table(OUT/'common_window_residuals.tsv',residuals)
    write_table(OUT/'common_window_summary.tsv',summaries)
    write_table(OUT/'common_window_contrasts.tsv',contrasts)
    for row in summaries:
        print(row,flush=True)
    for r in fits:
        if r['window']=='all_available' and r['cutoff']==2048:
            print('COMMON2048',r,flush=True)
    for r in residuals:
        if r['window']=='all_available' and r['cutoff']==2048 and not r['prediction_in_point95']:
            print('OUTSIDE_POINTWISE',r,flush=True)


if __name__=='__main__':
    main()

"""Audit only: signed regular background and free-energy-reference sensitivity.

No input, manuscript, figure or existing analysis output is overwritten.
Same data/covariance, 0<a<1, A>=0, nominal profile threshold and cutoff scan.
For signed B use a stable log/t limiting basis near a=1; no finite upper
exponent bound is inferred when the profile reaches this open-domain limit.
"""
from pathlib import Path
import sys, json, hashlib
import numpy as np

HERE=Path(__file__).resolve().parent
AUDIT=HERE.parent/'major5_audit_20261009'
OUT=HERE/'analysis_signed_background_20261011'
sys.path.insert(0,str(AUDIT))
from diagnose import read_table, write_table, make_fit, golden, chi2_sf
from audit_common_windows import bisect_root
from correction_diagnostics import linear_fit, model_matrix

THRESHOLD=3.841458820694124

def signed_fit(t,y,C,contrast=False):
    D=np.eye(len(t))
    if contrast: D=D[:-1]-D[1:]
    W=np.linalg.solve(np.linalg.cholesky(D@C@D.T),D)
    v=W@y; logt=np.log(t/t[0]); u=1/t
    def fit(a):
        e=1-a
        h=u*(np.expm1(e*logt)/e if e else logt)
        X=W@np.column_stack([h,u])
        norms=np.linalg.norm(X,axis=0); V=X/norms
        b=np.linalg.lstsq(V,v,rcond=None)[0]
        if b[0]<0: b=np.array([0.,V[:,1]@v])
        coef=b/norms
        if e:
            AB=np.array([coef[0]/e/t[0]**e,coef[1]-coef[0]/e])
        else: AB=np.array([np.inf,-np.inf])
        return float(np.sum((v-V@b)**2)),AB
    return fit,len(v)

def profile(t,y,C,theory,signed=False,contrast=False):
    fit,n=signed_fit(t,y,C,contrast) if signed else make_fit(t,y,C,contrast)
    grid=np.linspace(1e-6,1-1e-6,1201)
    vals=np.array([fit(a)[0] for a in grid])
    candidates=[(vals[0],grid[0]),(vals[-1],grid[-1])]
    for j in range(1,len(grid)-1):
        if vals[j]<=vals[j-1] and vals[j]<=vals[j+1]:
            a=golden(lambda a:fit(a)[0],grid[j-1],grid[j+1])
            candidates.append((fit(a)[0],a))
    minimum,best=min(candidates)
    _,ab=fit(best); fixed,fab=fit(theory)
    fun=lambda a:fit(a)[0]-minimum-THRESHOLD
    accepted=vals-minimum<=THRESHOLD
    bounds=[0.]+[bisect_root(fun,grid[j],grid[j+1])
        for j in range(len(grid)-1) if accepted[j]!=accepted[j+1]]+[1.]
    ints=[(l,h) for l,h in zip(bounds[:-1],bounds[1:]) if fun((l+h)/2)<=0]
    assert ints
    return dict(a=best,low95=ints[0][0],high95=ints[-1][1],
        intervals=json.dumps(ints),upper_unidentified=ints[-1][1]==1.,
        lower_unidentified=ints[0][0]==0.,chi2_min=minimum,dof_free=n-3,
        chi2_theory=fixed,dof_theory=n-2,goodness_p=chi2_sf(fixed,n-2),
        free_goodness_p=chi2_sf(minimum,n-3),delta_theory=fixed-minimum,
        theory_in95=fixed-minimum<=THRESHOLD,A=ab[0],B=ab[1],
        A_theory=fab[0],B_theory=fab[1],A_zero=ab[0]==0.,B_zero=ab[1]==0.,
        A_theory_zero=fab[0]==0.,B_theory_zero=fab[1]==0.)

def inputs(rows,d,dataset,p,obs,cut,ref,offset):
    g=sorted([r for r in rows if r['dataset']==dataset and float(r['p'])==p
              and int(r['tau'])>=cut],key=lambda r:int(r['tau']))
    t=np.array([float(r['tau']) for r in g])
    if obs=='c1':
        ff,ss=ref if ref is not None else (float(g[0]['delta_f']),float(g[0]['se_delta_f']))
        y=np.array([float(r['mean_w']) for r in g])-ff-(offset if d==2 else 0.)
        C=np.diag([float(r['se_mean_w'])**2 for r in g])+ss**2
    else:
        y=np.array([float(r['c2']) for r in g])
        C=np.diag([float(r['se_c2_moment'])**2 for r in g])
    return t,y,C

def main():
    OUT.mkdir(exist_ok=True)
    files=[HERE/f'analysis_d{d}/points.tsv' for d in (2,3)]
    files += [HERE/'reference_precision/final_checks/pooled_reference.tsv',
              AUDIT/'extension_analysis/finite_size_reference_2d.tsv']
    data={d:read_table(files[d-2]) for d in (2,3)}
    new=read_table(files[2])[0]; newref=(float(new['delta_f']),float(new['SE']))
    offset=float(next(r for r in read_table(files[3]) if int(r['L'])==512)['finite_size_offset'])
    oldref=(float(data[3][0]['delta_f']),float(data[3][0]['se_delta_f']))
    fits=[]; checks=[]; contrasts=[]
    for d in (2,3):
      nu,z=(1.,2.1665) if d==2 else (.629912,2.0245)
      for dataset in ('prior','new_only','pooled'):
       for p in (1.,1.2):
        theory=p*d*nu/(1+p*z*nu)
        for obs in ('c1','c2'):
         scenarios=[('old',None)]
         if d==3 and obs=='c1': scenarios.append(('refined',newref))
         for scenario,ref in scenarios:
          for cut in (128,512,1024,2048,4096,8192):
           t,y,C=inputs(data[d],d,dataset,p,obs,cut,ref,offset)
           if len(t)<4: continue
           base=dict(d=d,dataset=dataset,p=p,observable=obs,reference=scenario,
               cutoff=cut,n_points=len(t),tau_min=t[0],tau_max=t[-1],theory=theory)
           for signed in (False,True):
            result=profile(t,y,C,theory,signed)
            fits.append(dict(**base,background='signed' if signed else 'positive',**result))
            if cut==2048:
                # Independent direct-basis bounded least squares at key exponents.
                L=np.linalg.cholesky(C); yy=np.linalg.solve(L,y)
                for a in (theory,result['a'],result['low95'],result['high95']):
                    if not 1e-5<a<1-1e-5:continue
                    X=np.linalg.solve(L,np.column_stack([t**(-a),1/t]))
                    scale=np.linalg.norm(X,axis=0); V=X/scale
                    Q,R=np.linalg.qr(V); b=np.linalg.solve(R,Q.T@yy)
                    cand=[np.array([0., V[:,1]@yy if signed else max(0.,V[:,1]@yy)]),
                          np.array([max(0.,V[:,0]@yy),0.])]
                    if b[0]>=0 and (signed or b[1]>=0):cand.append(b)
                    direct=min(np.sum((yy-V@b)**2) for b in cand)
                    f,_=signed_fit(t,y,C) if signed else make_fit(t,y,C)
                    diff=abs(direct-f(a)[0]); assert diff<1e-6,(base,a,diff)
                    checks.append(dict(**base,background='signed' if signed else 'positive',a=a,abs_chi2_difference=diff))
                if dataset=='pooled':print('MAIN',d,p,obs,scenario,'signed' if signed else 'positive',
                    result['a'],result['low95'],result['high95'],result['goodness_p'],result['B'],flush=True)
           if d==3 and obs=='c1' and cut==2048 and len(t)>=5:
                contrasts.append(dict(**base,**profile(t,y,C,theory,True,True)))
    write_table(OUT/'profiles.tsv',fits); write_table(OUT/'independent_checks.tsv',checks)
    write_table(OUT/'reference_free_contrasts.tsv',contrasts)
    corrections=[]; predictions=[]; correction_checks=[]
    p=1.; nu,z=.629912,2.0245; alpha=3*p*nu/(1+p*z*nu)
    for scenario,ref in (('old',oldref),('refined',newref)):
      for signed in (False,True):
       for name,delta in (('two_term',None),('irrelevant',.832*p*nu/(1+p*z*nu)),('analytic',p/(1+p*z*nu))):
        for dataset in ('prior','new_only','pooled'):
         t,y,C=inputs(data[3],3,dataset,p,'c1',128,ref,offset)
         X=model_matrix(t,alpha,delta)
         q,beta,bcov,mapping,nactive=linear_fit(X,y,C,(0,) if signed else (0,1))
         base=dict(reference=scenario,background='signed' if signed else 'positive',model=name)
         # Independent QR calculation on the selected active columns.
         active=np.flatnonzero(beta!=0.)
         W=np.linalg.solve(np.linalg.cholesky(C),np.eye(len(t)))
         Q,R=np.linalg.qr(W@X[:,active]); b=np.linalg.solve(R,Q.T@(W@y))
         direct_res=W@y-W@X[:,active]@b
         err=abs(float(direct_res@direct_res)-q)
         assert err<1e-7,(base,dataset,err,beta)
         correction_checks.append(dict(**base,dataset=dataset,check='fit_QR',difference=err))
         ratio=0. if delta is None else beta[2]/beta[0]*t[0]**(-delta)
         corrections.append(dict(**base,dataset=dataset,n_points=len(t),A=beta[0],B=beta[1],
            correction=0. if delta is None else beta[2],chi2=q,dof=len(t)-len(beta),
            goodness_p=chi2_sf(q,len(t)-len(beta)),active_parameters=nactive,ratio_first=ratio))
         if dataset=='prior':
            th,yh,Ch=inputs(data[3],3,'new_only',p,'c1',128,ref,offset)
            Xh=model_matrix(th,alpha,delta); cross=np.full((len(th),len(t)),ref[1]**2)
            Cp=Ch+Xh@bcov@Xh.T-cross@mapping.T@Xh.T-Xh@mapping@cross.T
            residual=yh-Xh@beta; val=float(residual@np.linalg.solve(Cp,residual))
            # Equivalent joint train/test covariance, rather than expanded terms.
            G=np.column_stack([np.eye(len(th)),-Xh@mapping])
            joint=np.block([[Ch,cross],[cross.T,C]])
            Cp2=G@joint@G.T
            covariance_difference=float(np.max(np.abs(Cp2-Cp)))
            val2=float(residual@np.linalg.solve(Cp2,residual))
            assert np.allclose(Cp2,Cp,rtol=1e-8,atol=1e-24) and abs(val2-val)<1e-7
            correction_checks.append(dict(**base,dataset='prior_to_new',check='joint_covariance',difference=abs(val2-val)))
            predictions.append(dict(**base,chi2=val,dof=len(th),goodness_p=chi2_sf(val,len(th))))
    write_table(OUT/'corrections.tsv',corrections); write_table(OUT/'prior_to_new.tsv',predictions)
    write_table(OUT/'correction_checks.tsv',correction_checks)
    for r in corrections:
        if r['background']!='positive' or r['reference']!='old':continue
        old=next(x for x in read_table(HERE/'analysis_corrections/fits.tsv')
            if x['dataset']==r['dataset'] and x['model']==r['model'])
        assert abs(float(old['chi2'])-r['chi2'])<1e-7
    # Reproduce saved positive-B results rather than merely trusting common code.
    for r in fits:
        if r['background']!='positive' or r['reference']!='old' or r['cutoff']!=2048:continue
        saved=next(x for x in read_table(HERE/f"analysis_d{r['d']}/fits.tsv")
            if x['dataset']==r['dataset'] and float(x['p'])==r['p'] and x['observable']==r['observable']
            and x['window']=='all_available' and int(x['cutoff'])==2048)
        for key in ('chi2_min','chi2_theory','low95','high95'):
            assert abs(float(saved[key])-r[key])<1e-6,(key,saved[key],r[key])
    manifest=dict(inputs={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files},
        old_reference=oldref,new_reference=newref,model='A*t^-a+B/t; A>=0; 0<a<1',
        threshold=THRESHOLD,offset_2d=offset,profile_rows=len(fits),
        independent_checks=len(checks),max_independent_chi2_error=max(c['abs_chi2_difference'] for c in checks),
        manuscript_changes=False)
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('CHECKS',manifest,flush=True)
    for r in predictions:print('PREDICTION',r,flush=True)

if __name__=='__main__':main()

"""Joint nonparametric bootstrap of existing main-window trajectories only.

2000 fixed repeats; original free-energy replicas, shared between both d3
protocols. Same draws determine c1 and c2. Original GLS weights are fixed:
this diagnoses the existing conditional estimator, not coverage or a theory
null probability. Both original positive B and signed B use identical draws.
"""
from pathlib import Path
import sys,json,hashlib,csv
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'major5_audit_20261009'))
from diagnose import read_table,write_table,make_fit,golden
from audit_signed_background import inputs,signed_fit

OUT=HERE/'analysis_joint_bootstrap_20261012'
NBOOT=2000
SEED=2026101201

def bootstrap_moments(x,rng):
    means=np.empty(NBOOT);vars_=np.empty(NBOOT)
    for lo in range(0,NBOOT,40):
        hi=min(NBOOT,lo+40)
        xx=x[rng.integers(0,len(x),size=(hi-lo,len(x)))]
        means[lo:hi]=xx.mean(axis=1);vars_[lo:hi]=xx.var(axis=1,ddof=1)
    return means,vars_

def fit_many(t,C,Y,signed):
    # Y shape (replicates, time); orthogonalized basis avoids collinearity loss.
    W=np.linalg.solve(np.linalg.cholesky(C),np.eye(len(t)))
    v=Y@W.T
    u=(1/t)@W.T; un=np.linalg.norm(u); U=u/un
    pu=v@U; l=np.log(t/t[0]); ub=1/t
    def calc(a, vv=v, pp=pu, coefficients=False):
        e=1-np.asarray(a)
        h=ub*np.expm1(e[:,None]*l)/e[:,None]
        hw=h@W.T; hu=hw@U
        hp=hw-hu[:,None]*U; hn=np.linalg.norm(hp,axis=1)
        H=hp/hn[:,None]; ph=np.sum(vv*H,axis=1)
        ch=ph/hn; cu=(pp-ch*hu)/un
        A=ch/e/t[0]**e; B=cu-ch/e
        rs=vv-ph[:,None]*H-pp[:,None]*U
        q=np.sum(rs*rs,axis=1)
        q=np.where(ch>=0,q,np.sum((vv-pp[:,None]*U)**2,axis=1))
        A=np.where(ch>=0,A,0); B=np.where(ch>=0,B,pp/un)
        if not signed:
            g=t**(-np.asarray(a)[:,None]); gw=g@W.T
            ga=np.maximum(0,np.sum(gw*vv,axis=1)/np.sum(gw*gw,axis=1))
            qA=np.sum((vv-ga[:,None]*gw)**2,axis=1)
            b=np.maximum(0,pp/un)
            qB=np.sum((vv-b[:,None]*u)**2,axis=1)
            allowed=(ch>=0)&(B>=0)
            q=np.where(allowed,q,np.inf)
            useA=qA<q; q=np.where(useA,qA,q); A=np.where(useA,ga,A); B=np.where(useA,0,B)
            useB=qB<q; q=np.where(useB,qB,q); A=np.where(useB,0,A); B=np.where(useB,b,B)
        return (q,A,B) if coefficients else q
    grid=np.linspace(1e-6,1-1e-6,1001)
    bestq=np.full(len(Y),np.inf);ix=np.zeros(len(Y),int)
    # Grid loop is vectorized over all bootstrap repetitions.
    for j,a in enumerate(grid):
        q=calc(np.full(len(Y),a));take=q<bestq
        ix[take]=j;bestq[take]=q[take]
    left=grid[np.maximum(0,ix-1)];right=grid[np.minimum(len(grid)-1,ix+1)]
    ratio=(np.sqrt(5)-1)/2
    x=right-ratio*(right-left);y=left+ratio*(right-left)
    fx=calc(x);fy=calc(y)
    for _ in range(45):
        take=fx<fy
        right=np.where(take,y,right);left=np.where(take,left,x)
        x=right-ratio*(right-left);y=left+ratio*(right-left)
        fx=calc(x);fy=calc(y)
    aa=(left+right)/2;qq,A,B=calc(aa,coefficients=True)
    # Explicitly retain boundary candidates and all repetitions.
    ag=grid[ix];qg,Ag,Bg=calc(ag,coefficients=True)
    take=qg<qq;aa=np.where(take,ag,aa);qq=np.minimum(qg,qq)
    A=np.where(take,Ag,A);B=np.where(take,Bg,B)
    return aa,qq,A,B

def main():
    OUT.mkdir(exist_ok=True)
    rng=np.random.default_rng(SEED)
    refpath=HERE.parents[1]/'deliveries/major5_raw_data_original_reference_20261011/reference/original_reference_replicas.tsv'
    ref=np.array([float(r['delta_f']) for r in read_table(refpath)])
    refmean,_=bootstrap_moments(ref,rng)
    assert abs(ref.mean()+.29697775299765183)<1e-14
    offset_path=HERE.parent/'major5_audit_20261009/extension_analysis/finite_size_reference_2d.tsv'
    offset=float(next(r for r in read_table(offset_path) if int(r['L'])==512)['finite_size_offset'])
    rows=[];summaries=[];checks=[];arrays={};sourcefiles=[refpath,offset_path]
    original=read_table(HERE/'analysis_signed_background_20261011/profiles.tsv')
    for d,L in ((2,512),(3,128)):
        pointfile=HERE/f'analysis_d{d}/points.tsv';samplefile=HERE/f'analysis_d{d}/samples.tsv'
        sourcefiles.extend([pointfile,samplefile]);points=read_table(pointfile)
        raw={}
        for r in read_table(samplefile):
            if r['dataset']=='pooled' and int(r['tau'])>=2048:
                raw.setdefault((float(r['p']),int(r['tau'])),[]).append(float(r['W']))
        for p in (1.,1.2):
            times=sorted(t for pp,t in raw if pp==p)
            means=[];variances=[]
            for tt in times:
                xx=np.array(raw[(p,tt)]);m,va=bootstrap_moments(xx,rng)
                means.append(m/L**d);variances.append(va/L**d)
            means=np.array(means).T;variances=np.array(variances).T
            nu,z=(1.,2.1665) if d==2 else (.629912,2.0245)
            theory=p*d*nu/(1+p*z*nu)
            for obs in ('c1','c2'):
                t,y,C=inputs(points,d,'pooled',p,obs,2048,None,offset)
                assert np.array_equal(t,times)
                if obs=='c2':Y=variances
                elif d==3:Y=means-refmean[:,None]
                else:
                    ff=float(next(r for r in points if r['dataset']=='pooled' and float(r['p'])==p)['delta_f'])
                    Y=means-ff-offset
                for signed in (False,True):
                    mode='signed' if signed else 'positive'
                    aa,qq,A,B=fit_many(t,C,np.vstack([y,Y]),signed)
                    saved=next(r for r in original if int(r['d'])==d and float(r['p'])==p and
                        r['observable']==obs and r['dataset']=='pooled' and r['reference']=='old' and
                        int(r['cutoff'])==2048 and r['background']==mode)
                    assert abs(qq[0]-float(saved['chi2_min']))<1e-6
                    assert abs(aa[0]-float(saved['a']))<1e-5
                    for j in (1,17,83,251,999,1999):
                        f,_=signed_fit(t,Y[j-1],C) if signed else make_fit(t,Y[j-1],C)
                        dense=np.linspace(1e-6,1-1e-6,1201)
                        values=np.array([f(a)[0] for a in dense]);k=int(values.argmin())
                        a=dense[k] if k in (0,len(dense)-1) else golden(lambda a:f(a)[0],dense[k-1],dense[k+1])
                        err=abs(f(a)[0]-qq[j]);assert err<1e-5,(d,p,obs,mode,j,err)
                        checks.append(dict(d=d,p=p,obs=obs,mode=mode,replicate=j,chi2_error=err))
                    est=aa[0];a=aa[1:];b=B[1:];amps=A[1:]
                    arrays[f'{d}_{p}_{obs}_{mode}']=a
                    quant=np.quantile(a,[.025,.16,.5,.84,.975]);sd=a.std(ddof=1)
                    summaries.append(dict(d=d,p=p,obs=obs,mode=mode,theory=theory,best=est,
                        mean=a.mean(),sd=sd,q025=quant[0],q16=quant[1],median=quant[2],q84=quant[3],q975=quant[4],
                        skewness=np.mean(((a-a.mean())/sd)**3),
                        B_zero_fraction=np.mean(b==0),A_zero_fraction=np.mean(amps==0),
                        B_negative_fraction=np.mean(b<0),lower_edge_fraction=np.mean(a<1e-5),
                        upper_edge_fraction=np.mean(a>1-1e-5),
                        fraction_in_original_profile=np.mean((a>=float(saved['low95']))&(a<=float(saved['high95']))),
                        original_low95=float(saved['low95']),original_high95=float(saved['high95'])))
                    rows.extend(dict(d=d,p=p,obs=obs,mode=mode,replicate=j+1,a=a[j],
                        A=amps[j],B=b[j],chi2=qq[j+1],reference_draw=refmean[j] if d==3 else '') for j in range(NBOOT))
                    print('DONE',summaries[-1],flush=True)
    corr=[]
    for mode in ('positive','signed'):
        keys=[f'{d}_{p}_{obs}_{mode}' for d in (2,3) for p in (1.,1.2) for obs in ('c1','c2')]
        mat=np.corrcoef([arrays[k] for k in keys])
        for i,k in enumerate(keys):
            for j,h in enumerate(keys):corr.append(dict(mode=mode,first=k,second=h,correlation=mat[i,j]))
        for p in (1.,1.2):
            corr.append(dict(mode=mode,first=f'3_{p}_c1_{mode}',second='shared_reference',
                             correlation=np.corrcoef(arrays[f'3_{p}_c1_{mode}'],refmean)[0,1]))
    write_table(OUT/'summary.tsv',summaries);write_table(OUT/'replicates.tsv',rows)
    write_table(OUT/'correlations.tsv',corr);write_table(OUT/'independent_checks.tsv',checks)
    np.savez_compressed(OUT/'bootstrap_arrays.npz',**arrays,shared_reference=refmean)
    (OUT/'manifest.json').write_text(json.dumps(dict(repeats=NBOOT,seed=SEED,cutoff=2048,
        original_reference_mean=ref.mean(),original_reference_se=ref.std(ddof=1)/np.sqrt(len(ref)),
        covariance='Original fixed GLS covariance; no re-estimation of weights',
        sampling='Pooled independent trajectories at each point; same draws for c1/c2; shared original reference replicas for both 3D protocols',
        limits=['Not confidence-interval coverage calibration','Not a null probability of agreement with theory',
                'No retrospective window selection reproduced','No new simulations or manuscript changes'],
        independent_checks=len(checks),max_chi2_error=max(r['chi2_error'] for r in checks),
        input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sourcefiles}),indent=2)+'\n')

if __name__=='__main__':main()

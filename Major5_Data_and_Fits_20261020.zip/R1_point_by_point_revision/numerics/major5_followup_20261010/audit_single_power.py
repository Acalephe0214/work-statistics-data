"""Old-reference single-power diagnostic; no manuscript or input modifications.

Fit the untransformed cumulants with exactly the previous covariance and 2D
finite-size offset. All pooled points above each declared cutoff are retained.
Profile intervals use delta chi-square=3.841458820694124, without residual
variance rescaling. A>=0; use a wide exponent search (0,2), not the two-power
model's a<1 restriction. Signed two-power comparisons are diagnostics only.
"""
from pathlib import Path
import json
import hashlib
import numpy as np
from audit_signed_background import (
    inputs, read_table, write_table, golden, chi2_sf, bisect_root, THRESHOLD,
    signed_fit,
)

HERE = Path(__file__).resolve().parent
OUT = HERE / 'analysis_single_power_20261011'


def single_profile(t, y, C, theory):
    W = np.linalg.solve(np.linalg.cholesky(C), np.eye(len(t)))
    v = W @ y
    def fit(a):
        x = W @ (t / t[0]) ** (-a)
        amplitude = max(0., float(x @ v / (x @ x)))
        residual = v - amplitude * x
        return float(residual @ residual), amplitude
    grid = np.linspace(0., 2., 2001)
    vals = np.array([fit(a)[0] for a in grid])
    j = int(vals.argmin())
    assert 0 < j < len(grid)-1
    best = golden(lambda a: fit(a)[0], grid[j-1], grid[j+1])
    q, amp = fit(best)
    f = lambda a: fit(a)[0] - q - THRESHOLD
    roots = [bisect_root(f, l, h) for l, h in zip(grid[:-1], grid[1:])
             if f(l)*f(h) < 0]
    assert len(roots) == 2
    qt, at = fit(theory)
    qad, _ = fit(1.)
    # Independent direct GLS check (not using the whitened fit helper).
    errors = []
    for a in (best, *roots, theory, 1.):
        x = t ** (-a)
        cx = np.linalg.solve(C, x)
        aa = max(0., float(cx @ y / (x @ cx)))
        residual = y - aa*x
        direct = float(residual @ np.linalg.solve(C, residual))
        errors.append(abs(direct-fit(a)[0]))
    assert max(errors) < 1e-7
    n = len(t)
    result = dict(a=best, low95=roots[0], high95=roots[1],
        A=amp*t[0]**best, chi2=q, dof=n-2, goodness_p=chi2_sf(q,n-2),
        chi2_theory=qt, dof_theory=n-1, theory_goodness_p=chi2_sf(qt,n-1),
        theory_in95=qt-q <= THRESHOLD,
        chi2_adiabatic=qad, adiabatic_goodness_p=chi2_sf(qad,n-1),
        independent_max_error=max(errors))
    residuals=[dict(tau=tt, observed=yy, predicted=amp*(tt/t[0])**(-best),
        marginal_residual=(yy-amp*(tt/t[0])**(-best))/np.sqrt(C[i,i]))
        for i,(tt,yy) in enumerate(zip(t,y))]
    return result, residuals


def main():
    OUT.mkdir(exist_ok=True)
    paths = [HERE/f'analysis_d{d}/points.tsv' for d in (2,3)]
    offset_path = HERE.parent/'major5_audit_20261009/extension_analysis/finite_size_reference_2d.tsv'
    offset = float(next(r for r in read_table(offset_path) if int(r['L'])==512)['finite_size_offset'])
    previous = read_table(HERE/'analysis_signed_background_20261011/profiles.tsv')
    rows, residuals = [], []
    for d,path in zip((2,3),paths):
        data = read_table(path)
        nu,z = (1.,2.1665) if d==2 else (.629912,2.0245)
        for p in (1.,1.2):
            theory=p*d*nu/(1+p*z*nu)
            for obs in ('c1','c2'):
                for cut in (1024,2048,4096,8192,16384):
                    t,y,C = inputs(data,d,'pooled',p,obs,cut,None,offset)
                    if len(t)<4: continue
                    base=dict(d=d,p=p,observable=obs,cutoff=cut,n_points=len(t),
                              tau_min=t[0],tau_max=t[-1],theory=theory)
                    result,res = single_profile(t,y,C,theory)
                    old=next((r for r in previous if int(r['d'])==d and
                        float(r['p'])==p and r['observable']==obs and
                        r['dataset']=='pooled' and r['reference']=='old' and
                        int(r['cutoff'])==cut and r['background']=='signed'),None)
                    if old:
                        delta=max(0.,result['chi2']-float(old['chi2_min']))
                        result.update(delta_chi2_add_B=delta,
                                      add_B_nominal_p=chi2_sf(delta,1))
                    else:
                        result.update(delta_chi2_add_B='',add_B_nominal_p='')
                    # Size of the background in the theory-fixed two-power fit.
                    ff,_=signed_fit(t,y,C)
                    _,(aa,bb)=ff(theory)
                    result.update(theory_B=bb,
                        background_over_KZ_first=bb/aa*t[0]**(theory-1),
                        background_over_KZ_last=bb/aa*t[-1]**(theory-1))
                    rows.append(dict(**base,**result))
                    residuals.extend(dict(**base,**r) for r in res)
    write_table(OUT/'fits.tsv',rows)
    write_table(OUT/'residuals.tsv',residuals)
    manifest=dict(inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [*paths,offset_path]},
        reference='Original reference stored in the input points only',
        dataset='pooled; all points retained above each cutoff',
        model='A*tau^-a (plus the unchanged known D_L in 2D c1)',
        covariance='Identical to signed-background audit; shared reference covariance retained',
        search_exponent=[0,2],cutoffs=[1024,2048,4096,8192,16384],
        nominal_profile_delta=THRESHOLD,offset_2d=offset,
        max_independent_error=max(r['independent_max_error'] for r in rows),
        manuscript_changes=False)
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    preview_keys=['d','p','observable','cutoff','n_points','tau_min','tau_max',
                  'theory','a','low95','high95','chi2','dof','goodness_p','theory_in95']
    receipt=dict(schemaVersion=1,items=[dict(id='single-power-window-check',
        title='单幂拟合与统一窗口扫描',queries=[dict(id='old-reference-single-power',
        source=dict(label='Major 5 原参考数据单幂重拟合',
            files=['analysis_d2/points.tsv','analysis_d3/points.tsv','audit_single_power.py'],
            filters=['合并样本，每个窗口内全部有效时间点','原自由能参考和原协方差',
                     '二维 c1 保留已知有限尺寸偏移'],
            caveats=['95%区间以单幂模型成立为条件，不包含遗漏修正项的系统误差。',
                     '窗口扫描为敏感性诊断，未据理论一致性选择主窗口。'],
            evidenceFlow=[dict(kind='validation',title='独立GLS复核',
                detail=f'直接协方差求解与Cholesky白化在最优值、区间端点和固定指数处的最大卡方差为 {manifest["max_independent_error"]:.3g}。')]),
        columns=preview_keys,rows=[{k:r[k] for k in preview_keys} for r in rows])])])
    (OUT/'sources.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    for r in rows:
        print(r['d'],r['p'],r['observable'],r['cutoff'],r['n_points'],
            'a/CI',*[round(r[k],6) for k in ('a','low95','high95')],
            'p',round(r['goodness_p'],6),'theory_in',r['theory_in95'],
            'theory_p',round(r['theory_goodness_p'],6),
            'B/KZ',round(r['background_over_KZ_first'],3),round(r['background_over_KZ_last'],3))
    print('INDEPENDENT CHECK',manifest['max_independent_error'])


if __name__=='__main__':
    main()

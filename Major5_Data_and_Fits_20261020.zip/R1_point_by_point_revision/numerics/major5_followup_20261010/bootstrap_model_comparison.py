"""Fixed-window Gaussian parametric-bootstrap test of adding signed B/tau.

No physical simulations, reference changes, model selection or manuscript edits.
Both nested models use A>=0 and 1e-6<=a<=1-1e-6. Each group has 20000
predeclared null draws. Covariance is the original fixed GLS estimate.
Tests are marginal; Holm adjustment does not require cross-test independence.
"""
from pathlib import Path
import json, hashlib, time
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.stats import beta, chi2
from joint_bootstrap_existing import fit_many
from audit_signed_background import inputs, read_table, write_table, signed_fit

HERE = Path(__file__).resolve().parent
OUT = HERE/'analysis_bootstrap_model_comparison_20261012'
NBOOT = 20000
SEED = 2026101202
LOW, HIGH = 1e-6, 1-1e-6


def single_many(t, C, Y):
    W = np.linalg.solve(np.linalg.cholesky(C), np.eye(len(t)))
    v = Y@W.T
    def calc(a):
        g = (t/t[0])**(-np.asarray(a)[:, None])
        x = g@W.T
        amp = np.maximum(0, np.sum(x*v,axis=1)/np.sum(x*x,axis=1))
        residual = v-amp[:,None]*x
        return np.sum(residual*residual,axis=1), amp
    grid = np.linspace(LOW,HIGH,1001)
    best = np.full(len(Y),np.inf); ix = np.zeros(len(Y),int)
    for j,a in enumerate(grid):
        q,_ = calc(np.full(len(Y),a)); take=q<best
        ix[take]=j; best[take]=q[take]
    left=grid[np.maximum(0,ix-1)];right=grid[np.minimum(len(grid)-1,ix+1)]
    rho=(np.sqrt(5)-1)/2
    for _ in range(48):
        x=right-rho*(right-left); y=left+rho*(right-left)
        take=calc(x)[0]<calc(y)[0]
        right=np.where(take,y,right);left=np.where(take,left,x)
    a=(left+right)/2; q,amp=calc(a)
    ag=grid[ix];qg,gg=calc(ag);take=qg<q
    return np.where(take,ag,a),np.minimum(q,qg),np.where(take,gg,amp)


def independent_min(fun):
    grid=np.linspace(LOW,HIGH,1501)
    values=np.array([fun(a) for a in grid])
    candidates=[values[0],values[-1]]
    for j in range(1,len(grid)-1):
        if values[j]<=values[j-1] and values[j]<=values[j+1]:
            candidates.append(minimize_scalar(fun,bounds=(grid[j-1],grid[j+1]),
                method='bounded',options={'xatol':1e-13}).fun)
    return min(candidates)


def main():
    started=time.time();OUT.mkdir(exist_ok=True)
    rng=np.random.default_rng(SEED)
    shared_reference_z=rng.normal(size=NBOOT)
    offsetpath=HERE.parent/'major5_audit_20261009/extension_analysis/finite_size_reference_2d.tsv'
    offset=float(next(r for r in read_table(offsetpath) if int(r['L'])==512)['finite_size_offset'])
    original_single=read_table(HERE/'analysis_single_power_20261011/fits.tsv')
    original_double=read_table(HERE/'analysis_signed_background_20261011/profiles.tsv')
    rows=[];checks=[];replicates=[];sources=[offsetpath,Path(__file__),HERE/'joint_bootstrap_existing.py']
    arrays={}
    for d in (2,3):
        path=HERE/f'analysis_d{d}/points.tsv';sources.append(path);points=read_table(path)
        for p in (1.,1.2):
            for obs in ('c1','c2'):
                t,y,C=inputs(points,d,'pooled',p,obs,2048,None,offset)
                a0,q0,amp0=single_many(t,C,y[None,:])
                a1,q1,A1,B1=fit_many(t,C,y[None,:],True)
                old0=next(r for r in original_single if int(r['d'])==d and float(r['p'])==p and r['observable']==obs and int(r['cutoff'])==2048)
                old1=next(r for r in original_double if int(r['d'])==d and float(r['p'])==p and r['observable']==obs and int(r['cutoff'])==2048 and r['dataset']=='pooled' and r['reference']=='old' and r['background']=='signed')
                assert abs(q0[0]-float(old0['chi2']))<1e-6
                assert abs(q1[0]-float(old1['chi2_min']))<1e-6
                mean=amp0[0]*(t/t[0])**(-a0[0])
                if d==3 and obs=='c1':
                    sr=float(next(r for r in points if r['dataset']=='pooled' and float(r['p'])==p)['se_delta_f'])
                    residual_cov=C-sr**2
                    assert np.max(np.abs(residual_cov-np.diag(np.diag(residual_cov))))<1e-20
                    Y=mean+rng.normal(size=(NBOOT,len(t)))*np.sqrt(np.diag(residual_cov))-sr*shared_reference_z[:,None]
                else:
                    Y=mean+rng.normal(size=(NBOOT,len(t)))@np.linalg.cholesky(C).T
                z0,s0,amps=single_many(t,C,Y)
                z1,s1,As,Bs=fit_many(t,C,Y,True)
                assert np.all(np.isfinite(s0)) and np.all(np.isfinite(s1))
                assert np.min(s0-s1)>-1e-6
                D=max(0,float(q0[0]-q1[0])); Ds=np.maximum(0,s0-s1)
                # independent direct GLS single and separate lstsq double fits,
                # including the observation, near-tail, and boundary draws.
                ids=sorted(set([0,1,17,999,int(np.argmax(Ds)),int(np.argmax(z1))]))
                for j in [-1]+ids:
                    yy=y if j==-1 else Y[j]
                    def single_direct(a):
                        x=(t/t[0])**(-a);cx=np.linalg.solve(C,x)
                        amp=max(0,float(cx@yy/(x@cx)));r=yy-amp*x
                        return float(r@np.linalg.solve(C,r))
                    ff,_=signed_fit(t,yy,C)
                    e0=abs(independent_min(single_direct)-(q0[0] if j==-1 else s0[j]))
                    e1=abs(independent_min(lambda a:ff(a)[0])-(q1[0] if j==-1 else s1[j]))
                    assert max(e0,e1)<1e-5,(d,p,obs,j,e0,e1)
                    checks.append(dict(d=d,p=p,obs=obs,replicate=j,single_chi2_error=e0,double_chi2_error=e1))
                count=int(np.sum(Ds>=D));prob=(count+1)/(NBOOT+1)
                lo=0. if count==0 else beta.ppf(.025,count,NBOOT-count+1)
                hi=1. if count==NBOOT else beta.ppf(.975,count+1,NBOOT-count)
                row=dict(d=d,p=p,observable=obs,n_points=len(t),tau_min=t[0],tau_max=t[-1],
                    a_single=float(a0[0]),a_double=float(a1[0]),A_double=float(A1[0]),B_double=float(B1[0]),
                    chi2_single=float(q0[0]),chi2_double=float(q1[0]),delta_chi2=D,
                    bootstrap_exceedances=count,repetitions=NBOOT,p_bootstrap=prob,
                    mc95_low=float(lo),mc95_high=float(hi),p_chi2_1=float(chi2.sf(D,1)),
                    null_delta95=float(np.quantile(Ds,.95)),null_delta99=float(np.quantile(Ds,.99)),
                    single_goodness_bootstrap=(int(np.sum(s0>=q0[0]))+1)/(NBOOT+1),
                    single_goodness_nominal=float(chi2.sf(q0[0],len(t)-2)),
                    double_goodness_nominal=float(chi2.sf(q1[0],len(t)-3)),
                    null_single_upper_edge=float(np.mean(z0>1-1e-5)),
                    null_double_upper_edge=float(np.mean(z1>1-1e-5)))
                rows.append(row)
                key=f'd{d}_p{p}_{obs}'
                arrays[key+'_delta']=Ds;arrays[key+'_single_exponent']=z0;arrays[key+'_double_exponent']=z1
                replicates.extend(dict(d=d,p=p,observable=obs,replicate=j+1,delta_chi2=Ds[j],
                    chi2_single=s0[j],chi2_double=s1[j],a_single=z0[j],a_double=z1[j]) for j in range(NBOOT))
                write_table(OUT/'summary_partial.tsv',rows)
                print('DONE',row,flush=True)
    order=np.argsort([r['p_bootstrap'] for r in rows]);running=0.
    for rank,i in enumerate(order):
        running=max(running,min(1.,(len(rows)-rank)*rows[i]['p_bootstrap']))
        rows[i]['p_holm_8']=running
    write_table(OUT/'summary.tsv',rows);write_table(OUT/'independent_checks.tsv',checks)
    write_table(OUT/'null_replicates.tsv',replicates)
    np.savez_compressed(OUT/'null_arrays.npz',**arrays,shared_reference_z=shared_reference_z)
    manifest=dict(seed=SEED,repetitions=NBOOT,cutoff=2048,reference='original only',
        data='pooled; all main-window points; original 2D offset',
        null='A*tau^-a; A>=0; 1e-6<=a<=1-1e-6',
        alternative='A*tau^-a+B/tau; A>=0; signed B; same exponent domain',
        method='Plug-in Gaussian parametric bootstrap at fitted null mean; fixed original GLS covariance; both models refit every draw',
        common_reference='Same Gaussian original-reference error draw for both d3 c1 protocols',
        limits=['Conditional on estimated covariance and Gaussian errors of cumulant estimators',
            'Does not account for historical window selection',
            'Holm across eight marginal tests, requiring no joint independence',
            'c1/c2 cross-correlation not simulated; no joint test reported',
            'Non-rejection does not prove B=0 or establish asymptotic exponent',
            'No new physical samples or manuscript changes'],
        mc_intervals='Clopper-Pearson 95% intervals for simulation tail probability, not physical parameter intervals',
        independent_checks=len(checks),max_chi2_error=max(max(r['single_chi2_error'],r['double_chi2_error']) for r in checks),
        elapsed_seconds=time.time()-started,
        sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    receipt=dict(schemaVersion=1,items=[dict(id='background-needed',title='单幂律与双幂律的 bootstrap 比较',queries=[dict(
        id='null-bootstrap',source=dict(label='Major 5 原参考主窗口数据',
            files=['analysis_d2/points.tsv','analysis_d3/points.tsv','bootstrap_model_comparison.py','summary.tsv'],
            filters=['原自由能参考','合并数据，tau_Q≥2048的所有时间点','双幂律允许B取正负值'],
            caveats=['检验以原协方差和累积量估计误差的高斯近似为条件。','未重现历史窗口选择。','未拒绝单幂律不等于证明背景系数为零。'],
            evidenceFlow=[dict(kind='validation',title='独立拟合核验',detail=f'{len(checks)}组独立核验，最大卡方差{manifest["max_chi2_error"]:.3g}。'),
                dict(kind='calculation',title='零假设校准',detail='每组固定20000次单幂律零假设模拟，均重新拟合两个模型；报告加一校正p值和8组Holm校正。')]),
        columns=['d','p','observable','delta_chi2','bootstrap_exceedances','p_bootstrap','mc95_low','mc95_high','p_holm_8'],
        rows=[{k:r[k] for k in ['d','p','observable','delta_chi2','bootstrap_exceedances','p_bootstrap','mc95_low','mc95_high','p_holm_8']} for r in rows])])])
    (OUT/'sources.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print('FINAL',json.dumps(rows),flush=True)
    print('CHECKS',manifest['max_chi2_error'],'SECONDS',manifest['elapsed_seconds'],flush=True)


if __name__=='__main__':
    main()

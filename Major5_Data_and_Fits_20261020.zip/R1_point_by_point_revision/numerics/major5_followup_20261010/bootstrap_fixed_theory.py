"""Fixed-theory two-power GLS and Gaussian null bootstrap on existing data.

Original reference, pooled data, lower cutoff 2048, unchanged covariance.
20000 fixed draws per group; A>=0, signed B. No physical simulations or edits
to manuscript/data. The free-exponent alternative has 1e-6<=a<=1-1e-6.
"""
from pathlib import Path
import json, hashlib, time
import numpy as np
from scipy.stats import chi2, beta
from audit_signed_background import inputs, read_table, write_table, signed_fit
from joint_bootstrap_existing import fit_many
from bootstrap_model_comparison import independent_min

HERE=Path(__file__).resolve().parent
OUT=HERE/'analysis_fixed_theory_bootstrap_20261012'
NBOOT=20000
SEED=2026101203


def linear_many(X,C,Y):
    """GLS for two columns, first amplitude nonnegative, second signed."""
    W=np.linalg.solve(np.linalg.cholesky(C),np.eye(len(C)))
    U=W@X
    scale=np.linalg.norm(U,axis=0)
    V=U/scale
    v=Y@W.T
    coeff=v@np.linalg.pinv(V).T
    edge=coeff[:,0]<0
    coeff[edge,0]=0.
    coeff[edge,1]=v[edge]@V[:,1]/(V[:,1]@V[:,1])
    residual=v-coeff@V.T
    return np.sum(residual**2,axis=1),coeff/scale,edge


def probability(count):
    return dict(p=(count+1)/(NBOOT+1),count=int(count),
        mc95_low=0. if count==0 else float(beta.ppf(.025,count,NBOOT-count+1)),
        mc95_high=1. if count==NBOOT else float(beta.ppf(.975,count+1,NBOOT-count)))


def main():
    if OUT.exists():
        raise FileExistsError(f'Refusing to overwrite existing results: {OUT}')
    OUT.mkdir()
    start=time.time()
    rng=np.random.default_rng(SEED)
    shared_reference=rng.normal(size=NBOOT)
    offsetfile=HERE.parent/'major5_audit_20261009/extension_analysis/finite_size_reference_2d.tsv'
    offset=float(next(r for r in read_table(offsetfile) if r['L']=='512')['finite_size_offset'])
    prior=read_table(HERE/'analysis_signed_background_20261011/profiles.tsv')
    sources=[Path(__file__),HERE/'joint_bootstrap_existing.py',
             HERE/'audit_signed_background.py',offsetfile]
    summary=[];checks=[];replicates=[];arrays={}
    for d in (2,3):
        source=HERE/f'analysis_d{d}/points.tsv'
        sources.append(source);points=read_table(source)
        nu,z=(1.,2.1665) if d==2 else (.629912,2.0245)
        for p in (1.,1.2):
            alpha=p*d*nu/(1+p*z*nu)
            for obs in ('c1','c2'):
                t,y,C=inputs(points,d,'pooled',p,obs,2048,None,offset)
                X=np.column_stack((t**(-alpha),1/t))
                q0,ab0,edge0=linear_many(X,C,y[None,:])
                af,qf,_,_=fit_many(t,C,y[None,:],True)
                old=next(r for r in prior if int(r['d'])==d and float(r['p'])==p
                    and r['observable']==obs and r['dataset']=='pooled'
                    and r['reference']=='old' and r['background']=='signed'
                    and r['cutoff']=='2048')
                assert abs(q0[0]-float(old['chi2_theory']))<1e-7
                assert abs(qf[0]-float(old['chi2_min']))<1e-7
                # Multiplying the observable by tau produces a linear model
                # in x=tau^(1-alpha). Transform covariance by the same map.
                Xt=np.column_stack((t**(1-alpha),np.ones(len(t))))
                Ct=C*np.outer(t,t)
                qt,abt,_=linear_many(Xt,Ct,(t*y)[None,:])
                assert abs(qt[0]-q0[0])<1e-8
                assert np.allclose(abt,ab0,rtol=1e-9,atol=1e-10)
                mean=X@ab0[0]
                if d==3 and obs=='c1':
                    sr=float(next(r for r in points if r['dataset']=='pooled' and float(r['p'])==p)['se_delta_f'])
                    independent=C-sr**2
                    assert np.max(np.abs(independent-np.diag(np.diag(independent))))<1e-20
                    Y=mean+rng.normal(size=(NBOOT,len(t)))*np.sqrt(np.diag(independent))-sr*shared_reference[:,None]
                else:
                    Y=mean+rng.normal(size=(NBOOT,len(t)))@np.linalg.cholesky(C).T
                qb,abb,edgeb=linear_many(X,C,Y)
                aa,qfree,_,_=fit_many(t,C,Y,True)
                assert np.all(np.isfinite(qb)) and np.all(np.isfinite(qfree))
                assert np.min(qb-qfree)>-1e-6
                observed_delta=max(0.,float(q0[0]-qf[0]))
                delta=np.maximum(0.,qb-qfree)
                pg=probability(np.sum(qb>=q0[0]))
                pe=probability(np.sum(delta>=observed_delta))
                # Separate solve in original coordinates for fixed-theory GLS,
                # and independently scanned free-exponent GLS for selected draws.
                ids=sorted(set([-1,0,17,int(np.argmax(delta)),int(np.argmax(aa))]))
                for j in ids:
                    yy=y if j==-1 else Y[j]
                    cinvX=np.linalg.solve(C,X)
                    ab=np.linalg.solve(X.T@cinvX,cinvX.T@yy)
                    if ab[0]<0:
                        ab=np.array([0.,cinvX[:,1]@yy/(X[:,1]@cinvX[:,1])])
                    rr=yy-X@ab
                    direct=float(rr@np.linalg.solve(C,rr))
                    f,_=signed_fit(t,yy,C)
                    e0=abs(direct-(q0[0] if j==-1 else qb[j]))
                    e1=abs(independent_min(lambda a:f(a)[0])-(qf[0] if j==-1 else qfree[j]))
                    assert max(e0,e1)<1e-6
                    checks.append(dict(d=d,p=p,observable=obs,replicate=j,
                        fixed_chi2_error=e0,free_chi2_error=e1))
                row=dict(d=d,p=p,observable=obs,n_points=len(t),tau_min=t[0],tau_max=t[-1],
                    alpha=alpha,A=float(ab0[0,0]),B=float(ab0[0,1]),
                    chi2_fixed=float(q0[0]),dof=len(t)-2,
                    p_goodness_chi2=float(chi2.sf(q0[0],len(t)-2)),
                    p_goodness_boot=pg['p'],goodness_exceedances=pg['count'],
                    goodness_mc95_low=pg['mc95_low'],goodness_mc95_high=pg['mc95_high'],
                    a_free=float(af[0]),chi2_free=float(qf[0]),delta_chi2=observed_delta,
                    p_free_exponent_boot=pe['p'],free_exponent_exceedances=pe['count'],
                    free_exponent_mc95_low=pe['mc95_low'],free_exponent_mc95_high=pe['mc95_high'],
                    p_free_exponent_chi2=float(chi2.sf(observed_delta,1)),
                    A_low95=float(np.quantile(abb[:,0],.025)),A_high95=float(np.quantile(abb[:,0],.975)),
                    B_low95=float(np.quantile(abb[:,1],.025)),B_high95=float(np.quantile(abb[:,1],.975)),
                    fixed_A_edge_fraction=float(np.mean(edgeb)),
                    free_a_upper_edge_fraction=float(np.mean(aa>1-1e-5)),
                    transform_chi2_error=abs(float(qt[0]-q0[0])))
                summary.append(row)
                key=f'd{d}_p{p}_{obs}'
                arrays[key+'_t']=t;arrays[key+'_y']=y;arrays[key+'_C']=C
                arrays[key+'_q_fixed']=qb;arrays[key+'_q_free']=qfree
                arrays[key+'_a_free']=aa;arrays[key+'_AB_fixed']=abb
                replicates.extend(dict(d=d,p=p,observable=obs,replicate=j+1,
                    chi2_fixed=qb[j],chi2_free=qfree[j],delta_chi2=delta[j],
                    a_free=aa[j],A_fixed=abb[j,0],B_fixed=abb[j,1]) for j in range(NBOOT))
                write_table(OUT/'summary_partial.tsv',summary)
                print('DONE',d,p,obs,'chi2',row['chi2_fixed'],'p_gof',pg['p'],
                      'delta',observed_delta,'p_free',pe['p'],flush=True)
    write_table(OUT/'summary.tsv',summary)
    write_table(OUT/'independent_checks.tsv',checks)
    write_table(OUT/'replicates.tsv',replicates)
    np.savez_compressed(OUT/'arrays.npz',**arrays,shared_reference_z=shared_reference)
    metadata=dict(seed=SEED,repetitions=NBOOT,cutoff=2048,reference='original',
        null='A*tau^-alpha+B/tau; theoretical alpha fixed; A>=0; B signed',
        alternative='A*tau^-a+B/tau; A>=0; B signed; 1e-6<=a<=1-1e-6',
        method='Parametric Gaussian bootstrap at fitted theoretical mean; fixed observed covariance; both models refitted every draw',
        transform='yprime=tau*y; Cprime_ij=tau_i*C_ij*tau_j; x=tau^(1-alpha); yprime=A*x+B',
        limits=['Conditional on fixed estimated covariance, original reference, and specified window',
                '2D c1 removes the independent fixed D_L before fitting',
                'No calibration of historical window choice or omitted correction terms',
                'Goodness-of-fit non-rejection is consistency, not proof or a probability that the theory is true',
                'Group p values are marginal; no independent joint probability is asserted',
                'Amplitude intervals are conditional on theoretical exponents, not free-exponent intervals'],
        n_checks=len(checks),max_fixed_error=max(r['fixed_chi2_error'] for r in checks),
        max_free_error=max(r['free_chi2_error'] for r in checks),
        elapsed_seconds=time.time()-start,
        input_sha256={str(s):hashlib.sha256(s.read_bytes()).hexdigest() for s in sources})
    (OUT/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print('FINISHED',metadata['elapsed_seconds'],flush=True)


if __name__=='__main__':main()

using Test, LinearAlgebra
include(joinpath(@__DIR__, "finite_size_ising.jl"))

function logZ_enumeration(L,J,T)
    V=L^2
    weights = Float64[]
    for bits in 0:(2^V-1)
        spin(x,y) = 2Int((bits >> ((x-1)+L*(y-1))) & 1)-1
        B=sum(spin(x,y)*(spin(mod1(x+1,L),y)+spin(x,mod1(y+1,L)))
              for x in 1:L,y in 1:L)
        push!(weights,J*B/T)
    end
    largest=maximum(weights)
    largest+log(sum(exp.(weights .- largest)))
end

function logZ_transfer(L,J,T)
    spins = [2Int((bits >> j) & 1)-1 for bits in 0:(2^L-1),j in 0:(L-1)]
    bonds = vec(sum(spins .* circshift(spins,(0,1));dims=2))
    exponent=(J/T).*((bonds .+ bonds')/2 .+ spins*spins')
    largest=maximum(exponent)
    values=eigvals(Symmetric(exp.(exponent .- largest)))
    L*largest+log(sum(values.^L))
end

@testset "finite torus partition function" begin
    Tc=2/log(1+sqrt(2))
    for L in (2,4), J in (0.0,0.2,0.5,1.0,1.3)
        exact=Float64(log_partition_torus_2D(L,J,Tc))
        @test isapprox(exact,logZ_enumeration(L,J,Tc);atol=2e-12)
        @test isapprox(exact,logZ_transfer(L,J,Tc);atol=2e-12)
    end
    for L in (6,8), J in (0.5,1.0,1.3)
        @test isapprox(Float64(log_partition_torus_2D(L,J,Tc)),
                       logZ_transfer(L,J,Tc);atol=2e-11)
    end
    for L in (128,256,512)
        f128=deltaF_torus_2D(L,0.5,1.0,Tc;precision_bits=128)
        f256=deltaF_torus_2D(L,0.5,1.0,Tc;precision_bits=256)
        @test abs(f128-f256)<big"1e-25"
        @test f256 < 0
        println("L=",L," delta_f=",Float64(f256/L^2),
                " correction_to_bulk=",Float64(f256/L^2)+0.42193373570535)
    end
end

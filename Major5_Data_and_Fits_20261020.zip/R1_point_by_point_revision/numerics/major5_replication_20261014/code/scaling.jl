# =========================================================================
# IsingV2 / scaling.jl
# 多 step 扫描 (标度律拟合用): 对每个 step 独立跑一次实验, 汇总 E/W.
# (内层每次独立初始化随机晶格, 保证不同 step 间样本独立.)
# =========================================================================
using Statistics

function generate_data_cool(steps::AbstractVector; d::Integer=2, L::Integer=512,
                            batch_size::Integer=10, T_start::Real=3.0, T_final::Real=0.0,
                            p::Real=1.0, equil_sweeps::Integer=500,
                            show_progress::Bool=true)
    n = length(steps)
    println("generate_data_cool: n=$n, L=$L, batch=$batch_size")
    E  = zeros(Int, n, batch_size)
    Et = Vector{Vector{Float32}}()
    for i in 1:n
        Ef, et = cool(d, L, batch_size; step=steps[i], T_start=T_start,
                      T_final=T_final, p=p, equil_sweeps=equil_sweeps,
                      show_progress=show_progress)
        E[i, :] .= Int.(Ef)
        push!(Et, et)
    end
    return E, Et
end

function generate_data_demag_h(steps::AbstractVector; d::Integer=2, L::Integer=512,
                               batch_size::Integer=10, h_start::Real=3.5,
                               h_final::Real=1.5, T_factor::Real=1.0, p::Real=1.0,
                               equil_sweeps::Integer=500, show_progress::Bool=true)
    n = length(steps)
    println("generate_data_demag_h: n=$n, L=$L, batch=$batch_size")
    E  = zeros(Int, n, batch_size)
    W  = zeros(Float64, n, batch_size)
    Mt = Vector{Vector{Int64}}()
    for i in 1:n
        E[i, :], W[i, :], m = demag_h(d, L, batch_size; step=steps[i],
                                      h_start=h_start, h_final=h_final,
                                      T_factor=T_factor, p=p,
                                      equil_sweeps=equil_sweeps,
                                      show_progress=show_progress)
        push!(Mt, m)
    end
    return E, W, Mt
end

function generate_data_deJ(steps::AbstractVector; d::Integer=2, L::Integer=512,
                           batch_size::Integer=10, J_start::Real=0.5,
                           J_final::Real=1.0, T_factor::Real=1.0, p::Real=1.0,
                           equil_sweeps::Integer=500, show_progress::Bool=true,
                           check_critical_endpoint::Bool=true)
    n = length(steps)
    println("generate_data_deJ: n=$n, L=$L, batch=$batch_size")
    E  = zeros(Float64, n, batch_size)
    W  = zeros(Float64, n, batch_size)
    Bt = Vector{Vector{Int64}}()
    for i in 1:n
        E[i, :], W[i, :], b = demag_J(d, L, batch_size; step=steps[i],
                                      J_start=J_start, J_final=J_final,
                                      T_factor=T_factor, p=p,
                                      equil_sweeps=equil_sweeps,
                                      show_progress=show_progress,
                                      check_critical_endpoint=check_critical_endpoint)
        push!(Bt, b)
    end
    return E, W, Bt
end

# =========================================================================
# IsingV2 / buffers.jl
# 一次性分配所有 GPU 缓冲, 配套 free!
# =========================================================================
using CUDA

struct Buffers{N}
    E_local::CuArray{Int8, N}     # 与 lattice 同形, 局域能量/键和
    B_local::CuArray{Int8, N}     # 局域键和 (s·邻居正方向)
    E_out::CuArray{Int32, N}      # (1,...,1,batch) 归约能量 (J=1)
    B_out::CuArray{Int32, N}      # (1,...,1,batch) 归约键和 B
    M_out::CuArray{Int32, N}      # (1,...,1,batch) 归约磁化 M = Σ s_i
    W_out::CuArray{Float64, N}    # (1,...,1,batch) 累计功
end

# 形状工具: 空间维全 1, 末维 (batch) 保留
@inline _out_dims(dims::NTuple{N}) where {N} = ntuple(i -> i == N ? dims[N] : 1, N)

function allocate_buffers(lattice::CuArray{Int8, N}) where N
    dims = size(lattice)
    odim = _out_dims(dims)
    return Buffers{N}(
        CUDA.zeros(Int8,   dims),
        CUDA.zeros(Int8,   dims),
        CUDA.zeros(Int32,  odim),
        CUDA.zeros(Int32,  odim),
        CUDA.zeros(Int32,  odim),
        CUDA.zeros(Float64,odim),
    )
end

function free!(buf::Buffers)
    CUDA.unsafe_free!(buf.E_local)
    CUDA.unsafe_free!(buf.B_local)
    CUDA.unsafe_free!(buf.E_out)
    CUDA.unsafe_free!(buf.B_out)
    CUDA.unsafe_free!(buf.M_out)
    CUDA.unsafe_free!(buf.W_out)
    return nothing
end

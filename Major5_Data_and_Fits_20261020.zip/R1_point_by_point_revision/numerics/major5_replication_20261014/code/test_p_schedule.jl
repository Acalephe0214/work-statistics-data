# =========================================================================
# test_p_schedule.jl — 验证非匀速驱动参数 p
#   1) p=1 调度与线性调度位级一致；默认入口可正常运行
#   2) p=2 / p=0.5 各协议能跑通且结果有限
#   3) 调度端点正确: X(0)=X_start, X(step)=X_final
# =========================================================================
include(joinpath(@__DIR__, "IsingV2.jl"))
using .IsingV2
using Random, CUDA, Printf

@assert CUDA.functional() "需要可用 GPU"

# --- 调度公式自洽性（直接测试生产代码） ---
for p in (0.5, 1, 2.0, 3.0)
    X0, X1, step = 0.5, 1.0, 250
    xs = power_schedule(X0, X1, step, p)
    @assert xs[1] == Float32(X0) && xs[end] == Float32(X1)
    @assert xs[2] > xs[1]
    @assert sum(Float64.(protocol_increments(xs))) ≈ X1-X0
    validate_schedule(xs, X0, X1)
end
println("schedule formula ok")

# --- 1) p=1 回归 ---
# CUDA kernel 内部的随机数状态不保证 CUDA.seed! 后逐 kernel 位级复现，
# 因而不能用“两次随机轨迹完全相同”来检验关键字默认值。这里直接检验
# 生产调度向量，并另做一次默认入口 smoke test。
linear = Float32.(range(0.5, 1.0; length=21))
@assert power_schedule(0.5, 1.0, 20, 1.0) == linear
Random.seed!(42); CUDA.seed!(42)
E1, W1, B1 = demag_J(2, 32, 8; J_start=0.5, J_final=1.0, step=20)
@assert all(isfinite, E1) && all(isfinite, W1)
println("p=1 schedule is exactly linear; demag_J default entry runs successfully")

# --- 2) p=2 跑通, 且与 p=1 结果不同 (调度确实改变) ---
Random.seed!(42); CUDA.seed!(42)
E3, W3, B3 = demag_J(2, 32, 8; J_start=0.5, J_final=1.0, step=20, p=2.0)
@assert all(isfinite, W3) && all(isfinite, E3)
@assert power_schedule(0.5, 1.0, 20, 2.0) != linear "p=2 调度未生效?"
@printf("demag_J p=2 ok: W mean = %.4f (p=1: %.4f)\n", sum(W3)/length(W3), sum(W1)/length(W1))

# --- 3) demag_h 与 cool 的非匀速 smoke test ---
Random.seed!(42); CUDA.seed!(42)
Eh, Wh, Mh = demag_h(2, 32, 8; h_start=1.0, h_final=0.0, step=20, p=0.5)
@assert all(isfinite, Wh)
println("demag_h p=0.5 ok")

Random.seed!(42); CUDA.seed!(42)
Ef, Et = cool(2, 32, 8; T_start=2.5, T_final=0.0, step=20, p=2.0)
@assert all(isfinite, Et) && all(isfinite, Ef)
println("cool p=2 ok")

println("ALL TESTS PASSED")

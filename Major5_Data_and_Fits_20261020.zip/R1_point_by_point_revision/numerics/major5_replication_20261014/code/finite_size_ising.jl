# Finite periodic square-lattice Ising thermodynamics at zero field.
# Ferdinand and Fisher, Phys. Rev. 185, 832 (1969), DOI:10.1103/PhysRev.185.832;
# Salas, J. Phys. A 34, 1311 (2001), Eqs. (2.2)--(2.6), cond-mat/0009054.
# Pure CPU implementation; no CUDA or non-standard dependencies.

"""
    log_partition_torus_2D(L, J, T; precision_bits=256)

Log partition function for the SAME L x L periodic lattice as the simulation,
with H=-J*sum_<ij>(s_i*s_j). The signed zero mode must be retained: replacing
gamma_0 by its absolute value gives the wrong high-temperature partition sum.
Arbitrary precision and logarithmic products avoid overflow and cancellation.
"""
function log_partition_torus_2D(L::Integer, J::Real, T::Real;
                                precision_bits::Integer=256)
    L >= 2 || throw(ArgumentError("L must be at least 2"))
    J >= 0 || throw(ArgumentError("J must be nonnegative"))
    T > 0 || throw(ArgumentError("T must be positive"))
    return setprecision(BigFloat, precision_bits) do
        J == 0 && return BigFloat(L)^2 * log(BigFloat(2))
        K = BigFloat(J) / BigFloat(T)
        g0 = 2K + log(tanh(K))
        # acosh(1+x)=2asinh(sqrt(x/2)) is stable near the critical zero mode.
        g = [l == 0 ? g0 :
             2asinh(sqrt(sinh(g0/2)^2 + sinpi(BigFloat(l)/(2L))^2))
             for l in 0:(2L-1)]
        log2cosh(x) = abs(x) + log1p(exp(-2abs(x)))
        log2abssinh(x) = iszero(x) ? BigFloat(-Inf) :
            abs(x) + log(-expm1(-2abs(x)))
        odd = g[2:2:end] .* (BigFloat(L)/2)
        even = g[1:2:end] .* (BigFloat(L)/2)
        logs = [sum(log2cosh, odd), sum(log2abssinh, odd),
                sum(log2cosh, even), sum(log2abssinh, even)]
        largest = maximum(logs)
        signed_sum = sum(exp(logs[j]-largest) for j in 1:3) +
                     sign(g0)*exp(logs[4]-largest)
        signed_sum > 0 || error("nonpositive partition sum")
        BigFloat(L)^2/2 * log(2sinh(2K)) - log(BigFloat(2)) +
            largest + log(signed_sum)
    end
end

"""Exact finite-L free-energy difference, returned as a total energy."""
function deltaF_torus_2D(L::Integer, J_start::Real, J_final::Real, T::Real;
                         precision_bits::Integer=256)
    return setprecision(BigFloat, precision_bits) do
        -BigFloat(T) * (log_partition_torus_2D(L,J_final,T;precision_bits) -
                       log_partition_torus_2D(L,J_start,T;precision_bits))
    end
end

# =========================================================================
# IsingV2 / equilibrium.jl
# 与非平衡轨迹独立的平衡参考：
#   1) Delta F = - integral dJ <B>_J（复合 Gauss-Legendre 热力学积分）；
#   2) 同一有限 L、同一更新规则下的临界 E_eq(L)。
# 每个 batch 给出一个完整积分样本，因此 J 节点间的相关性会被保留。
# =========================================================================
using CUDA
using LinearAlgebra
using ProgressMeter

"""n 点 Gauss-Legendre 节点和权重（Golub-Welsch，无额外包依赖）。"""
function gauss_legendre(n::Integer)
    n > 0 || throw(ArgumentError("quadrature order must be positive"))
    diagonal = zeros(Float64, n)
    offdiag = [k / sqrt(4k^2 - 1) for k in 1:n-1]
    decomposition = eigen(SymTridiagonal(diagonal, offdiag))
    nodes = decomposition.values
    weights = 2 .* decomposition.vectors[1, :].^2
    return nodes, weights
end

"""
    composite_gauss_legendre(breaks, order)

在每个相邻 `breaks` 区间上放置 `order` 个 Gauss-Legendre 节点。
"""
function composite_gauss_legendre(breaks::AbstractVector{<:Real}, order::Integer)
    length(breaks) >= 2 || throw(ArgumentError("at least two break points are required"))
    issorted(breaks) || throw(ArgumentError("break points must be sorted"))
    all(diff(breaks) .> 0) || throw(ArgumentError("break points must be strictly increasing"))
    x, w = gauss_legendre(order)
    nodes, weights = Float64[], Float64[]
    for (a0, b0) in zip(breaks[1:end-1], breaks[2:end])
        a, b = Float64(a0), Float64(b0)
        append!(nodes, (a + b) / 2 .+ (b - a) / 2 .* x)
        append!(weights, (b - a) / 2 .* w)
    end
    return nodes, weights
end

"""
    equilibrium_reference_J(d, L, batch; ...)

Estimate one independent finite-size reference sample per replica.  The
Hamiltonian is `H=-J*B` and hence `dF/dJ=-<B>`.  Returned `deltaF` and
`E_final` are vectors of length `batch`, suitable for a whole-pipeline
bootstrap together with the driven trajectories.
"""
function equilibrium_reference_J(d::Integer, L::Integer, batch::Integer;
        J_start::Real=0.5, J_final::Real=1.0, T_factor::Real=1.0,
        integration_breaks::AbstractVector{<:Real}=[J_start,
            J_start + 0.8 * (J_final-J_start),
            J_start + 0.96 * (J_final-J_start), J_final],
        quadrature_order::Integer=16, initial_relax_sweeps::Integer=1000,
        node_relax_sweeps::Integer=500, node_measurements::Integer=32,
        adaptive_node_relax::Bool=true, relaxation_factor::Real=2.0,
        sweeps_between_measurements::Integer=32,
        endpoint_relax_sweeps::Integer=max(4000,
            ceil(Int, 4.0 * L^zA_Ising(d))),
        endpoint_measurements::Integer=64, initial_state::Symbol=:random,
        node_order::Symbol=:forward,
        show_progress::Bool=true)

    J_start < J_final || throw(ArgumentError("this routine expects J_start < J_final"))
    L > 0 || throw(ArgumentError("L must be positive"))
    batch > 0 || throw(ArgumentError("batch must be positive"))
    quadrature_order > 0 || throw(ArgumentError("quadrature_order must be positive"))
    initial_relax_sweeps >= 0 || throw(ArgumentError("initial_relax_sweeps must be non-negative"))
    node_relax_sweeps >= 0 || throw(ArgumentError("node_relax_sweeps must be non-negative"))
    relaxation_factor >= 0 || throw(ArgumentError("relaxation_factor must be non-negative"))
    node_measurements > 0 || throw(ArgumentError("node_measurements must be positive"))
    sweeps_between_measurements > 0 ||
        throw(ArgumentError("sweeps_between_measurements must be positive"))
    endpoint_relax_sweeps >= 0 ||
        throw(ArgumentError("endpoint_relax_sweeps must be non-negative"))
    endpoint_measurements > 0 || throw(ArgumentError("endpoint_measurements must be positive"))
    initial_state in (:random, :ordered_plus, :ordered_minus) ||
        throw(ArgumentError("initial_state must be :random, :ordered_plus, or :ordered_minus"))
    node_order in (:forward, :reverse) ||
        throw(ArgumentError("node_order must be :forward or :reverse"))
    isapprox(J_final, T_factor; rtol=2e-6, atol=2e-6) ||
        throw(ArgumentError("a critical endpoint at T=T_factor*Tc requires J_final=T_factor"))
    first(integration_breaks) == J_start || throw(ArgumentError("integration_breaks must start at J_start"))
    last(integration_breaks) == J_final || throw(ArgumentError("integration_breaks must end at J_final"))
    T = Tc(d) * T_factor
    nodes, weights = composite_gauss_legendre(integration_breaks, quadrature_order)
    n_nodes = length(nodes)
    visit_order = node_order == :forward ? collect(eachindex(nodes)) :
        collect(reverse(eachindex(nodes)))

    lattice = init_lattice(L, T, batch; d=d, relax=initial_relax_sweeps,
                           h=0, J=nodes[first(visit_order)], progress=show_progress,
                           initial_state=initial_state)
    buf = allocate_buffers(lattice)
    B_node = zeros(Float64, n_nodes, batch)
    B_endpoint = zeros(Float64, batch)
    node_relax_used = zeros(Int, n_nodes)

    try
        progress = show_progress ? Progress(n_nodes; desc="equilibrium TI...") : nothing
        for k in visit_order
            # Near the critical endpoint, fixed short burn-in is not enough.
            # The cap xi<=L gives the finite-size relaxation scale L^z.
            distance = max(abs(nodes[k]-J_final)/abs(J_final), L^(-1/nu_Ising(d)))
            xi_estimate = min(Float64(L), distance^(-nu_Ising(d)))
            adaptive = ceil(Int, Float64(relaxation_factor)*xi_estimate^zA_Ising(d))
            node_relax_used[k] = adaptive_node_relax ? max(node_relax_sweeps,adaptive) : node_relax_sweeps
            run_mcmc_sweeps!(lattice, T, 0, nodes[k], node_relax_used[k];
                             progress=false)
            accumulator = zeros(Float64, batch)
            for _ in 1:node_measurements
                run_mcmc_sweeps!(lattice, T, 0, nodes[k], sweeps_between_measurements;
                                 progress=false)
                bond_sum!(lattice, buf)
                accumulator .+= Float64.(Array(vec(buf.B_out)))
            end
            B_node[k, :] .= accumulator ./ node_measurements
            show_progress && next!(progress)
        end

        # A separate endpoint measurement supplies E_eq(L), rather than
        # subtracting an infinite-volume number from finite-L trajectories.
        run_mcmc_sweeps!(lattice, T, 0, J_final, endpoint_relax_sweeps;
                         progress=show_progress, label="endpoint equilibration...")
        for _ in 1:endpoint_measurements
            run_mcmc_sweeps!(lattice, T, 0, J_final, sweeps_between_measurements;
                             progress=false)
            bond_sum!(lattice, buf)
            B_endpoint .+= Float64.(Array(vec(buf.B_out)))
        end
        B_endpoint ./= endpoint_measurements

        deltaF = -vec(transpose(weights) * B_node)
        E_final = -Float64(J_final) .* B_endpoint
        return (deltaF=deltaF, E_final=E_final, B_nodes=B_node,
                J_nodes=nodes, J_weights=weights, B_endpoint=B_endpoint,
                node_relax_sweeps=node_relax_used, T=Float64(T))
    finally
        CUDA.unsafe_free!(lattice)
        free!(buf)
    end
end

"""Infinite-volume square-lattice Ising free-energy density at zero field."""
function free_energy_density_2D(J::Real, T::Real; quadrature_order::Integer=256)
    J > 0 || throw(ArgumentError("J must be positive"))
    T > 0 || throw(ArgumentError("T must be positive"))
    x, w = gauss_legendre(quadrature_order)
    theta = (pi / 2) .* (x .+ 1)
    theta_weights = (pi / 2) .* w
    K = Float64(J) / Float64(T)
    a = cosh(2K) / tanh(2K)
    integral = dot(theta_weights, acosh.(a .- cos.(theta)))
    minus_beta_f = 0.5 * log(2 * sinh(2 * K)) + integral / (2 * pi)
    return -Float64(T) * minus_beta_f
end

"""Thermodynamic-limit exact Delta F for the 2D square lattice."""
function deltaF_exact_2D(L::Integer, J_start::Real, J_final::Real, T::Real)
    return L^2 * (free_energy_density_2D(J_final, T) -
                  free_energy_density_2D(J_start, T))
end

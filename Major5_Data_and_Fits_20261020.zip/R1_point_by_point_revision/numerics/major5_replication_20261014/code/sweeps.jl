# =========================================================================
# IsingV2 / sweeps.jl
# 线程块配置 / 弛豫 / 初始化
# =========================================================================
using CUDA
using ProgressMeter

# 线程块配置: 2D 与 3D 不同, 由数组维数多派发
@inline function launch_config(gpu_lattice::CuArray{Int8, 3})
    L = size(gpu_lattice, 1)
    nb = size(gpu_lattice, 3)
    threads = (16, 16, 1)
    blocks  = (cld(L, 16), cld(L, 16), nb)
    return threads, blocks, L, nb
end

@inline function launch_config(gpu_lattice::CuArray{Int8, 4})
    L = size(gpu_lattice, 1)
    nb = size(gpu_lattice, 4)
    threads = (8, 8, 4)
    blocks  = (cld(L * nb, 8), cld(L, 8), cld(L, 4))
    return threads, blocks, L, nb
end

# 单次 sweep = 棋盘色 0 + 色 1 各一遍
function _sweep_once!(gpu_lattice, T::Float32, h::Float32, J::Float32, threads, blocks, L, nb,
                      attempt_probability::Float32=1.0f0)
    if ndims(gpu_lattice) == 3
        @cuda threads=threads blocks=blocks ising_kernel!(gpu_lattice, T, h, J, Int32(0), Int32(L), attempt_probability)
        @cuda threads=threads blocks=blocks ising_kernel!(gpu_lattice, T, h, J, Int32(1), Int32(L), attempt_probability)
    else
        @cuda threads=threads blocks=blocks ising_kernel!(gpu_lattice, T, h, J, Int32(0), Int32(L), Int32(nb), attempt_probability)
        @cuda threads=threads blocks=blocks ising_kernel!(gpu_lattice, T, h, J, Int32(1), Int32(L), Int32(nb), attempt_probability)
    end
    return nothing
end

# 弛豫 n 步 (不计做功), progress=false 时静默 (供 generate_data 内层调用)
function run_mcmc_sweeps!(gpu_lattice, T::Real, h::Real, J::Real, n::Integer;
                          progress::Bool=true, label::String="sweeping",
                          attempt_probability::Real=1.0)
    0 < attempt_probability <= 1 || throw(ArgumentError("attempt_probability must lie in (0,1]"))
    threads, blocks, L, nb = launch_config(gpu_lattice)
    Tf, hf, Jf = Float32(T), Float32(h), Float32(J)
    if progress
        @showprogress label for _ in 1:n
            _sweep_once!(gpu_lattice, Tf, hf, Jf, threads, blocks, L, nb, Float32(attempt_probability))
        end
    else
        for _ in 1:n
            _sweep_once!(gpu_lattice, Tf, hf, Jf, threads, blocks, L, nb, Float32(attempt_probability))
        end
    end
    return nothing
end

# 随机 ±1 初始化并弛豫
function init_lattice(L::Integer, T::Real, num_batches::Integer;
                      d::Integer=3, relax::Integer=100, h::Real=0, J::Real=1,
                      progress::Bool=true, initial_state::Symbol=:random,
                      attempt_probability::Real=1.0)
    d in (2,3) || throw(ArgumentError("only d=2 and d=3 are supported"))
    L > 0 && iseven(L) || throw(ArgumentError("checkerboard updates with periodic boundaries require positive even L"))
    num_batches > 0 || throw(ArgumentError("num_batches must be positive"))
    relax >= 0 || throw(ArgumentError("relax must be non-negative"))
    d == 2 && num_batches > 65535 && throw(ArgumentError("2D CUDA launch requires num_batches <= 65535"))
    d == 3 && big(L)^3*num_batches > typemax(Int32) &&
        throw(ArgumentError("3D kernel indexing requires L^3 * num_batches <= 2^31-1; reduce the batch size"))
    spatial_dims = ntuple(_ -> L, d)
    cpu_lattice = if initial_state === :random
        rand(Int8[-1, 1], spatial_dims..., num_batches)
    elseif initial_state === :ordered_plus
        ones(Int8, spatial_dims..., num_batches)
    elseif initial_state === :ordered_minus
        -ones(Int8, spatial_dims..., num_batches)
    else
        throw(ArgumentError("initial_state must be :random, :ordered_plus, or :ordered_minus"))
    end
    gpu_lattice  = CuArray(cpu_lattice)
    run_mcmc_sweeps!(gpu_lattice, T, h, J, relax; progress=progress,
                     label="initializing $(d)D...", attempt_probability=attempt_probability)
    return gpu_lattice
end

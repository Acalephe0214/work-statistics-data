# =========================================================================
# IsingV2 / experiments.jl
# 实验协议: cool (温度淬火) / demag_h (h驱动) / demag_J (J驱动, 新) / drive
# -------------------------------------------------------------------------
# 注: 实验主循环的线程块配置与原始 ising.jl 保持一致 (3D: (8,8,8); 2D: (16,16,1)),
#     init 阶段沿用 run_mcmc_sweeps! 的 (8,8,4). 这保证同种子下 demag_h 与原 demag
#     产生位级一致的结果.
# =========================================================================
using CUDA
using Statistics
using ProgressMeter
using Printf

# 主循环用的线程块 (与原始 demag/cool 一致)
@inline function _loop_config(d::Integer, L::Integer, batch::Integer)
    if d == 3
        return (8, 8, 8), (cld(L * batch, 8), cld(L, 8), cld(L, 8))
    else
        return (16, 16, 1), (cld(L, 16), cld(L, 16), batch)
    end
end

# 单次棋盘 sweep (实验循环内, 用传入的 threads/blocks)
@inline function _loop_sweep!(lat, T::Float32, h::Float32, J::Float32, threads, blocks, L::Int, nb::Int,
                              attempt_probability::Float32=1.0f0)
    if ndims(lat) == 3
        @cuda threads=threads blocks=blocks ising_kernel!(lat, T, h, J, Int32(0), Int32(L), attempt_probability)
        @cuda threads=threads blocks=blocks ising_kernel!(lat, T, h, J, Int32(1), Int32(L), attempt_probability)
    else
        @cuda threads=threads blocks=blocks ising_kernel!(lat, T, h, J, Int32(0), Int32(L), Int32(nb), attempt_probability)
        @cuda threads=threads blocks=blocks ising_kernel!(lat, T, h, J, Int32(1), Int32(L), Int32(nb), attempt_probability)
    end
    return nothing
end

# -------------------------------------------------------------------------
# 温度淬火: T 从 T_start 降到 T_final, J=1, h=0. 记录每步总能量.
# 调度: T(i) = T_final + (1 - i/step)^p * (T_start - T_final). p=1 为线性 (默认).
# -------------------------------------------------------------------------
function cool(d::Integer, L::Integer, batch::Integer;
              T_start::Real=0.5, T_final::Real=0.0, step::Integer=250, p::Real=1.0,
              equil_sweeps::Integer=500, show_progress::Bool=true)
    T_schedule = power_schedule(T_start, T_final, step, p; T=Float32)
    validate_schedule(T_schedule, T_start, T_final)
    lattice = init_lattice(L, T_schedule[1], batch; d=d, relax=equil_sweeps,
                           h=0, J=1, progress=show_progress)
    buf = allocate_buffers(lattice)
    Et = CUDA.zeros(Float32, step)
    threads, blocks = _loop_config(d, L, batch)

    try
        progress = show_progress ? Progress(step; desc="cooling...") : nothing
        for i in 1:step
            T_t = T_schedule[i + 1]
            _loop_sweep!(lattice, Float32(T_t), 0.0f0, 1.0f0, threads, blocks, L, batch)
            energy_sum!(lattice, buf)
            sum!(view(Et, i:i), buf.E_out)
            if i % 20 == 0
                CUDA.synchronize()
            end
            show_progress && next!(progress)
        end
        Ef_cpu = Array(vec(buf.E_out))
        Et_cpu = Array(vec(Et))
        return Ef_cpu, Et_cpu
    finally
        CUDA.unsafe_free!(lattice)
        CUDA.unsafe_free!(Et)
        free!(buf)
    end
end

# -------------------------------------------------------------------------
# h 驱动退磁: T 固定 = T_factor*Tc, J=1.
# 调度: h(i) = h_final + (1 - i/step)^p * (h_start - h_final). p=1 为线性 (默认,
# 做功 W = Σ -M·Δh；这里 Δh=h_i-h_{i-1} 是控制参数的实际有符号增量。
# -------------------------------------------------------------------------
function demag_h(d::Integer, L::Integer, batch::Integer;
                 h_start::Real=0.5, h_final::Real=0.0, step::Integer=250,
                 T_factor::Real=1.0, p::Real=1.0, equil_sweeps::Integer=500,
                 show_progress::Bool=true, record_force_trace::Bool=true)
    Tc_val = Tc(d)
    T  = Tc_val * T_factor
    h_schedule = power_schedule(h_start, h_final, step, p; T=Float32)
    nzero = validate_schedule(h_schedule, h_start, h_final)
    p < 1 && @warn "p<1 has a singular endpoint derivative; use it only with an explicit endpoint/correction analysis" p
    nzero > 0 && @warn "Float32 rounding produced zero-size h increments" nzero step p

    lattice = init_lattice(L, T, batch; d=d, relax=equil_sweeps,
                           h=h_schedule[1], J=1, progress=show_progress)
    buf = allocate_buffers(lattice)
    Mt  = record_force_trace ? CUDA.zeros(Int64, step) : nothing
    threads, blocks = _loop_config(d, L, batch)

    try
        progress = show_progress ? Progress(step; desc="demag_h...") : nothing
        for i in 1:step
            h_prev, h_t = h_schedule[i], h_schedule[i + 1]
            dh_actual = Float64(h_t) - Float64(h_prev)
            # Inclusive work for H=-hM-JB: first jump the parameter on the
            # old configuration, then relax once at the new parameter.
            dW_h!(lattice, buf, dh_actual)
            record_force_trace && sum!(view(Mt, i:i), buf.M_out)
            _loop_sweep!(lattice, Float32(T), Float32(h_t), 1.0f0, threads, blocks, L, batch)
            if i % 20 == 0
                CUDA.synchronize()
            end
            show_progress && next!(progress)
        end
        energy_sum!(lattice, buf)
        trace = record_force_trace ? Array(vec(Mt)) : Int64[]
        return Array(vec(buf.E_out)), Array(vec(buf.W_out)), trace
    finally
        CUDA.unsafe_free!(lattice)
        record_force_trace && CUDA.unsafe_free!(Mt)
        free!(buf)
    end
end

# -------------------------------------------------------------------------
# J 驱动 (新): T 固定 = T_factor*Tc, h=0.
# 调度: J(i) = J_final + (1 - i/step)^p * (J_start - J_final). p=1 为线性 (默认).
# 做功 W = Σ -B·dJ  (B = Σ_<ij> s_i s_j).  与 demag_h 严格对称.
# 非匀速时逐步使用 ΔJ=J_i-J_{i-1}，望远镜和为 J_final-J_start。
# 末态能量 E_final = -J_final * B (h=0).
# -------------------------------------------------------------------------
function demag_J(d::Integer, L::Integer, batch::Integer;
                 J_start::Real=0.5, J_final::Real=1.0, step::Integer=250,
                 T_factor::Real=1.0, p::Real=1.0, equil_sweeps::Integer=500,
                 show_progress::Bool=true, check_critical_endpoint::Bool=true,
                 record_force_trace::Bool=true, attempt_probability::Real=1.0)
    Tc_val = Tc(d)
    T  = Tc_val * T_factor
    check_critical_endpoint && !isapprox(J_final, T_factor; rtol=2e-6, atol=2e-6) &&
        throw(ArgumentError("at fixed T=T_factor*Tc(J=1), a critical endpoint requires J_final=T_factor"))
    J_schedule = power_schedule(J_start, J_final, step, p; T=Float32)
    nzero = validate_schedule(J_schedule, J_start, J_final)
    p < 1 && @warn "p<1 has a singular endpoint derivative; use it only with an explicit endpoint/correction analysis" p
    nzero > 0 && @warn "Float32 rounding produced zero-size J increments" nzero step p

    lattice = init_lattice(L, T, batch; d=d, relax=equil_sweeps,
                           h=0, J=J_schedule[1], progress=show_progress,
                           attempt_probability=attempt_probability)
    buf = allocate_buffers(lattice)
    Bt  = record_force_trace ? CUDA.zeros(Int64, step) : nothing
    threads, blocks = _loop_config(d, L, batch)

    try
        progress = show_progress ? Progress(step; desc="demag_J...") : nothing
        for i in 1:step
            J_prev, J_t = J_schedule[i], J_schedule[i + 1]
            dJ_actual = Float64(J_t) - Float64(J_prev)
            # W_i=H(s_{i-1};J_i)-H(s_{i-1};J_{i-1})=-B*dJ_actual.
            dW_J!(lattice, buf, dJ_actual)
            record_force_trace && sum!(view(Bt, i:i), buf.B_out)
            _loop_sweep!(lattice, Float32(T), 0.0f0, J_t, threads, blocks, L, batch, Float32(attempt_probability))
            if i % 20 == 0
                CUDA.synchronize()
            end
            show_progress && next!(progress)
        end
        bond_sum!(lattice, buf)
        B_final = Array(vec(buf.B_out))
        E_final = .- Float64.(B_final) .* Float64(J_final)
        trace = record_force_trace ? Array(vec(Bt)) : Int64[]
        return E_final, Array(vec(buf.W_out)), trace
    finally
        CUDA.unsafe_free!(lattice)
        record_force_trace && CUDA.unsafe_free!(Bt)
        free!(buf)
    end
end

# -------------------------------------------------------------------------
# 任意调度驱动: h(t), J(t) 由外部向量给出. 修复原 run_exp_driving 的二次包装 bug.
# 返回每步的 m(t) (每格点磁化).
# -------------------------------------------------------------------------
function drive(d::Integer, L::Integer, batch::Integer, T::Real,
               h_schedule::AbstractVector, J_schedule::AbstractVector)
    @assert length(h_schedule) == length(J_schedule) "h/J 调度长度不一致"
    steps = length(h_schedule)
    lattice = init_lattice(L, T, batch; d=d, relax=100,
                           h=h_schedule[1], J=J_schedule[1])
    m = zeros(Float32, steps, batch)
    threads, blocks = _loop_config(d, L, batch)

    try
        @showprogress "driving..." for i in 1:steps
            m[i, :] .= Array(sum(lattice, dims=ntuple(k->k, d))[:] ) ./ Float32(L^d)
            _loop_sweep!(lattice, Float32(T), Float32(h_schedule[i]),
                         Float32(J_schedule[i]), threads, blocks, L, batch)
        end
        CUDA.synchronize()
        return m
    finally
        CUDA.unsafe_free!(lattice)
    end
end

# -------------------------------------------------------------------------
# 带打印的封装
# -------------------------------------------------------------------------
function run_experiment_cool(step::Integer; d::Integer=2, batch_size::Integer=100,
                             L::Integer=1024, T_start::Real=3.5, T_final::Real=0.0,
                             p::Real=1.0)
    println("Running cool: L=$L, d=$d, Batch=$batch_size, Steps=$step, T: $T_start -> $T_final, p=$p")
    Ef, Et = cool(d, L, batch_size; step=step, T_start=T_start, T_final=T_final, p=p)
    @printf("Defect Energy Mean: %.6f\n", mean(Ef))
    return Ef, Et
end

function run_experiment_demag_h(step::Integer; d::Integer=2, batch_size::Integer=100,
                                L::Integer=1024, h_start::Real=1.5, h_final::Real=0.0,
                                T_factor::Real=1.0, p::Real=1.0)
    E_C = Ec(d)
    println("Running demag_h: L=$L, d=$d, Batch=$batch_size, Steps=$step, h: $h_start -> $h_final, T/Tc=$T_factor, p=$p")
    E, W, M = demag_h(d, L, batch_size; step=step, h_start=h_start, h_final=h_final, T_factor=T_factor, p=p)
    @printf("Defect Energy Mean: %.6f\n", mean(E) - E_C * L^d)
    @printf("Work mean:  %.6f\n", mean(W))
    @printf("Work var:   %.6f\n", var(W))
    return E, W, M
end

function run_experiment_demag_J(step::Integer; d::Integer=2, batch_size::Integer=100,
                                L::Integer=1024, J_start::Real=0.5, J_final::Real=1.0,
                                T_factor::Real=1.0, p::Real=1.0)
    E_C = Ec(d)
    println("Running demag_J: L=$L, d=$d, Batch=$batch_size, Steps=$step, J: $J_start -> $J_final, T/Tc=$T_factor, p=$p")
    E, W, Bt = demag_J(d, L, batch_size; step=step, J_start=J_start, J_final=J_final, T_factor=T_factor, p=p)
    @printf("Final Energy Mean: %.6f\n", mean(E))
    @printf("Defect Energy Mean (vs Ec*L^d at J=1): %.6f\n", mean(E) - E_C * L^d)
    @printf("Work mean:  %.6f\n", mean(W))
    @printf("Work var:   %.6f\n", var(W))
    return E, W, Bt
end

# =========================================================================
# IsingV2 / constants.jl
# 临界温度、临界能量密度与分析所用临界指数的单一来源 (J=1 约定)
# =========================================================================

const Tc_2D = 2.0 / log(1 + sqrt(2))
# K_c=0.221654626(5), Ferrenberg, Xu, and Landau, PRE 97, 043301 (2018).
const Tc_3D = 4.51152326

# 每格点临界能量 (J=1, h=0)。注意这不是基态能量。
const Ec_2D = -sqrt(2)
# Feng and Blote, PRE 81, 031103 (2010): e_c=-0.990604(4).
# 旧值 -0.99016 在 L=128 时造成约 931 的总能量背景误差。
const Ec_3D = -0.990604

# 仅供理论曲线/指数比较使用；它们不参与 Metropolis 接受率。
const nu_2D = 1.0
const nu_3D = 0.629912
const zA_2D = 2.1665
const zA_3D = 2.0245

@inline Tc(d::Integer) = d == 2 ? Tc_2D : d == 3 ? Tc_3D : error("Tc only defined for d=2 or 3")
@inline Ec(d::Integer) = d == 2 ? Ec_2D : d == 3 ? Ec_3D : error("Ec only defined for d=2 or 3")
@inline nu_Ising(d::Integer) = d == 2 ? nu_2D : d == 3 ? nu_3D : error("nu only defined for d=2 or 3")
@inline zA_Ising(d::Integer) = d == 2 ? zA_2D : d == 3 ? zA_3D : error("z_A only defined for d=2 or 3")

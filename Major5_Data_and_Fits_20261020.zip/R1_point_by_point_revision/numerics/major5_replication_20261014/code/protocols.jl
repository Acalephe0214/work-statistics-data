# =========================================================================
# IsingV2 / protocols.jl
# 纯 CPU 的协议工具。调度向量同时包含初、末端；做功与 CUDA 动力学
# 必须读取同一组已经舍入的参数，避免“动力学没看到、做功却计入”的微小增量。
# =========================================================================

"""
    power_schedule(x_start, x_final, nsteps, p; T=Float32)

返回长度 `nsteps+1` 的幂律协议
`x_i=x_final+(1-i/nsteps)^p(x_start-x_final)`，`i=0,...,nsteps`。
"""
function power_schedule(x_start::Real, x_final::Real, nsteps::Integer, p::Real;
                        T::Type{<:AbstractFloat}=Float32)
    nsteps > 0 || throw(ArgumentError("nsteps must be positive"))
    p > 0 || throw(ArgumentError("protocol exponent p must be positive"))
    xs = Vector{T}(undef, nsteps + 1)
    x0, x1, pp = Float64(x_start), Float64(x_final), Float64(p)
    for i in 0:nsteps
        s = 1.0 - i / nsteps
        xs[i + 1] = T(x1 + s^pp * (x0 - x1))
    end
    xs[1] = T(x_start)
    xs[end] = T(x_final)
    return xs
end

"""返回调度中实际（已经舍入）的逐步增量。"""
protocol_increments(xs::AbstractVector) = diff(xs)

"""检查端点和望远镜恒等式，并返回有限精度造成的零增量步数。"""
function validate_schedule(xs::AbstractVector, x_start::Real, x_final::Real)
    length(xs) >= 2 || throw(ArgumentError("a schedule needs two endpoints"))
    xs[1] == eltype(xs)(x_start) || error("schedule does not start at x_start")
    xs[end] == eltype(xs)(x_final) || error("schedule does not end at x_final")
    increments = diff(Float64.(xs))
    isapprox(sum(increments), Float64(xs[end]) - Float64(xs[1]);
             rtol=0, atol=32eps(Float64)) || error("protocol increments do not telescope")
    return count(iszero, diff(xs))
end

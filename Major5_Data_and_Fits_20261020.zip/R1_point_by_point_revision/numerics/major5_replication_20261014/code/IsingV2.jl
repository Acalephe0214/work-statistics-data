# =========================================================================
# IsingV2.jl  —  模块入口
#   include("IsingV2/IsingV2.jl"); using .IsingV2
# =========================================================================
module IsingV2

using CUDA
using Statistics
using ProgressMeter
using Printf

const ROOT = dirname(@__FILE__)
include(joinpath(ROOT, "constants.jl"))
include(joinpath(ROOT, "protocols.jl"))
include(joinpath(ROOT, "finite_size_ising.jl"))
include(joinpath(ROOT, "kernels.jl"))
include(joinpath(ROOT, "buffers.jl"))
include(joinpath(ROOT, "sweeps.jl"))
include(joinpath(ROOT, "work.jl"))
include(joinpath(ROOT, "equilibrium.jl"))
include(joinpath(ROOT, "experiments.jl"))
include(joinpath(ROOT, "scaling.jl"))

# 导出公共 API
export Tc, Ec, Tc_2D, Tc_3D, Ec_2D, Ec_3D,
       nu_Ising, zA_Ising, nu_2D, nu_3D, zA_2D, zA_3D,
       power_schedule, protocol_increments, validate_schedule,
       Buffers, allocate_buffers, free!,
       init_lattice, run_mcmc_sweeps!,
       bond_sum!, energy_sum!, dW_h!, dW_J!,
       gauss_legendre, composite_gauss_legendre, equilibrium_reference_J,
       free_energy_density_2D, deltaF_exact_2D,
       log_partition_torus_2D, deltaF_torus_2D,
       cool, demag_h, demag_J, drive,
       run_experiment_cool, run_experiment_demag_h, run_experiment_demag_J,
       generate_data_cool, generate_data_demag_h, generate_data_deJ

end # module

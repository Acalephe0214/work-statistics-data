# Exhaustive finite-state reference, independent of the CUDA implementation.
# Feasible for 2D L=4 and 3D L=2; the latter is a periodic multigraph with
# opposite neighbours coincident, exactly as in the production convention.
using LinearAlgebra

struct ExactIsingReference
    d::Int
    L::Int
    spins::Matrix{Int8}
    bonds::Vector{Int}
    flips::Matrix{Int}
    site_order::Vector{Int}
end

function ExactIsingReference(d::Int, L::Int)
    iseven(L) && L >= 2 || error("an even lattice is required")
    V = L^d
    V <= 20 || error("exhaustive reference restricted to at most 20 spins")
    dims = ntuple(_ -> L,d)
    coords = collect(CartesianIndices(dims))[:]
    linear = LinearIndices(dims)
    ns = 1 << V
    spins = Matrix{Int8}(undef,V,ns)
    flips = Matrix{Int}(undef,ns,V)
    for site in 1:V, state in 0:ns-1
        spins[site,state+1] = (state >> (site-1)) & 1 == 1 ? Int8(1) : Int8(-1)
        flips[state+1,site] = xor(state,1 << (site-1)) + 1
    end
    bonds = zeros(Int,ns)
    for (site,coord) in enumerate(coords), axis in 1:d
        adjacent = CartesianIndex(ntuple(a -> a == axis ? mod1(coord[a]+1,L) : coord[a],d))
        j = linear[adjacent]
        for state in 1:ns
            bonds[state] += Int(spins[site,state])*Int(spins[j,state])
        end
    end
    site_order = [i for color in 0:1 for i in 1:V if sum(Tuple(coords[i])) % 2 == color]
    return ExactIsingReference(d,L,spins,bonds,flips,site_order)
end

function exact_gibbs(model::ExactIsingReference,J,T)
    exponent = Float64(J)/Float64(T) .* model.bonds
    offset = maximum(exponent)
    weights = exp.(exponent .- offset)
    Zscaled = sum(weights)
    return weights ./ Zscaled, log(Zscaled)+offset
end

function exact_rates(model::ExactIsingReference,J,T,attempt_probability=1.0)
    0 < attempt_probability <= 1 || error("attempt_probability must lie in (0,1]")
    rates = Matrix{Float64}(undef,size(model.flips))
    for site in axes(rates,2), state in axes(rates,1)
        deltaE = -Float64(J)*(model.bonds[model.flips[state,site]]-model.bonds[state])
        rates[state,site] = attempt_probability * min(1.0,exp(-deltaE/Float64(T)))
    end
    return rates
end

function exact_sweep!(weights::AbstractMatrix,scratch::AbstractMatrix,
                      model::ExactIsingReference,rates)
    # All updates of one sublattice commute. Applying each site successively
    # therefore evaluates the same transition law as a parallel half-sweep.
    for site in model.site_order
        for col in axes(weights,2), state in axes(weights,1)
            paired = model.flips[state,site]
            scratch[state,col] = (1-rates[state,site])*weights[state,col] +
                                 rates[paired,site]*weights[paired,col]
        end
        copyto!(weights,scratch)
    end
    return weights
end

function exact_work_reference(model::ExactIsingReference,schedule,T;
                               attempt_probability=1.0)
    probability,logZi = exact_gibbs(model,first(schedule),T)
    _,logZf = exact_gibbs(model,last(schedule),T)
    weights = hcat(probability,zero(probability),zero(probability),copy(probability))
    scratch = similar(weights)
    for i in 2:length(schedule)
        deltaJ = Float64(schedule[i])-Float64(schedule[i-1])
        for state in axes(weights,1)
            w = -model.bonds[state]*deltaJ
            weights[state,3] += 2w*weights[state,2] + w^2*weights[state,1]
            weights[state,2] += w*weights[state,1]
            weights[state,4] *= exp(-w/T)
        end
        rates = exact_rates(model,schedule[i],T,attempt_probability)
        exact_sweep!(weights,scratch,model,rates)
    end
    meanW = sum(view(weights,:,2))
    meanW2 = sum(view(weights,:,3))
    return (meanW=meanW,varW=meanW2-meanW^2,meanW2=meanW2,
            jarzynski=sum(view(weights,:,4)),partition_ratio=exp(logZf-logZi),
            meanB=dot(view(weights,:,1),model.bonds),mass=sum(view(weights,:,1)))
end

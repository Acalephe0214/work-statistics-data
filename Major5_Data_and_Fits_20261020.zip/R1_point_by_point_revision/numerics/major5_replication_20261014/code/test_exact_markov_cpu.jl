include(joinpath(@__DIR__,"constants.jl"))
include(joinpath(@__DIR__,"protocols.jl"))
include(joinpath(@__DIR__,"finite_size_ising.jl"))
include(joinpath(@__DIR__,"exact_markov_reference.jl"))
using Test, Printf

@testset "Exact checkerboard transition and work" begin
    for (d,L) in ((2,4),(3,2))
        model = ExactIsingReference(d,L)
        T = Float64(Float32(Tc(d)))
        for attempt in (1.0,0.5), J in (0.5,1.0)
            prob,logZ = exact_gibbs(model,J,T)
            weights = reshape(copy(prob),:,1)
            exact_sweep!(weights,similar(weights),model,exact_rates(model,J,T,attempt))
            @test maximum(abs.(vec(weights)-prob)) < 2e-15
            @test sum(weights) ≈ 1 atol=2e-14
            if d == 2
                @test logZ ≈ Float64(log_partition_torus_2D(L,J,T)) atol=2e-13
            end
        end
        for attempt in (1.0,0.5), p in (1.0,1.2), steps in (2,8)
            schedule = power_schedule(0.5,1.0,steps,p;T=Float32)
            ref = exact_work_reference(model,schedule,T;attempt_probability=attempt)
            @test ref.mass ≈ 1 atol=3e-14
            @test ref.varW > 0
            @test ref.jarzynski ≈ ref.partition_ratio rtol=3e-13
            @test ref.meanW >= -T*log(ref.partition_ratio)-1e-12
            @printf("d=%d L=%d attempt=%.1f p=%.1f tau=%d: meanW=%.12g varW=%.12g\n",
                    d,L,attempt,p,steps,ref.meanW,ref.varW)
        end
    end
end

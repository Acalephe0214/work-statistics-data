# =========================================================================
# IsingV2 / kernels.jl
# CUDA 内核: Metropolis 更新 (含 J, h), 键和 B, 能量 E
# =========================================================================
using CUDA

@inline function _metropolis_accept(delta_E::Float32, T::Float32,
                                    attempt_probability::Float32)
    if attempt_probability == 1.0f0
        return delta_E <= 0.0f0 || rand(Float32) < exp(-delta_E / T)
    end
    acceptance = delta_E <= 0.0f0 ? 1.0f0 : exp(-delta_E / T)
    return rand(Float32) < attempt_probability * acceptance
end

# -------------------------------------------------------------------------
# 1. Metropolis 更新核 (棋盘格分解)
#    delta_E = 2 * J * s_i * s_sum + 2 * h * s_i
# -------------------------------------------------------------------------

# 2D: lattice 形状 (L, L, batch)
function ising_kernel!(lattice::CuDeviceArray{Int8, 3},
                       T::Float32, h::Float32, J::Float32,
                       color::Int32, L::Int32, attempt_probability::Float32=1.0f0)
    idx = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    idy = (blockIdx().y - 1) * blockDim().y + threadIdx().y
    b   = blockIdx().z

    if idx <= L && idy <= L
        if (idx + idy) % 2 == color
            s_i = lattice[idx, idy, b]

            idy_top    = idy == 1 ? L : idy - 1
            idy_bottom = idy == L ? 1 : idy + 1
            idx_left   = idx == 1 ? L : idx - 1
            idx_right  = idx == L ? 1 : idx + 1

            top    = Float32(lattice[idx, idy_top, b])
            bottom = Float32(lattice[idx, idy_bottom, b])
            left   = Float32(lattice[idx_left, idy, b])
            right  = Float32(lattice[idx_right, idy, b])

            s_sum = top + bottom + left + right
            delta_E = 2.0f0 * J * s_i * s_sum + 2.0f0 * h * s_i

            if _metropolis_accept(delta_E, T, attempt_probability)
                lattice[idx, idy, b] = -s_i
            end
        end
    end
    return nothing
end

# 3D: lattice 形状 (L, L, L, batch); (x, batch) 打包进 x 维绕过三维网格限制
function ising_kernel!(lattice::CuDeviceArray{Int8, 4},
                       T::Float32, h::Float32, J::Float32,
                       color::Int32, L::Int32, num_batches::Int32,
                       attempt_probability::Float32=1.0f0)
    idz = (blockIdx().z - 1) * blockDim().z + threadIdx().z
    idy = (blockIdx().y - 1) * blockDim().y + threadIdx().y
    x_and_batch = (blockIdx().x - 1) * blockDim().x + threadIdx().x

    if idz <= L && idy <= L && x_and_batch <= (L * num_batches)
        idx       = (x_and_batch - 1) % L + 1
        batch_idx = (x_and_batch - 1) ÷ L + 1

        if (idx + idy + idz) % 2 == color
            s_i = lattice[idx, idy, idz, batch_idx]

            idx_left   = idx == 1 ? L : idx - 1
            idx_right  = idx == L ? 1 : idx + 1
            idy_top    = idy == 1 ? L : idy - 1
            idy_bottom = idy == L ? 1 : idy + 1
            idz_front  = idz == 1 ? L : idz - 1
            idz_back   = idz == L ? 1 : idz + 1

            left   = Float32(lattice[idx_left, idy, idz, batch_idx])
            right  = Float32(lattice[idx_right, idy, idz, batch_idx])
            top    = Float32(lattice[idx, idy_top, idz, batch_idx])
            bottom = Float32(lattice[idx, idy_bottom, idz, batch_idx])
            front  = Float32(lattice[idx, idy, idz_front, batch_idx])
            back   = Float32(lattice[idx, idy, idz_back, batch_idx])

            s_sum = top + bottom + left + right + front + back
            delta_E = 2.0f0 * J * s_i * s_sum + 2.0f0 * h * s_i

            if _metropolis_accept(delta_E, T, attempt_probability)
                lattice[idx, idy, idz, batch_idx] = -s_i
            end
        end
    end
    return nothing
end

# -------------------------------------------------------------------------
# 2. 键和核: 写 s * (s_right + s_down[+ s_front]), 求和得 B = Σ_<ij> s_i s_j
#    (每条键只数正方向, 避免重复计数)
# -------------------------------------------------------------------------

function bond_sum_kernel!(lattice::CuDeviceArray{Int8, 3}, B_local::CuDeviceArray{Int8, 3}, L::Int32)
    i = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    j = (blockIdx().y - 1) * blockDim().y + threadIdx().y
    b = blockIdx().z
    if i <= L && j <= L && b <= size(lattice, 3)
        i_next = ifelse(i == L, 1, i + 1)
        j_next = ifelse(j == L, 1, j + 1)
        s      = lattice[i, j, b]
        s_right = lattice[i_next, j, b]
        s_down  = lattice[i, j_next, b]
        B_local[i, j, b] = s * (s_right + s_down)
    end
    return nothing
end

function bond_sum_kernel!(lattice::CuDeviceArray{Int8, 4}, B_local::CuDeviceArray{Int8, 4}, L::Int32, N_batch::Int32)
    idx = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    total = L * L * L * N_batch
    if idx <= total
        tmp = idx - 1
        x = tmp % L + 1; tmp = tmp ÷ L
        y = tmp % L + 1; tmp = tmp ÷ L
        z = tmp % L + 1
        b = tmp ÷ L + 1
        xp = ifelse(x == L, 1, x + 1)
        yp = ifelse(y == L, 1, y + 1)
        zp = ifelse(z == L, 1, z + 1)
        s   = lattice[x, y, z, b]
        s_x = lattice[xp, y, z, b]
        s_y = lattice[x, yp, z, b]
        s_z = lattice[x, y, zp, b]
        B_local[x, y, z, b] = s * (s_x + s_y + s_z)
    end
    return nothing
end

# -------------------------------------------------------------------------
# 3. 能量核: 写 -s * (s_right + s_down[+ s_front]), 求和得 E (J=1, h=0 时)
#    保留以便与旧 Ec 对比 "缺陷能"; 通用能量应由 E = -J*B - h*M 推导
# -------------------------------------------------------------------------

function energy_kernel!(lattice::CuDeviceArray{Int8, 3}, E_local::CuDeviceArray{Int8, 3}, L::Int32)
    i = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    j = (blockIdx().y - 1) * blockDim().y + threadIdx().y
    b = blockIdx().z
    if i <= L && j <= L && b <= size(lattice, 3)
        i_next = ifelse(i == L, 1, i + 1)
        j_next = ifelse(j == L, 1, j + 1)
        s      = lattice[i, j, b]
        s_right = lattice[i_next, j, b]
        s_down  = lattice[i, j_next, b]
        E_local[i, j, b] = -s * (s_right + s_down)
    end
    return nothing
end

function energy_kernel!(lattice::CuDeviceArray{Int8, 4}, E_local::CuDeviceArray{Int8, 4}, L::Int32, N_batch::Int32)
    idx = (blockIdx().x - 1) * blockDim().x + threadIdx().x
    total = L * L * L * N_batch
    if idx <= total
        tmp = idx - 1
        x = tmp % L + 1; tmp = tmp ÷ L
        y = tmp % L + 1; tmp = tmp ÷ L
        z = tmp % L + 1
        b = tmp ÷ L + 1
        xp = ifelse(x == L, 1, x + 1)
        yp = ifelse(y == L, 1, y + 1)
        zp = ifelse(z == L, 1, z + 1)
        s   = lattice[x, y, z, b]
        s_x = lattice[xp, y, z, b]
        s_y = lattice[x, yp, z, b]
        s_z = lattice[x, y, zp, b]
        E_local[x, y, z, b] = -s * (s_x + s_y + s_z)
    end
    return nothing
end

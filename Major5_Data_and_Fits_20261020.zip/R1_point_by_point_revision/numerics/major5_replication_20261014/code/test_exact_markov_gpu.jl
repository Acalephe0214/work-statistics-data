# Statistical comparison with the full finite-state transition law, not only
# a fluctuation identity. Every replica starts from an exact Gibbs sample.
include(joinpath(@__DIR__,"IsingV2.jl"))
include(joinpath(@__DIR__,"exact_markov_reference.jl"))
using .IsingV2, CUDA, Random, Statistics, Test, Printf

CUDA.functional() || error("a functional CUDA GPU is required")
const EXACT_GPU_BATCH = parse(Int,get(ENV,"EXACT_GPU_BATCH","50000"))
EXACT_GPU_BATCH <= 65535 || error("2D launch requires batch <= 65535")

@testset "CUDA against exact Markov work moments" begin
    for (d,L) in ((2,4),(3,2))
        model = ExactIsingReference(d,L)
        T = Float32(Tc(d))
        prob,_ = exact_gibbs(model,0.5,T)
        cdf = cumsum(prob); cdf[end] = 1.0
        for attempt in (1.0,0.5), p in (1.0,1.2)
            seed = 20261009 + 100d + round(Int,10attempt) + round(Int,10p)
            Random.seed!(seed); CUDA.seed!(seed)
            selected = searchsortedfirst.(Ref(cdf),rand(EXACT_GPU_BATCH))
            host = reshape(model.spins[:,selected],ntuple(_ -> L,d)...,EXACT_GPU_BATCH)
            lattice = CuArray(host)
            buf = allocate_buffers(lattice)
            threads,blocks = IsingV2._loop_config(d,L,EXACT_GPU_BATCH)
            schedule = power_schedule(0.5,1.0,8,p;T=Float32)
            reference = exact_work_reference(model,schedule,Float64(T);attempt_probability=attempt)
            try
                for i in 2:length(schedule)
                    dW_J!(lattice,buf,Float64(schedule[i])-Float64(schedule[i-1]))
                    IsingV2._loop_sweep!(lattice,T,0.0f0,schedule[i],threads,blocks,L,
                                         EXACT_GPU_BATCH,Float32(attempt))
                end
                bond_sum!(lattice,buf)
                W = Array(vec(buf.W_out)); B = Float64.(Array(vec(buf.B_out)))
                observables = (("W",W,reference.meanW),
                               ("W2",W.^2,reference.meanW2),
                               ("B_final",B,reference.meanB),
                               ("exp(-W/T)",exp.(-W/Float64(T)),reference.partition_ratio))
                for (name,values,truth) in observables
                    se = std(values)/sqrt(length(values))
                    zscore = abs(mean(values)-truth)/se
                    @printf("d=%d L=%d attempt=%.1f p=%.1f %s: %.9g +/- %.3g exact %.9g z=%.3f\n",
                             d,L,attempt,p,name,mean(values),se,truth,zscore)
                    @test abs(mean(values)-truth) < 6se + 1e-6*max(1,abs(truth))
                end
            finally
                CUDA.unsafe_free!(lattice); free!(buf)
            end
        end
    end
end

@testset "Zero-field stripe diagnostic" begin
    for d in (2,3)
        L,batch = 8,64
        stripe = Array{Int8}(undef,ntuple(_ -> L,d))
        for index in CartesianIndices(stripe)
            power = d == 2 ? index[1]-1 : index[1]-1+div(index[2]-1,2)
            stripe[index] = iseven(power) ? 1 : -1
        end
        host = repeat(reshape(stripe,size(stripe)...,1),ntuple(_->1,d)...,batch)
        for attempt in (1.0,0.5)
            lattice = CuArray(host)
            try
                run_mcmc_sweeps!(lattice,Tc(d),0,0.5,2;progress=false,attempt_probability=attempt)
                if attempt == 1.0
                    @test Array(lattice) == host
                else
                    @test Array(lattice) != host
                end
            finally
                CUDA.unsafe_free!(lattice)
            end
        end
    end
end

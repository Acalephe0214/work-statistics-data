# Exact small-lattice checks for the protocol/work convention.
include(joinpath(@__DIR__, "IsingV2.jl"))
using .IsingV2
using CUDA

@assert CUDA.functional()

# On an ordered LxL square lattice B=2L^2.  A parameter jump must satisfy
# W=H(s,J1)-H(s,J0)=-B*(J1-J0) before any stochastic update.
L, batch = 4, 3
lattice = init_lattice(L, Tc(2), batch; d=2, relax=0,
                       initial_state=:ordered_plus, progress=false)
buf = allocate_buffers(lattice)
try
    B = 2 * L^2
    dW_J!(lattice, buf, 0.1)
    @assert all(Array(vec(buf.W_out)) .≈ -B*0.1)
    dW_J!(lattice, buf, -0.1)
    @assert all(Array(vec(buf.W_out)) .≈ 0.0)

    # h jump on the same state: M=L^2 and Delta W=-M Delta h.
    dW_h!(lattice, buf, -0.2)
    @assert all(Array(vec(buf.W_out)) .≈ L^2*0.2)
finally
    CUDA.unsafe_free!(lattice)
    free!(buf)
end

for p in (0.5, 1.0, 2.0)
    xs = power_schedule(0.5, 1.0, 8192, p)
    validate_schedule(xs, 0.5, 1.0)
    @assert sum(Float64.(diff(xs))) ≈ 0.5
end

println("2D work/protocol checks passed")

# The same bond-count check in 3D: B=3L^3.
lattice3 = init_lattice(L, Tc(3), batch; d=3, relax=0,
                        initial_state=:ordered_plus, progress=false)
buf3 = allocate_buffers(lattice3)
try
    bond_sum!(lattice3, buf3)
    @assert all(Array(vec(buf3.B_out)) .== 3 * L^3)
    dW_J!(lattice3, buf3, 0.125)
    @assert all(Array(vec(buf3.W_out)) .≈ -(3 * L^3) * 0.125)
finally
    CUDA.unsafe_free!(lattice3)
    free!(buf3)
end

println("2D/3D WORK/PROTOCOL GPU TESTS PASSED")

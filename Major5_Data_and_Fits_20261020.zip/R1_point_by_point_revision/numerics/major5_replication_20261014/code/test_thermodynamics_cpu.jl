# Pure numerical checks of the exact 2D background and quadrature.
include(joinpath(@__DIR__, "constants.jl"))
include(joinpath(@__DIR__, "protocols.jl"))
using LinearAlgebra

# Minimal copy of the pure quadrature helpers avoids loading CUDA in this CPU test.
function gl(n)
    offdiag = [k/sqrt(4k^2-1) for k in 1:n-1]
    e = eigen(SymTridiagonal(zeros(n), offdiag))
    e.values, 2 .* e.vectors[1,:].^2
end
function f2(J,T)
    x,w=gl(256); theta=(pi/2).*(x.+1); K=J/T
    a=cosh(2K)/tanh(2K)
    mbf=0.5*log(2*sinh(2*K))+dot((pi/2).*w,acosh.(a.-cos.(theta)))/(2*pi)
    -T*mbf
end

deltaf = f2(1.0,Tc_2D)-f2(0.5,Tc_2D)
@assert isapprox(deltaf, -0.42193373570535; atol=2e-13)
@assert isapprox(Ec_2D, -sqrt(2); atol=eps())
println("THERMODYNAMIC CPU TESTS PASSED")

# =========================================================================
# IsingV2 / work.jl
# 做功累加: H=-JB-hM，故 dW=-M*Delta h-B*Delta J。
# Delta h/Delta J 必须是“新参数减旧参数”的实际有符号增量。
# =========================================================================
using CUDA

# 键和归约: 启动核 + sum!, 结果写入 buf.B_out
function bond_sum!(lattice::CuArray{Int8, N}, buf::Buffers{N}) where N
    L = size(lattice, 1)
    if N == 3
        nb = size(lattice, 3)
        threads = (16, 16, 1)
        blocks  = (cld(L, 16), cld(L, 16), nb)
        @cuda threads=threads blocks=blocks bond_sum_kernel!(lattice, buf.B_local, Int32(L))
    else
        nb = size(lattice, 4)
        threads = 256
        blocks  = cld(L * L * L * nb, threads)
        @cuda threads=threads blocks=blocks bond_sum_kernel!(lattice, buf.B_local, Int32(L), Int32(nb))
    end
    sum!(buf.B_out, buf.B_local)
    return nothing
end

# 能量归约 (J=1, h=0 定义下的 -B), 结果写入 buf.E_out
function energy_sum!(lattice::CuArray{Int8, N}, buf::Buffers{N}) where N
    L = size(lattice, 1)
    if N == 3
        nb = size(lattice, 3)
        threads = (16, 16, 1)
        blocks  = (cld(L, 16), cld(L, 16), nb)
        @cuda threads=threads blocks=blocks energy_kernel!(lattice, buf.E_local, Int32(L))
    else
        nb = size(lattice, 4)
        threads = 256
        blocks  = cld(L * L * L * nb, threads)
        @cuda threads=threads blocks=blocks energy_kernel!(lattice, buf.E_local, Int32(L), Int32(nb))
    end
    sum!(buf.E_out, buf.E_local)
    return nothing
end

# h 驱动做功: W .+= -M * Delta h（用参数跳变前的构型）
function dW_h!(lattice, buf::Buffers, dh::Real)
    sum!(buf.M_out, lattice)
    buf.W_out .+= .- Float64.(buf.M_out) .* Float64(dh)
    return nothing
end

# J 驱动做功: W .+= -B * Delta J（用参数跳变前的构型）
function dW_J!(lattice, buf::Buffers, dJ::Real)
    bond_sum!(lattice, buf)
    buf.W_out .+= .- Float64.(buf.B_out) .* Float64(dJ)
    return nothing
end

"""Long-duration cumulant figures and fitting-window checks for Major 5.

The cumulant figures show the eighteen durations used in the principal fits.
The window comparison uses the data required for its lower-cutoff scan.
No raw samples or manuscript files are edited.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / 'major5_followup_20261010'
AUDIT = HERE.parent / 'major5_audit_20261009'
PRESENTATION = HERE / 'presentation_20261015'
OUT = PRESENTATION / 'figures'
sys.path.insert(0, str(OLD))
from audit_signed_background import inputs, profile, signed_fit

OFFSET = 5.5392487898209275e-6
BLUE = '#276A9D'; ORANGE = '#BC651F'; DARK = '#252525'
CUTS = (512, 1024, 2048, 4096, 8192)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.titlesize': 11, 'axes.labelsize': 11, 'legend.fontsize': 8,
    'axes.spines.top': False, 'axes.spines.right': False,
    'pdf.fonttype': 42, 'savefig.dpi': 180})


def read(path):
    return pd.read_csv(path, sep='\t', float_precision='round_trip')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def final_points():
    combined = read(HERE / 'analysis/points.tsv').query('dataset == "combined"')
    window_points = pd.concat([read(OLD / f'analysis_d{d}/points.tsv')
        .query('dataset == "pooled" and 512 <= tau < 2048') for d in (2, 3)])
    result = pd.concat([combined, window_points], ignore_index=True)
    result['dataset'] = 'final'
    assert not result.duplicated(['d', 'L', 'p', 'tau']).any()
    for (d, p), group in result.groupby(['d', 'p']):
        assert sum(group.tau >= 2048) == 18
        assert group.tau.max() == (131072 if d == 2 else 65536)
    return result.sort_values(['d', 'p', 'tau'])


def scan_windows(points):
    fits = []; checks = []
    main = read(HERE / 'analysis/fits_two_power.tsv').query('dataset == "combined"')
    for d in (2, 3):
        rows = points[points.d == d].to_dict('records')
        nu, z = (1., 2.1665) if d == 2 else (.629912, 2.0245)
        ref = (rows[0]['delta_f'], rows[0]['se_delta_f'])
        for p in (1., 1.2):
            alpha = p * d * nu / (1 + p * z * nu)
            for obs in ('c1', 'c2'):
                for cut in CUTS:
                    t, y, C = inputs(rows, d, 'final', p, obs, cut, ref, OFFSET)
                    result = profile(t, y, C, alpha, signed=True)
                    base = dict(d=d, L=512 if d == 2 else 128, p=p,
                        observable=obs, cutoff=cut, n_points=len(t),
                        tau_min=t[0], tau_max=t[-1], theory=alpha)
                    fits.append(dict(**base, **result))
                    if cut == 2048:
                        saved = main[(main.d == d) & (main.p == p) &
                                     (main.observable == obs)].iloc[0]
                        for field in ('a', 'low95', 'high95', 'chi2_min', 'chi2_theory'):
                            error = abs(float(saved[field]) - result[field])
                            assert error < 2e-6, (base, field, error)
                            checks.append(dict(**base, check='principal_reproduction',
                                               field=field, absolute_error=error))
                    # Original power basis independently checks the stable basis.
                    Lc = np.linalg.cholesky(C); yw = np.linalg.solve(Lc, y)
                    fun, _ = signed_fit(t, y, C)
                    for a in (alpha, result['a'], result['low95'], result['high95']):
                        if not 1e-5 < a < 1 - 1e-5:
                            continue
                        X = np.linalg.solve(Lc, np.column_stack((t**(-a), 1 / t)))
                        norms = np.linalg.norm(X, axis=0); V = X / norms
                        Q, R = np.linalg.qr(V)
                        b = np.linalg.solve(R, Q.T @ yw)
                        if b[0] < 0:
                            b = np.array([0., V[:, 1] @ yw])
                        direct = np.sum((yw - V @ b)**2)
                        error = abs(direct - fun(a)[0])
                        assert error < 1e-6, (base, a, error)
                        checks.append(dict(**base, check='original_basis_QR',
                                           field=str(a), absolute_error=error))
    table = pd.DataFrame(fits)
    table.to_csv(PRESENTATION / 'window_profiles.tsv', sep='\t', index=False,
                 float_format='%.17g')
    pd.DataFrame(checks).to_csv(PRESENTATION / 'window_fit_checks.tsv', sep='\t',
                               index=False, float_format='%.17g')
    return table


def save(fig, name):
    fig.savefig(OUT / (name + '.pdf'), bbox_inches='tight')
    fig.savefig(OUT / (name + '.png'), bbox_inches='tight')
    plt.close(fig)


def cumulants(d, points, intervals, plot_rows, curve_rows):
    single = read(HERE / 'analysis/fits_single_power.tsv').query('dataset == "combined"')
    double = read(HERE / 'analysis/fits_two_power.tsv').query('dataset == "combined"')
    fig, axes = plt.subplots(2, 2, figsize=(10, 6.8), layout='constrained')
    for i, obs in enumerate(('c1', 'c2')):
        for j, p in enumerate((1., 1.2)):
            ax = axes[i, j]
            f = single[(single.d == d) & (single.p == p) & (single.observable == obs)].iloc[0]
            g = double[(double.d == d) & (double.p == p) & (double.observable == obs)].iloc[0]
            alpha = float(f.theory); add = OFFSET if d == 2 and obs == 'c1' else 0.
            assert abs(alpha - g.theory) < 1e-12
            assert f.tau_min == g.tau_min and f.tau_max == g.tau_max
            rr = points[(points.d == d) & (points.p == p) &
                        (points.tau >= f.tau_min) & (points.tau <= f.tau_max)]
            assert len(rr) == 18
            t = rr.tau.to_numpy(dtype=float); y = rr[obs].to_numpy(dtype=float)
            lows = []; highs = []
            for r in rr.itertuples():
                b = intervals[(intervals.d == d) & (intervals.p == p) &
                              (intervals.tau == r.tau)]
                assert len(b) == 1
                b = b.iloc[0]
                assert abs(b[obs] - getattr(r, obs)) < 1e-12
                low, high = b[obs + '_low'], b[obs + '_high']
                assert low <= getattr(r, obs) <= high
                lows.append(low); highs.append(high)
                plot_rows.append(dict(d=d, p=p, observable=obs, tau=r.tau, N=r.N,
                    fit_window=True, observed=getattr(r, obs), low95=low, high95=high,
                    offset=add, scaling_power=alpha,
                    displayed=(getattr(r, obs)-add)*r.tau**alpha,
                    displayed_low=(low-add)*r.tau**alpha,
                    displayed_high=(high-add)*r.tau**alpha))
            errors = np.array([y-np.array(lows), np.array(highs)-y]) * t**alpha
            ax.errorbar(t, (y-add)*t**alpha, yerr=errors, fmt='o',
                ms=3.7, color=DARK, elinewidth=.85, capsize=2,
                label='Data', zorder=3)
            tt = np.geomspace(f.tau_min, f.tau_max, 300)
            ys = float(f.A)*tt**(alpha-f.a)
            yf = float(g.A_theory)+float(g.B_theory)*tt**(alpha-1)
            ax.plot(tt, ys, '--', color=BLUE, lw=1.6, label='Single power (free $a$)')
            ax.plot(tt, yf, '-', color=ORANGE, lw=1.6,
                    label=r'Two-term form ($a=\alpha_n$)')
            for t, s, fixed in zip(tt, ys, yf):
                curve_rows.append(dict(d=d,p=p,observable=obs,tau=t,
                    single_scaled=s, fixed_two_scaled=fixed,scaling_power=alpha,offset=add))
            ylabel = r'$\tau^{\alpha_n}(c_1-D_L)$' if add else rf'$\tau^{{\alpha_n}}c_{i+1}$'
            ax.set(xscale='log', xlabel=r'Driving duration $\tau$ (MCS)', ylabel=ylabel,
                   title=rf'({chr(97+2*i+j)}) $d={d},\ p={p:g},\ c_{i+1}$')
            ax.grid(alpha=.15); ax.legend(frameon=False, loc='best')
    save(fig, f'major5_fit_comparison_{d}d')


def windows_sizes(windows):
    fig, axes = plt.subplots(3, 2, figsize=(10, 10), layout='constrained')
    for k, (d, p) in enumerate(((2,1.), (2,1.2), (3,1.), (3,1.2))):
        ax = axes.flat[k]
        for obs, color, marker, shift in (('c1',BLUE,'o',.95), ('c2',ORANGE,'D',1.05)):
            ff = windows[(windows.d == d) & (windows.p == p) &
                         (windows.observable == obs)].sort_values('cutoff')
            assert list(ff.cutoff) == list(CUTS)
            x = ff.cutoff.to_numpy()*shift; y = ff.a.to_numpy()
            lo = ff.low95.to_numpy(); hi = ff.high95.to_numpy()
            ax.errorbar(x, y, yerr=[y-lo, hi-y], fmt=marker+'-', color=color,
                ms=4, lw=1, capsize=2, label=rf'$c_{obs[-1]}$')
            for xx, lower, upper in zip(x, lo, hi):
                if upper == 1.: ax.plot(xx,.985,'^',color=color,ms=5)
                if lower == 0.: ax.plot(xx,.015,'v',color=color,ms=5)
        ax.axhline(float(ff.iloc[0].theory), ls='--', color=DARK, lw=1.2,
                   label='RG prediction')
        ax.set(xscale='log', xlim=(420,10000), ylim=(0,1.04),
               xlabel=r'Lower cutoff $\tau_{\min}$ (MCS)', ylabel='Fitted exponent $a$',
               title=rf'({chr(97+k)}) $d={d},\ p={p:g}$')
        ax.set_xticks(CUTS, labels=[str(c) for c in CUTS]); ax.tick_params(axis='x', labelsize=8)
        ax.grid(alpha=.15); ax.legend(frameon=False, loc='lower left')
    pairs = read(OLD / 'analysis_size/size_pairs.tsv')
    for j, d in enumerate((2,3)):
        ax = axes[2,j]
        for p,color,marker,shift in ((1.,BLUE,'o',.97),(1.2,ORANGE,'D',1.03)):
            rr = pairs[(pairs.dataset=='pooled') & (pairs.d==d) &
                       (pairs.p==p)].sort_values('tau')
            ax.errorbar(rr.tau.to_numpy()*shift, 1e6*rr.work_density_difference,
                        yerr=1.96e6*rr.se_work_difference, fmt=marker, color=color,
                        capsize=2, ms=4, label=rf'$p={p:g}$')
        ax.axhline(0,ls='--',color=DARK,lw=1)
        sizes = '1024 versus 512' if d==2 else '192 versus 128'
        ax.set(xscale='log',xlabel=r'Driving duration $\tau$ (MCS)',
            ylabel=r'$10^6(\bar w_{\rm large}-\bar w_{\rm small})$',
            title=f'({chr(101+j)}) {d}D: $L=$ {sizes}')
        ticks = [16384,32768,65536] + ([131072] if d==2 else [])
        ax.set_xticks(ticks,labels=[str(t) for t in ticks]); ax.tick_params(axis='x',labelsize=8)
        ax.xaxis.set_minor_formatter(NullFormatter()); ax.legend(frameon=False); ax.grid(alpha=.15)
    save(fig,'major5_fit_window_size_signed')


def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--windows-only', action='store_true')
    mode.add_argument('--cumulants-only', action='store_true')
    args = parser.parse_args()
    PRESENTATION.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    points = final_points()
    points.to_csv(PRESENTATION/'final_points_all_durations.tsv', sep='\t', index=False,
                  float_format='%.17g')
    windows = None if args.cumulants_only else scan_windows(points)
    if args.windows_only:
        print(windows[['d','p','observable','cutoff','n_points','a','low95','high95']].to_string(index=False))
        return
    intervals = read(PRESENTATION/'point_intervals.tsv')
    assert len(intervals) == 72
    plot_rows = []; curve_rows = []
    cumulants(3, points, intervals, plot_rows, curve_rows)
    cumulants(2, points, intervals, plot_rows, curve_rows)
    if not args.cumulants_only:
        windows_sizes(windows)
    pd.DataFrame(plot_rows).to_csv(PRESENTATION/'figure_points.tsv', sep='\t', index=False,
                                   float_format='%.17g')
    pd.DataFrame(curve_rows).to_csv(PRESENTATION/'figure_curves.tsv', sep='\t', index=False,
                                    float_format='%.17g')
    sources = [Path(__file__), HERE/'analysis/points.tsv', HERE/'analysis/fits_single_power.tsv',
        HERE/'analysis/fits_two_power.tsv', PRESENTATION/'point_intervals.tsv',
        OLD/'analysis_d2/points.tsv', OLD/'analysis_d3/points.tsv',
        OLD/'analysis_size/size_pairs.tsv',
        OLD/'audit_signed_background.py']
    manifest = dict(inputs={str(p):digest(p) for p in sources},
        output_hashes={str(p):digest(p) for p in sorted(OUT.glob('*'))},
        model='A*tau^-a + B/tau; A>=0, B signed, 0<a<1',
        fit_window_cutoff=2048, principal_points_per_curve=18,
        cumulant_figures='Only the eighteen principal-fit durations per curve',
        window_scan=list(CUTS), two_power_curves='a fixed to RG prediction',
        single_power_curves='a freely fitted', point_intervals='2000 whole-trajectory bootstrap, 95% percentile',
        size_comparison='Original paired durations only; no change to size runs or reference',
        manuscripts_changed=False)
    (PRESENTATION/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    count = 2 if args.cumulants_only else 3
    print(f'Rendered {count} figures; all 18 principal points retained per cumulant curve.')


if __name__ == '__main__':
    main()

"""Publication statistics for the frozen 18-point combined Major 5 dataset.

No raw samples, references, fit windows, or manuscript files are modified.
Gaussian parametric bootstrap: 20000 fixed draws under each fitted null.
Whole-trajectory bootstrap: 2000 fixed draws, same resamples for c1 and c2.
"""
from pathlib import Path
import hashlib
import json
import os
import sys
import time

for variable in ('OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[variable] = '1'
import numpy as np
import pandas as pd
from scipy.stats import beta, chi2

OUT = Path(__file__).resolve().parent
RUN = OUT.parent
OLD = RUN.parent / 'major5_followup_20261010'
ROOT = RUN.parents[1]
sys.path.insert(0, str(OLD))
from audit_signed_background import inputs, signed_fit
from bootstrap_model_comparison import independent_min
from bootstrap_fixed_theory import linear_many
from joint_bootstrap_existing import fit_many as legacy_fit_many

NBOOT = 20000
NTRAJ = 2000
LOW, HIGH = 1e-6, 1-1e-6


def read(path):
    return pd.read_csv(path, sep='\t', float_precision='round_trip')


def save(name, rows):
    pd.DataFrame(rows).to_csv(OUT/name, sep='\t', index=False, float_format='%.17g')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tail(count, total=NBOOT):
    count = int(count)
    return dict(k=count, n=total, p=(count+1)/(total+1),
        mc95_low=0. if count == 0 else float(beta.ppf(.025, count, total-count+1)),
        mc95_high=1. if count == total else float(beta.ppf(.975, count+1, total-count)))


def fast_many(t, C, Y, double):
    """Same constrained GLS estimator as prior scripts; cached grid geometry.

    Grid screening uses orthogonal projection scores; minima and their final
    values use explicit residuals in the stable log/t basis. No covariance or
    parameter-domain change is introduced by this vectorized implementation.
    """
    W = np.linalg.solve(np.linalg.cholesky(C), np.eye(len(t)))
    v = Y @ W.T
    l = np.log(t/t[0]); u = 1/t
    uw = u @ W.T; un = np.linalg.norm(uw); U = uw/un
    pu = v @ U
    grid = np.linspace(LOW, HIGH, 1001)
    if double:
        e = 1-grid
        hw = (u*np.expm1(e[:, None]*l)/e[:, None]) @ W.T
        hp = hw-(hw@U)[:, None]*U
        grid_vectors = hp/np.linalg.norm(hp, axis=1)[:, None]
    else:
        gw = np.exp(-grid[:, None]*l) @ W.T
        grid_vectors = gw/np.linalg.norm(gw, axis=1)[:, None]
    ix = np.empty(len(Y), int)
    for lo in range(0, len(Y), 1000):
        hi = min(len(Y), lo+1000)
        scores = np.maximum(0, v[lo:hi] @ grid_vectors.T)**2
        ix[lo:hi] = scores.argmax(axis=1)

    def calc(a):
        if double:
            e = 1-a
            hw = (u*np.expm1(e[:, None]*l)/e[:, None]) @ W.T
            hu = hw@U
            hp = hw-hu[:, None]*U
            hn = np.linalg.norm(hp, axis=1); H = hp/hn[:, None]
            ph = np.maximum(0, np.sum(v*H, axis=1))
            ch = ph/hn
            cu = (pu-ch*hu)/un
            A = ch/e/t[0]**e; B = cu-ch/e
            residual = v-ph[:, None]*H-pu[:, None]*U
        else:
            gw = np.exp(-a[:, None]*l) @ W.T
            amp = np.maximum(0, np.sum(gw*v, axis=1)/np.sum(gw*gw, axis=1))
            residual = v-amp[:, None]*gw
            A = amp*t[0]**a; B = np.zeros(len(a))
        return np.sum(residual*residual, axis=1), A, B

    left = grid[np.maximum(0, ix-1)]; right = grid[np.minimum(1000, ix+1)]
    rho = (np.sqrt(5)-1)/2
    for _ in range(48):
        x = right-rho*(right-left); y = left+rho*(right-left)
        take = calc(x)[0] < calc(y)[0]
        right = np.where(take, y, right); left = np.where(take, left, x)
    a = (left+right)/2
    q, A, B = calc(a)
    ag = grid[ix]; qg, Ag, Bg = calc(ag)
    take = qg < q
    return np.where(take, ag, a), np.minimum(qg, q), np.where(take, Ag, A), np.where(take, Bg, B)


def moments_bootstrap(x, rng):
    means = np.empty(NTRAJ); variances = np.empty(NTRAJ)
    for lo in range(0, NTRAJ, 40):
        hi = min(NTRAJ, lo+40)
        xx = x[rng.integers(0, len(x), size=(hi-lo, len(x)))]
        means[lo:hi] = xx.mean(axis=1)
        variances[lo:hi] = xx.var(axis=1, ddof=1)
    return means, variances


def main():
    started = time.time()
    points_path = RUN/'analysis/points.tsv'
    points = read(points_path).query('dataset=="combined"')
    assert len(points) == 72 and not points.duplicated(['d','L','p','tau']).any()
    offset_path = RUN.parent/'major5_audit_20261009/extension_analysis/finite_size_reference_2d.tsv'
    offset = float(read(offset_path).query('L==512').iloc[0].finite_size_offset)
    profile_path = RUN/'analysis/fits_two_power.tsv'
    single_path = RUN/'analysis/fits_single_power.tsv'
    profiles = read(profile_path).query('dataset=="combined"')
    singles = read(single_path).query('dataset=="combined"')
    new_path = RUN/'analysis/new_samples.tsv'
    new = read(new_path)
    ref_path = ROOT/'deliveries/major5_raw_data_original_reference_20261011/reference/original_reference_replicas.tsv'
    ref = read(ref_path).delta_f.to_numpy()
    assert abs(ref.mean()+.29697775299765183)<1e-14
    rng_traj = np.random.default_rng(2026101501)
    ref_draw, _ = moments_bootstrap(ref, rng_traj)
    sourcepaths = [points_path, profile_path, single_path, offset_path, new_path, ref_path,
        OLD/'joint_bootstrap_existing.py', OLD/'bootstrap_model_comparison.py',
        OLD/'bootstrap_fixed_theory.py', Path(__file__)]
    point_rows = []; background_rows = []; raw_arrays = {}; observed_rows = []; checks = []
    # All point intervals are created first, ready for the figure workflow.
    for d, L in ((2, 512), (3, 128)):
        old_path = OLD/f'analysis_d{d}/samples.tsv'; sourcepaths.append(old_path)
        old = read(old_path).query('dataset=="pooled" and tau>=2048')
        raw = {}
        for (p, tau), g in old.groupby(['p','tau']):
            raw[(float(p), int(tau))] = g.W.to_numpy()
        for (p, tau), g in new[new.d==d].groupby(['p','tau']):
            assert (float(p), int(tau)) not in raw
            raw[(float(p), int(tau))] = g.W.to_numpy()
        for p in (1., 1.2):
            source = points[(points.d==d)&(points.p==p)].sort_values('tau')
            times = source.tau.to_numpy(dtype=float)
            assert len(times)==18
            means = []; variances = []
            for row in source.to_dict('records'):
                x = raw[(p, int(row['tau']))]
                assert len(x)==row['N'] and np.all(np.isfinite(x))
                assert abs(x.mean()/L**d-row['mean_w'])<1e-13
                assert abs(x.var(ddof=1)/L**d-row['c2'])<1e-13
                m, v = moments_bootstrap(x, rng_traj)
                means.append(m/L**d); variances.append(v/L**d)
            means = np.asarray(means).T; variances = np.asarray(variances).T
            Ys = {'c1': means-(ref_draw[:,None] if d==3 else float(source.iloc[0].delta_f)),
                  'c2': variances}
            for i, row in enumerate(source.to_dict('records')):
                rr = {k: row[k] for k in ['d','L','p','tau','N','c1','c2']}
                for obs in ('c1','c2'):
                    rr[obs+'_low'], rr[obs+'_high'] = np.quantile(Ys[obs][:,i],[.025,.975])
                point_rows.append(rr)
            save('point_intervals.tsv', point_rows)
            if d==2:
                for obs in ('c1','c2'):
                    t,y,C = inputs(source.to_dict('records'),d,'combined',p,obs,2048,None,offset)
                    Y = Ys[obs]-(offset if obs=='c1' else 0.)
                    a,q,A,B = fast_many(t,C,np.vstack([y,Y]),True)
                    s = profiles[(profiles.d==d)&(profiles.p==p)&(profiles.observable==obs)].iloc[0]
                    assert abs(q[0]-s.chi2_min)<1e-7
                    assert abs(a[0]-s.a)<2e-6
                    key=f'd{d}_p{p}_{obs}'
                    raw_arrays[key+'_a']=a[1:];raw_arrays[key+'_A']=A[1:];raw_arrays[key+'_B']=B[1:]
                    background_rows.append(dict(d=d,L=L,p=p,observable=obs,a=a[0],A=A[0],B=B[0],
                        a_low=np.quantile(a[1:],.025),a_high=np.quantile(a[1:],.975),
                        B_low=np.quantile(B[1:],.025),B_high=np.quantile(B[1:],.975),
                        B_negative_fraction=np.mean(B[1:]<0),A_zero_fraction=np.mean(A[1:]==0),
                        a_upper_fraction=np.mean(a[1:]>1-1e-5),repetitions=NTRAJ))
                    # Independent old implementation, using identical pseudo-data.
                    idx=np.array([0,1,17,83,251,999,1999,2000])
                    al,ql,_,_=legacy_fit_many(t,C,np.vstack([y,Y])[idx],True)
                    error=float(np.max(np.abs(ql-q[idx])));assert error<1e-6
                    checks.append(dict(test='whole_trajectory_legacy',d=d,p=p,observable=obs,
                        max_chi2_error=error,draws=len(idx)))
            print('POINTS',d,p,'elapsed',time.time()-started,flush=True)
    save('trajectory_background_2d.tsv',background_rows)
    np.savez_compressed(OUT/'trajectory_replicates.npz',**raw_arrays,shared_reference=ref_draw)

    rng_null = np.random.default_rng(2026101502)
    rng_fixed = np.random.default_rng(2026101503)
    ref_null = rng_null.normal(size=NBOOT); ref_fixed = rng_fixed.normal(size=NBOOT)
    model_rows=[]; fit_rows=[]; arrays={}
    for d in (2,3):
        for p in (1.,1.2):
            for obs in ('c1','c2'):
                source=points[(points.d==d)&(points.p==p)].sort_values('tau')
                t,y,C=inputs(source.to_dict('records'),d,'combined',p,obs,2048,None,offset)
                sp=singles[(singles.d==d)&(singles.p==p)&(singles.observable==obs)].iloc[0]
                tp=profiles[(profiles.d==d)&(profiles.p==p)&(profiles.observable==obs)].iloc[0]
                alpha=float(tp.theory)
                a0,q0,A0,_=fast_many(t,C,y[None,:],False)
                af,qf,Af,Bf=fast_many(t,C,y[None,:],True)
                assert abs(q0[0]-sp.chi2)<1e-7
                assert abs(qf[0]-tp.chi2_min)<1e-7
                X=np.column_stack([t**(-alpha),1/t])
                qt,ab,edge=linear_many(X,C,y[None,:])
                assert abs(qt[0]-tp.chi2_theory)<1e-7
                # Exact unit-change equivalence of the linear presentation.
                qtt,abt,_=linear_many(np.column_stack([t**(1-alpha),np.ones(len(t))]),
                    C*np.outer(t,t),(y*t)[None,:])
                assert abs(qtt[0]-qt[0])<1e-8 and np.allclose(abt,ab,rtol=1e-9,atol=1e-10)
                def simulate(mean,rng,reference_z):
                    if d==3 and obs=='c1':
                        sr=float(source.iloc[0].se_delta_f)
                        D=C-sr**2
                        assert np.max(np.abs(D-np.diag(np.diag(D))))<1e-20
                        return mean+rng.normal(size=(NBOOT,len(t)))*np.sqrt(np.diag(D))-sr*reference_z[:,None]
                    return mean+rng.normal(size=(NBOOT,len(t)))@np.linalg.cholesky(C).T
                # Single-power null: GOF plus the necessity of B with free a.
                Y0=simulate(A0[0]*t**(-a0[0]),rng_null,ref_null)
                _,s0,_,_=fast_many(t,C,Y0,False)
                az,s1,_,_=fast_many(t,C,Y0,True)
                assert np.min(s0-s1)>-1e-6
                delta0=max(0.,float(q0[0]-qf[0])); deltas=np.maximum(0.,s0-s1)
                P0=tail(np.sum(s0>=q0[0])); PB=tail(np.sum(deltas>=delta0))
                # Theoretical two-power null: GOF and test of freeing a.
                Yt=simulate(X@ab[0],rng_fixed,ref_fixed)
                st,abt,edges=linear_many(X,C,Yt)
                at,sf,_,_=fast_many(t,C,Yt,True)
                assert np.min(st-sf)>-1e-6
                deltat=max(0.,float(qt[0]-qf[0])); dt=np.maximum(0.,st-sf)
                Pfit=tail(np.sum(st>=qt[0])); Pa=tail(np.sum(dt>=deltat))
                row=dict(d=d,L=512 if d==2 else 128,p=p,observable=obs,n_points=len(t),
                    tau_min=t[0],tau_max=t[-1],alpha=alpha,a_single=sp.a,
                    single_low95=sp.low95,single_high95=sp.high95,chi2_single=q0[0],
                    dof_single=len(t)-2,P0=P0['p'],P0_k=P0['k'],P0_mc95_high=P0['mc95_high'],
                    chi2_fixed=qt[0],dof_fixed=len(t)-2,Pfit=Pfit['p'],Pfit_k=Pfit['k'],
                    Pfit_mc95_low=Pfit['mc95_low'],Pfit_mc95_high=Pfit['mc95_high'],
                    Pa=Pa['p'],Pa_k=Pa['k'],Pa_mc95_low=Pa['mc95_low'],Pa_mc95_high=Pa['mc95_high'],
                    a_free=tp.a,free_low95=tp.low95,free_high95=tp.high95,
                    free_upper_unidentified=bool(tp.upper_unidentified),chi2_free=qf[0],dof_free=len(t)-3,
                    A_fixed=ab[0,0],B_fixed=ab[0,1],A_free=Af[0],B_free=Bf[0],
                    repetitions=NBOOT,delta_free_exponent=deltat)
                fit_rows.append(row)
                model_rows.append(dict(d=d,p=p,observable=obs,delta_chi2=delta0,
                    p_bootstrap=PB['p'],exceedances=PB['k'],repetitions=NBOOT,
                    mc95_low=PB['mc95_low'],mc95_high=PB['mc95_high'],
                    p_chi2_1=float(chi2.sf(delta0,1))))
                # Independently scan selected null draws with prior scalar solver.
                for label,Y,Q in [('single_null',Y0,s1),('theory_null',Yt,sf)]:
                    ids=sorted(set([0,17,int(np.argmax(Q)),int(np.argmax(az if label=='single_null' else at))]))
                    for j in ids:
                        ff,_=signed_fit(t,Y[j],C)
                        err=abs(independent_min(lambda aa:ff(aa)[0])-Q[j])
                        assert err<1e-6,(d,p,obs,label,j,err)
                        checks.append(dict(test=label,d=d,p=p,observable=obs,
                            max_chi2_error=err,draws=1,replicate=j))
                key=f'd{d}_p{p}_{obs}'
                arrays[key+'_single_null_chi2']=s0;arrays[key+'_single_null_double_chi2']=s1
                arrays[key+'_theory_null_chi2']=st;arrays[key+'_theory_null_free_chi2']=sf
                arrays[key+'_null_delta_B']=deltas;arrays[key+'_null_delta_a']=dt
                save('fit_statistics.tsv',fit_rows);save('model_comparison.tsv',model_rows)
                print('BOOT',d,p,obs,'P0',P0,'Pfit',Pfit['p'],'Pa',Pa['p'],'PB',PB,
                    'elapsed',time.time()-started,flush=True)
    order=np.argsort([r['p_bootstrap'] for r in model_rows]); running=0.
    for rank,i in enumerate(order):
        running=max(running,min(1.,(len(model_rows)-rank)*model_rows[i]['p_bootstrap']))
        model_rows[i]['p_holm_8']=running
    save('model_comparison.tsv',model_rows)
    save('independent_checks.tsv',checks)
    np.savez_compressed(OUT/'parametric_replicates.npz',**arrays,
        shared_reference_single_null=ref_null,shared_reference_theory_null=ref_fixed)
    counts=points.groupby(['d','L','p']).agg(n_points=('tau','size'),trajectories=('N','sum'),
        min_N=('N','min'),max_N=('N','max'),tau_min=('tau','min'),tau_max=('tau','max')).reset_index()
    save('sampling_counts.tsv',counts)
    manifest=dict(complete=True,n_total_points=72,trajectories=int(points.N.sum()),
        trajectory_bootstrap_seed=2026101501,single_null_seed=2026101502,theory_null_seed=2026101503,
        parametric_repetitions=NBOOT,trajectory_repetitions=NTRAJ,cutoff=2048,
        data='All 18 distinct durations per dimension and protocol; 72 parameter points',
        model='A*tau^-a+B/tau; A>=0; signed B; 1e-6<=a<=1-1e-6',
        covariance='Original sample-moment GLS covariance, held fixed; original common 3D reference unchanged',
        reference_mean=float(ref.mean()),reference_se=float(ref.std(ddof=1)/np.sqrt(len(ref))),
        offset_2d=offset,point_interval_c1='Before subtracting known D512; figures subtract that same constant from central value and bounds',
        bootstrap_p='(k+1)/(20000+1); Clopper-Pearson two-sided 95% Monte Carlo intervals',
        limits=['Parametric GOF is conditional on estimated Gaussian cumulant covariance',
            'Profile confidence intervals remain nominal and distinct from the trajectory-percentile B intervals',
            'Tests are marginal; no independence between cumulants or protocol shared-reference errors asserted'],
        checks=len(checks),max_check_error=max(r['max_chi2_error'] for r in checks),
        elapsed_seconds=time.time()-started,source_sha256={str(p):sha(p) for p in sourcepaths})
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('COMPLETE',json.dumps(manifest,indent=2),flush=True)


if __name__=='__main__':
    main()

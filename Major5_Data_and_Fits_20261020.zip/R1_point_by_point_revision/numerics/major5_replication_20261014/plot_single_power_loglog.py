"""Plot the saved principal single-power fits on logarithmic axes (SM Fig. S4).

Uses the same data, 95% intervals, fixed 2D reference subtraction, and
generalized least-squares estimates as Figs. S1-S2. No fits are rerun.
Run this script from any directory with NumPy and Matplotlib installed.
"""
from pathlib import Path
import csv
import hashlib
import json

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import NullFormatter

HERE = Path(__file__).resolve().parent
PRESENTATION = HERE / "presentation_20261015"
OUT = PRESENTATION / "figures"
NAME = "major5_single_power_loglog"
BLUE, ORANGE = "#276A9D", "#BC651F"


def read(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def key(row):
    return int(row["d"]), float(row["p"]), row["observable"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_rows(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), delimiter="\t")
        writer.writeheader()
        writer.writerows(rows)


def main():
    points_path = PRESENTATION / "figure_points.tsv"
    curves_path = PRESENTATION / "figure_curves.tsv"
    fits_path = HERE / "analysis/fits_single_power.tsv"
    points, old_curves = read(points_path), read(curves_path)
    fits = {key(r): r for r in read(fits_path) if r["dataset"] == "combined"}
    assert len(points) == 144 and len(fits) == 8
    assert len({(*key(r), float(r["tau"])) for r in points}) == 144

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 11,
        "axes.titlesize": 12, "axes.labelsize": 12,
        "legend.fontsize": 10, "axes.spines.top": False,
        "axes.spines.right": False, "pdf.fonttype": 42,
        "savefig.dpi": 200,
    })
    fig, axes = plt.subplots(2, 2, figsize=(10, 7.2), sharex=True,
                             sharey="row", layout="constrained")
    point_rows, curve_rows, checks = [], [], []
    max_curve_error = 0.0
    for i, d in enumerate((2, 3)):
        for j, p in enumerate((1.0, 1.2)):
            ax = axes[i, j]
            handles = []
            for obs, color, marker in (("c1", BLUE, "o"), ("c2", ORANGE, "D")):
                group_key = (d, p, obs)
                fit = fits[group_key]
                rows = sorted((r for r in points if key(r) == group_key),
                              key=lambda r: float(r["tau"]))
                assert len(rows) == int(fit["n_points"]) == 18
                assert all(r["fit_window"] == "True" for r in rows)
                tau = np.array([float(r["tau"]) for r in rows])
                assert tau[0] == float(fit["tau_min"])
                assert tau[-1] == float(fit["tau_max"])
                offset = float(rows[0]["offset"])
                assert all(float(r["offset"]) == offset for r in rows)
                assert (offset > 0) == (d == 2 and obs == "c1")
                values = np.array([float(r["observed"]) for r in rows]) - offset
                low = np.array([float(r["low95"]) for r in rows]) - offset
                high = np.array([float(r["high95"]) for r in rows]) - offset
                assert np.all(0 < low) and np.all(low <= values) and np.all(values <= high)
                amplitude, exponent = float(fit["A"]), float(fit["a"])

                # Check against the published compensated curves before removing
                # the plotting factor tau**alpha. This does not refit the data.
                old = [r for r in old_curves if key(r) == group_key]
                assert len(old) == 300
                tt = np.array([float(r["tau"]) for r in old])
                theory = float(fit["theory"])
                yy = amplitude * tt ** (-exponent)
                old_y = np.array([float(r["single_scaled"]) for r in old]) / tt**theory
                relative_error = np.max(np.abs(yy / old_y - 1))
                max_curve_error = max(max_curve_error, float(relative_error))
                assert relative_error < 2e-12
                for r, t, y, lo, hi in zip(rows, tau, values, low, high):
                    assert np.isclose(y * t**theory, float(r["displayed"]), rtol=2e-12)
                    point_rows.append(dict(d=d, L=int(fit["L"]), p=p, observable=obs,
                        tau=int(t), N=int(r["N"]), observed=float(r["observed"]),
                        offset=offset, displayed=y, low95=lo, high95=hi,
                        single_power_fit=amplitude * t**(-exponent)))
                for t, y in zip(tt, yy):
                    curve_rows.append(dict(d=d, p=p, observable=obs, tau=t,
                                           fitted=y, A=amplitude, a=exponent))
                checks.append(dict(d=d, L=int(fit["L"]), p=p, observable=obs,
                    n_points=len(rows), tau_min=int(tau[0]), tau_max=int(tau[-1]),
                    A=amplitude, a=exponent, offset=offset,
                    low95_a=float(fit["low95"]), high95_a=float(fit["high95"])))

                ax.plot(tt, yy, "--", color=color, lw=1.5, zorder=2)
                ax.errorbar(tau, values, yerr=[values-low, high-values],
                            fmt=marker, color=color, ms=4.0, markeredgewidth=.7,
                            elinewidth=.85, capsize=2, linestyle="none", zorder=3)
                symbol = r"c_1-D_{512}" if offset else rf"c_{obs[-1]}"
                handles.append(Line2D([], [], color=color, marker=marker,
                    linestyle="--", lw=1.5, ms=4,
                    label=rf"${symbol}$, $a={exponent:.4f}$"))
            ax.set(xscale="log", yscale="log", xlim=(1800, 155000),
                   title=rf"({chr(97+2*i+j)}) $d={d},\ L={512 if d == 2 else 128},\ p={p:g}$")
            ax.set_xticks([4096, 16384, 65536, 131072],
                          labels=["4096", "16384", "65536", "131072"])
            ax.tick_params(axis="x", labelsize=9)
            ax.xaxis.set_minor_formatter(NullFormatter())
            ax.grid(which="major", alpha=.15, linewidth=.7)
            ax.legend(handles=handles, frameon=False, loc="lower left")
            if j == 0:
                ax.set_ylabel(r"$c_1-D_{512},\ c_2$" if d == 2 else r"$c_1,\ c_2$")
            if i == 1:
                ax.set_xlabel(r"Driving duration $\tau$ (MCS)")
        row_points = [r for r in point_rows if r["d"] == d]
        axes[i, 0].set_ylim(min(r["low95"] for r in row_points)*.72,
                            max(r["high95"] for r in row_points)*1.35)

    OUT.mkdir(exist_ok=True)
    fig.savefig(OUT / f"{NAME}.pdf", bbox_inches="tight")
    fig.savefig(OUT / f"{NAME}.png", bbox_inches="tight")
    plt.close(fig)
    write_rows(PRESENTATION / "single_power_loglog_points.tsv", point_rows)
    write_rows(PRESENTATION / "single_power_loglog_curves.tsv", curve_rows)
    inputs = [points_path, curves_path, fits_path, Path(__file__)]
    outputs = [OUT / f"{NAME}.{suffix}" for suffix in ("pdf", "png")]
    outputs += [PRESENTATION / f"single_power_loglog_{kind}.tsv" for kind in ("points", "curves")]
    manifest = dict(figure="SM Fig. S4", fit_method="Saved generalized least-squares fits; no refitting",
        plot="Logarithmic axes; known D_512 subtracted from 2D c1",
        intervals="Saved pointwise 95% whole-trajectory bootstrap intervals",
        inputs={str(p.relative_to(HERE)): digest(p) for p in inputs},
        outputs={str(p.relative_to(HERE)): digest(p) for p in outputs},
        groups=checks, max_relative_error_against_existing_curves=max_curve_error)
    (PRESENTATION / "single_power_loglog_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    print(json.dumps(dict(points=len(point_rows), curves=len(curve_rows), groups=len(checks),
        max_curve_relative_error=max_curve_error, figure=str(OUT / f"{NAME}.pdf")), indent=2))


if __name__ == "__main__":
    main()
